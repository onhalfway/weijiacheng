# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
okay we've come to our first word now we
see the picture this is what it is
and this is the definition so let's go
over the definition a warm coat with
sleeves it's very similar to coat coat
and another word mean the same thing
what is the other word we say jacket
jacket jacket jacket and coat are
basically the same right we say jacket
for the covering that we wear it's the
same as a coat we wear them in the
winter or when it's cold outside we want
to stay warm put on a jacket put on a
coat same thing the next one is another
type of clothing that we wear when it's
cold outside but we wear these over our
hands so this is the picture the warm
thing that you wear on your hand so if I
wear it on my hand right I put it on
what is it what do we call that we call
that a glove this is a glove this is a
very colorful glove this is a very warm
glove right so we wear gloves when we
want to stay warm a glove very easy okay
the next word okay to hold it's a verb -
we're looking for a verb to hold
somebody close in your arms so to hold
that's a verb to hold somebody close in
your arms like wow these very cute
monkeys right they're holding each other
they love each other right there maybe
they're doing it to stay warm too but in
this case we say cuddle cuddle these two
monkeys are
by the way you may have thought hug hug
what's the difference between hug and
cuddle ego ha go ego ha go aunt okay
Tony right what's the difference between
hug and cuddle hug is very quick it's
like you see your friend hey how are you
doing you hug that person done finished
quick but cuddle is a long time right
and be careful cuddle usually means like
romantic right boyfriend or girlfriend
or parent and child that's not romantic
right but that's just people who hold on
to each other for a long time right
cuddle and maybe you know pet the hair
or something you cuddle you might cuddle
your pet if you have a dog or a cat you
cuddle that pet for a long time hug hug
done finished
okay so hug is short time cuddle is for
a longer time so to cuddle to hold
somebody close in your arms okay not
thin whoa look at that book can you read
that book it would take a very very long
time
to read this book why because it's not
thin it's not a thin book it's really
thick it's a thick book so if we see
something that is very wide right like
this then we say it's thick it has a lot
of thickness not thin thin is like this
thick is like this right okay
so thick not thin the next word we have
look at this it looks like it looks very
soft right you can put your hand on it
and all its feels very soft right it's
hair that covers an animal's body an
animal's body not human right if it's
hair that covers an animal
body we call it fur fur not human
do not say human fur hmm we say hair
right so for humans humans have hair
animals have fur so humans have hair on
their head if we have hair on our arms
it's not fur it's hair okay
humans have hair animals have fur and
animals have a lot of fur if you have a
dog or a cat they have fur all over
their body so an animal's fur hair that
covers an animal's body it covers it
everywhere next is a piece of cloth that
you wear it's a type of clothing a piece
of cloth that you wear there are many
types of clothing this one you wear
around your neck here it is right so if
it's cold outside you wear this and you
put it around your neck
it keeps your neck warm because it's
very cold outside you can put it up over
your face right to protect your nose and
your mouth so some people wear it up
here if it's really cold what do we call
it we call it a scarf scarf
s-see scarf scarf okay and then our F at
the end scarf okay
that's one scarf but if we have many two
three four five or many we say scarves
scarves okay do you guys try scarves
scarves okay so we have V and s scarves
okay don't pronounce the e scarves so
one scarf two
scarves okay so scarf is singular plural
is scarves another piece of clothing
that we wear to keep warm okay the next
word is a large animal with thick fur
that's a very simple definition we're
looking for this animal here because
there are many large animals with thick
fur right but we're looking for this
specific one we where do we find him we
find him at the North Pole at the North
Pole way up north we find this animal
large animal with thick fur we call this
animal a bear right now there are many
kinds of bears right this is a polar
bear a polar bear a polar bear is a bear
that lives at the North Pole it's very
large it has thick fur not all bears
live at the North Pole there are other
bears that live further south like black
bears brown bears okay
many types of bears but the bear that
lives at the North Pole
is a polar bear okay next word having a
low temperature if something has a low
temperature low what do we say it is
cold it's cold outside in the wintertime
it is cold it has a low temperature
temperature is the number that says how
cold or how hot it is outside or inside
what is the temperature of the air right
if it's a low temperature little it's
cold if it's a high temperature it's hot
okay okay but what about not very hot or
very cold so we have hot high
temperature we
have cold low temperature high
temperature low temperature but we want
in the middle not very hot not very cold
in between we say it's warm so warm warm
is between hot and cold it's not it's
not high temperature it's not low
temperature it's in the middle it's warm
usually we are warm in your house it's
warm at your school
I hope it's warm because they're inside
we like to have the temperature to be
warm that's normal
not very hot not very cold it's warm in
the middle ok here we have another piece
of clothing another piece of clothing
this is something you wear on your head
so you put it on your head right there
are many styles many types this is one
style it's a woman's style a woman would
wear this this is a hat very easy hat do
you have a hat sometimes you can say a
cap like a baseball cap is very common
baseball cap right that's the cap that
you put on your head it has the long
part out here that protects your face
from the Sun most hats protect your face
from the Sun but there are many styles
of hats many different types of hats ok
now here we have an interesting word the
soft part of your body under your skin
so under my skin it's soft right yeah my
stomach is soft right if it's hard it's
not this but if it's soft what do we
call it we call it fat so under my skin
on my belly on my stomach that is fat
if you workout if you exercise it's not
fat
then it's muscle if it's hard it's
muscle if it's soft and weak then it's
fat butt fat keeps you warm right
okay so fat the soft part of your body
under your skin is fat but if you have a
lot of fat you're warm
but you shouldn't have too much fat
right you should also have muscle okay
an animal that lives in the water an
animal that lives in the water like this
animal right here that animal lives in
the water it breathes it breathes in the
water what is it it is of course a fish
fish are very common that and they live
in the water fish are common animals
that live in the water sometimes they
jump out of the water and their fish
fish

## toggle timestamps Transcript

00:00
[Music]
00:05
okay we've come to our first word now we
00:08
see the picture this is what it is
00:10
and this is the definition so let's go
00:13
over the definition a warm coat with
00:17
sleeves it's very similar to coat coat
00:21
and another word mean the same thing
00:24
what is the other word we say jacket
00:28
jacket jacket jacket and coat are
00:33
basically the same right we say jacket
00:38
for the covering that we wear it's the
00:41
same as a coat we wear them in the
00:44
winter or when it's cold outside we want
00:47
to stay warm put on a jacket put on a
00:52
coat same thing the next one is another
00:57
type of clothing that we wear when it's
01:01
cold outside but we wear these over our
01:04
hands so this is the picture the warm
01:08
thing that you wear on your hand so if I
01:14
wear it on my hand right I put it on
01:17
what is it what do we call that we call
01:20
that a glove this is a glove this is a
01:25
very colorful glove this is a very warm
01:28
glove right so we wear gloves when we
01:32
want to stay warm a glove very easy okay
01:37
the next word okay to hold it's a verb -
01:44
we're looking for a verb to hold
01:48
somebody close in your arms so to hold
01:52
that's a verb to hold somebody close in
01:56
your arms like wow these very cute
01:59
monkeys right they're holding each other
02:01
they love each other right there maybe
02:04
they're doing it to stay warm too but in
02:07
this case we say cuddle cuddle these two
02:11
monkeys are
02:13
by the way you may have thought hug hug
02:20
what's the difference between hug and
02:24
cuddle ego ha go ego ha go aunt okay
02:30
Tony right what's the difference between
02:33
hug and cuddle hug is very quick it's
02:37
like you see your friend hey how are you
02:39
doing you hug that person done finished
02:42
quick but cuddle is a long time right
02:46
and be careful cuddle usually means like
02:50
romantic right boyfriend or girlfriend
02:53
or parent and child that's not romantic
02:57
right but that's just people who hold on
03:00
to each other for a long time right
03:03
cuddle and maybe you know pet the hair
03:05
or something you cuddle you might cuddle
03:08
your pet if you have a dog or a cat you
03:11
cuddle that pet for a long time hug hug
03:15
done finished
03:17
okay so hug is short time cuddle is for
03:20
a longer time so to cuddle to hold
03:24
somebody close in your arms okay not
03:29
thin whoa look at that book can you read
03:32
that book it would take a very very long
03:36
time
03:37
to read this book why because it's not
03:41
thin it's not a thin book it's really
03:45
thick it's a thick book so if we see
03:49
something that is very wide right like
03:53
this then we say it's thick it has a lot
03:56
of thickness not thin thin is like this
04:00
thick is like this right okay
04:02
so thick not thin the next word we have
04:07
look at this it looks like it looks very
04:10
soft right you can put your hand on it
04:12
and all its feels very soft right it's
04:15
hair that covers an animal's body an
04:20
animal's body not human right if it's
04:24
hair that covers an animal
04:26
body we call it fur fur not human
04:33
do not say human fur hmm we say hair
04:39
right so for humans humans have hair
04:49
animals have fur so humans have hair on
04:54
their head if we have hair on our arms
04:57
it's not fur it's hair okay
05:00
humans have hair animals have fur and
05:05
animals have a lot of fur if you have a
05:08
dog or a cat they have fur all over
05:11
their body so an animal's fur hair that
05:16
covers an animal's body it covers it
05:19
everywhere next is a piece of cloth that
05:25
you wear it's a type of clothing a piece
05:29
of cloth that you wear there are many
05:32
types of clothing this one you wear
05:36
around your neck here it is right so if
05:40
it's cold outside you wear this and you
05:43
put it around your neck
05:44
it keeps your neck warm because it's
05:48
very cold outside you can put it up over
05:50
your face right to protect your nose and
05:53
your mouth so some people wear it up
05:55
here if it's really cold what do we call
05:58
it we call it a scarf scarf
06:03
s-see scarf scarf okay and then our F at
06:09
the end scarf okay
06:12
that's one scarf but if we have many two
06:16
three four five or many we say scarves
06:22
scarves okay do you guys try scarves
06:27
scarves okay so we have V and s scarves
06:33
okay don't pronounce the e scarves so
06:37
one scarf two
06:39
scarves okay so scarf is singular plural
06:43
is scarves another piece of clothing
06:47
that we wear to keep warm okay the next
06:52
word is a large animal with thick fur
06:56
that's a very simple definition we're
07:00
looking for this animal here because
07:03
there are many large animals with thick
07:06
fur right but we're looking for this
07:08
specific one we where do we find him we
07:12
find him at the North Pole at the North
07:18
Pole way up north we find this animal
07:22
large animal with thick fur we call this
07:26
animal a bear right now there are many
07:29
kinds of bears right this is a polar
07:34
bear a polar bear a polar bear is a bear
07:39
that lives at the North Pole it's very
07:42
large it has thick fur not all bears
07:46
live at the North Pole there are other
07:48
bears that live further south like black
07:52
bears brown bears okay
07:56
many types of bears but the bear that
07:58
lives at the North Pole
07:59
is a polar bear okay next word having a
08:05
low temperature if something has a low
08:08
temperature low what do we say it is
08:13
cold it's cold outside in the wintertime
08:18
it is cold it has a low temperature
08:22
temperature is the number that says how
08:26
cold or how hot it is outside or inside
08:31
what is the temperature of the air right
08:35
if it's a low temperature little it's
08:37
cold if it's a high temperature it's hot
08:41
okay okay but what about not very hot or
08:47
very cold so we have hot high
08:51
temperature we
08:53
have cold low temperature high
08:56
temperature low temperature but we want
08:59
in the middle not very hot not very cold
09:03
in between we say it's warm so warm warm
09:10
is between hot and cold it's not it's
09:14
not high temperature it's not low
09:16
temperature it's in the middle it's warm
09:21
usually we are warm in your house it's
09:25
warm at your school
09:27
I hope it's warm because they're inside
09:31
we like to have the temperature to be
09:35
warm that's normal
09:37
not very hot not very cold it's warm in
09:41
the middle ok here we have another piece
09:46
of clothing another piece of clothing
09:49
this is something you wear on your head
09:53
so you put it on your head right there
09:57
are many styles many types this is one
10:00
style it's a woman's style a woman would
10:04
wear this this is a hat very easy hat do
10:10
you have a hat sometimes you can say a
10:13
cap like a baseball cap is very common
10:17
baseball cap right that's the cap that
10:22
you put on your head it has the long
10:24
part out here that protects your face
10:27
from the Sun most hats protect your face
10:31
from the Sun but there are many styles
10:34
of hats many different types of hats ok
10:38
now here we have an interesting word the
10:43
soft part of your body under your skin
10:47
so under my skin it's soft right yeah my
10:51
stomach is soft right if it's hard it's
10:54
not this but if it's soft what do we
10:57
call it we call it fat so under my skin
11:02
on my belly on my stomach that is fat
11:06
if you workout if you exercise it's not
11:10
fat
11:10
then it's muscle if it's hard it's
11:16
muscle if it's soft and weak then it's
11:20
fat butt fat keeps you warm right
11:23
okay so fat the soft part of your body
11:26
under your skin is fat but if you have a
11:29
lot of fat you're warm
11:31
but you shouldn't have too much fat
11:34
right you should also have muscle okay
11:38
an animal that lives in the water an
11:42
animal that lives in the water like this
11:45
animal right here that animal lives in
11:48
the water it breathes it breathes in the
11:55
water what is it it is of course a fish
11:59
fish are very common that and they live
12:03
in the water fish are common animals
12:06
that live in the water sometimes they
12:08
jump out of the water and their fish
12:11
fish