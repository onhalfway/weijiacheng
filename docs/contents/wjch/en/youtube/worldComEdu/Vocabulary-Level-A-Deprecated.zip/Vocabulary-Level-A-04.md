# Transcsript

- [Transcsript](#transcsript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
we have to learn some vocabulary
now the first vocabulary word we're
going to listen to or learn is this one
here this is a picture of a place in
front of your house what is this it's a
bell outside the door you press it it
goes ding dong right ding dong what is
that it's a kind of Bell and it's at the
door it's at the door and it's a bell
it's a doorbell that's pretty easy it's
a door bell it's outside the door and it
is about will you push it ding dong
sounds like a bell so it's a door bell
in front of your house you have a
doorbell when somebody visits you they
press the door bell so doorbell doorbell
it's two words that make one word door
and bell doorbell very easy okay the
next word what is this
this is very old right probably you have
a small one in your pocket something you
use to talk to your friend so you want
to talk to your friend you take this out
of your pocket or your backpack and you
can call your friend on it and you can
talk to your friend what is it what is
it called it's a telephone telephone
telephone telephone three syllables or
three sounds telephone telephone
telephone very easy of course this is a
very old telephone right we don't use
those anymore we use the very small or
sometimes big pocket our cell phones and
we but it's a telephone it's basically a
telephone that we use to talk with our
friend
okay the next word what's this this
looks very interesting doesn't it this
is a clock so it's a type of clock right
we tell time but look at this what are
these things here those are bells again
another another type of Bell right and
at a certain time those bells sound did
it it editing right so what is this it's
a clock that wakes you up in the morning
maybe you use this maybe you use your
cell phone probably you use your cell
phone but a long time ago when I was
younger we used one of these to wake up
in the morning what is it called it's an
alarm clock so it's a clock right it's a
clock what kind of clock alarm alarm
means make a big sound alarm did it
editing right so an alarm clock is what
we use to wake up in the morning we need
a very loud sound to wake up right some
people need a really really loud sound
to wake up some people they sleep that
it editing they keep sleeping okay
so you need a very loud alarm clock to
wake up in the morning alarm clock okay
our next word wow this looks very
interesting right unhappy he looks very
sad right because you are alone if he is
alone he's very sad right it almost
looks like a human right but it looks
like a baby gorilla so very interesting
picture but he looks sad because he's
what he's alone so he is lonely if you
are alone you are by yourself you are by
your self there are no friends no family
around you you are by yourself you are
alone how do you feel you are lonely
lonely be careful with el la lonely we
have two elves lonely lonely lonely so
hopefully I hope you don't feel lonely
but sometimes we feel lonely because we
are alone there are no friends or family
around us in that time we feel lonely
okay next
somewhere where only animals live only
animals no humans so it's in nature some
place where there are no humans and
animals live without humans they don't
live with humans what do we call this
place we say it's in the wild in the
wild the wild is a place where there are
no humans no villages no towns no roads
no humans around just animals only
animals live there in the wild wild of
you is like wow what wild and then we
have LD wild uh duck is when you jaw
drops duck wild wild so in the wild okay
the next word giving help so if
something is giving help what are they
doing what do we say for this word we
say help full because it's like full
right this word here full to ELLs means
you have a lot of it's full right but we
only have one el here when we put it as
an adjective helpful helpful if somebody
or some thing is helpful they are giving
help so help full helpful helpful that
is the word that means you are giving
help okay here's another word this is a
very funny picture right very cute right
we have a small animal on top of the
girl
had it's her pet right a small animal
that lives with you and I just said the
word right so a small animal that lives
with you it can be a gerbil it can be a
hamster it can be a dog it can be a cat
it can be a bird but it's a small animal
that lives with you not in the wild but
in your house we call that of course a
pet I said that before right
do you have a pet many houses have a pet
like a dog or a cat very common pets but
also a hamster you could say hamster a
hamster is also a very common type of
pets they're fun aren't they they're
they're very cute and also they make us
so we are not lonely we have some thing
to play with or something to love and to
play with okay what's this guy doing
that's crazy what is he doing he's it's
exciting and not boring so this kid is
exciting right it's kind of exciting we
look at him more wow what is he doing
with his eyes that's very strange and
his his smile is very funny too right
because he's missing a tooth he's
missing a tooth so if something is
exciting not boring we say it is fun
it's fun let's do something for fun
let's have fun we want to be excited we
don't want to be bored it's fun let's
have fun okay here this man he cannot
see not able to see we know that very
quickly because people who are like him
have a long stick and it's this color
white and red and they use it so they
can feel where they are going because
they cannot see what do we call this
situation we say blind this person is
blind
it's unfortunate it's too bad but
sometimes this happens so this person is
blind they
cannot see blind okay so the word is
blind okay now to move from one side to
the other so you're on one side of the
street and you want to go to the other
side of the street or river or anything
you want to go from one side you want to
go to the other side what do we say we
say cross I want to cross the street
cross is a verb right so cross the
street cross the street let's cross the
street we want to cross the street so
use cross as a verb
let's go across that's different
let's cross the street if you use a
cross that's a different word cross is
the word that we use for a verb let's
cross the street
you should cross the street here not
here you should cross here okay so cross
as a verb let's cross the street okay
this is another verb to try to try to
hear sounds carefully so it's very cute
isn't he with the little feet okay but
look at these big headphones by the way
these are head phones they're very big
for this little boy really big and he's
listening right he is listening
carefully he's trying to hear sounds
listen so you listen to something he's
probably listening to music too listen
listen listen carefully okay if I'm
telling you something listen carefully
but we listen to different things to
listen to try to hear sounds carefully
listen okay another one to stay until
something happens
so you're staying in one place and
you're what
until something happens you're staying
until something happens what are you
doing you are waiting so if you before
you cross the street
wait don't just cross the street stop
wait look both sides then cross the
street what it's safe but you should
wait before crossing the street to stay
stay here don't move wait until
something happens it's safe okay then we
can cross but you should wait first to
stay until something happens
wait

## toggle timestamps Transcript

00:00
[Music]
00:05
we have to learn some vocabulary
00:08
now the first vocabulary word we're
00:11
going to listen to or learn is this one
00:15
here this is a picture of a place in
00:19
front of your house what is this it's a
00:23
bell outside the door you press it it
00:27
goes ding dong right ding dong what is
00:32
that it's a kind of Bell and it's at the
00:35
door it's at the door and it's a bell
00:38
it's a doorbell that's pretty easy it's
00:43
a door bell it's outside the door and it
00:47
is about will you push it ding dong
00:49
sounds like a bell so it's a door bell
00:52
in front of your house you have a
00:55
doorbell when somebody visits you they
00:58
press the door bell so doorbell doorbell
01:04
it's two words that make one word door
01:08
and bell doorbell very easy okay the
01:12
next word what is this
01:14
this is very old right probably you have
01:17
a small one in your pocket something you
01:21
use to talk to your friend so you want
01:26
to talk to your friend you take this out
01:29
of your pocket or your backpack and you
01:32
can call your friend on it and you can
01:35
talk to your friend what is it what is
01:38
it called it's a telephone telephone
01:43
telephone telephone three syllables or
01:48
three sounds telephone telephone
01:52
telephone very easy of course this is a
01:55
very old telephone right we don't use
01:58
those anymore we use the very small or
02:00
sometimes big pocket our cell phones and
02:04
we but it's a telephone it's basically a
02:07
telephone that we use to talk with our
02:10
friend
02:10
okay the next word what's this this
02:13
looks very interesting doesn't it this
02:16
is a clock so it's a type of clock right
02:19
we tell time but look at this what are
02:22
these things here those are bells again
02:25
another another type of Bell right and
02:28
at a certain time those bells sound did
02:32
it it editing right so what is this it's
02:35
a clock that wakes you up in the morning
02:39
maybe you use this maybe you use your
02:43
cell phone probably you use your cell
02:45
phone but a long time ago when I was
02:48
younger we used one of these to wake up
02:51
in the morning what is it called it's an
02:55
alarm clock so it's a clock right it's a
02:59
clock what kind of clock alarm alarm
03:03
means make a big sound alarm did it
03:05
editing right so an alarm clock is what
03:09
we use to wake up in the morning we need
03:12
a very loud sound to wake up right some
03:17
people need a really really loud sound
03:20
to wake up some people they sleep that
03:24
it editing they keep sleeping okay
03:26
so you need a very loud alarm clock to
03:30
wake up in the morning alarm clock okay
03:34
our next word wow this looks very
03:37
interesting right unhappy he looks very
03:41
sad right because you are alone if he is
03:47
alone he's very sad right it almost
03:50
looks like a human right but it looks
03:52
like a baby gorilla so very interesting
03:54
picture but he looks sad because he's
03:57
what he's alone so he is lonely if you
04:03
are alone you are by yourself you are by
04:08
your self there are no friends no family
04:14
around you you are by yourself you are
04:17
alone how do you feel you are lonely
04:23
lonely be careful with el la lonely we
04:28
have two elves lonely lonely lonely so
04:34
hopefully I hope you don't feel lonely
04:37
but sometimes we feel lonely because we
04:41
are alone there are no friends or family
04:43
around us in that time we feel lonely
04:48
okay next
04:50
somewhere where only animals live only
04:55
animals no humans so it's in nature some
05:00
place where there are no humans and
05:03
animals live without humans they don't
05:08
live with humans what do we call this
05:11
place we say it's in the wild in the
05:14
wild the wild is a place where there are
05:18
no humans no villages no towns no roads
05:24
no humans around just animals only
05:28
animals live there in the wild wild of
05:33
you is like wow what wild and then we
05:38
have LD wild uh duck is when you jaw
05:43
drops duck wild wild so in the wild okay
05:50
the next word giving help so if
05:52
something is giving help what are they
05:55
doing what do we say for this word we
05:57
say help full because it's like full
06:01
right this word here full to ELLs means
06:04
you have a lot of it's full right but we
06:07
only have one el here when we put it as
06:09
an adjective helpful helpful if somebody
06:13
or some thing is helpful they are giving
06:18
help so help full helpful helpful that
06:23
is the word that means you are giving
06:26
help okay here's another word this is a
06:29
very funny picture right very cute right
06:32
we have a small animal on top of the
06:35
girl
06:35
had it's her pet right a small animal
06:39
that lives with you and I just said the
06:41
word right so a small animal that lives
06:44
with you it can be a gerbil it can be a
06:47
hamster it can be a dog it can be a cat
06:51
it can be a bird but it's a small animal
06:54
that lives with you not in the wild but
06:57
in your house we call that of course a
06:59
pet I said that before right
07:01
do you have a pet many houses have a pet
07:05
like a dog or a cat very common pets but
07:09
also a hamster you could say hamster a
07:13
hamster is also a very common type of
07:17
pets they're fun aren't they they're
07:19
they're very cute and also they make us
07:23
so we are not lonely we have some thing
07:26
to play with or something to love and to
07:30
play with okay what's this guy doing
07:33
that's crazy what is he doing he's it's
07:36
exciting and not boring so this kid is
07:40
exciting right it's kind of exciting we
07:42
look at him more wow what is he doing
07:43
with his eyes that's very strange and
07:46
his his smile is very funny too right
07:49
because he's missing a tooth he's
07:51
missing a tooth so if something is
07:54
exciting not boring we say it is fun
07:58
it's fun let's do something for fun
08:01
let's have fun we want to be excited we
08:06
don't want to be bored it's fun let's
08:08
have fun okay here this man he cannot
08:15
see not able to see we know that very
08:20
quickly because people who are like him
08:24
have a long stick and it's this color
08:28
white and red and they use it so they
08:31
can feel where they are going because
08:33
they cannot see what do we call this
08:36
situation we say blind this person is
08:40
blind
08:41
it's unfortunate it's too bad but
08:44
sometimes this happens so this person is
08:48
blind they
08:49
cannot see blind okay so the word is
08:53
blind okay now to move from one side to
08:59
the other so you're on one side of the
09:03
street and you want to go to the other
09:05
side of the street or river or anything
09:09
you want to go from one side you want to
09:11
go to the other side what do we say we
09:15
say cross I want to cross the street
09:19
cross is a verb right so cross the
09:24
street cross the street let's cross the
09:33
street we want to cross the street so
09:38
use cross as a verb
09:40
let's go across that's different
09:43
let's cross the street if you use a
09:46
cross that's a different word cross is
09:48
the word that we use for a verb let's
09:51
cross the street
09:52
you should cross the street here not
09:55
here you should cross here okay so cross
09:59
as a verb let's cross the street okay
10:03
this is another verb to try to try to
10:07
hear sounds carefully so it's very cute
10:12
isn't he with the little feet okay but
10:13
look at these big headphones by the way
10:16
these are head phones they're very big
10:21
for this little boy really big and he's
10:24
listening right he is listening
10:27
carefully he's trying to hear sounds
10:30
listen so you listen to something he's
10:34
probably listening to music too listen
10:39
listen listen carefully okay if I'm
10:43
telling you something listen carefully
10:46
but we listen to different things to
10:48
listen to try to hear sounds carefully
10:52
listen okay another one to stay until
10:57
something happens
10:59
so you're staying in one place and
11:02
you're what
11:03
until something happens you're staying
11:06
until something happens what are you
11:08
doing you are waiting so if you before
11:13
you cross the street
11:15
wait don't just cross the street stop
11:18
wait look both sides then cross the
11:22
street what it's safe but you should
11:24
wait before crossing the street to stay
11:27
stay here don't move wait until
11:32
something happens it's safe okay then we
11:35
can cross but you should wait first to
11:38
stay until something happens
11:41
wait