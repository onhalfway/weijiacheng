# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
and let's look at the words for this
lesson let's learn the words for this
lesson the first word what do we see
here this is an interesting picture
isn't it we have little pieces of wood
standing up right and we have somebody's
going to push it right and that's going
to hit that and they're all gonna fall
over so we're gonna make something
happen to make something happen we're
gonna cause one to hit the other and the
other and the other and I just use the
word there right to cause cause so if
you cause something that means you made
it happen if you cause all of these to
fall down right you made it happen to
cause something to happen the wit the
tornado caused the car to fly away okay
so something makes another thing happen
to cause okay next word this is a type
of weather right this this little girl
all right she's in her coat she's in her
knit hat and look it's very strong the
wind weather with fast-moving air the
air is moving pastor very quickly in
this case what is the weather we say the
weather is windy windy it's very windy
so the wind is strong it's windy okay
the next one strong dangerous weather
strong dangerous weather of course we
talked about tornado but we're looking
for not just tornado but any type of
weather any type of weather that is
dangerous or strong we could say storm
it is a storm so a tornado is a type of
storm but there are other types of
weather for example it rains a lot and
there's lightning and thunder the
a storm if it snows a lot too much snow
your parents can't drive their car
nobody can move everybody stays inside
that's a storm a snow storm
so some storms are very big and caused a
lot of water rain or snow to fall down
very quickly and we call those storms
okay I taught you this word before do
you remember seeing this picture before
right this is dangerous bright light
from storms okay
dangerous bright light from storms we
say it's lightning just two sounds
lightning lightning it's lightning and
of course with lightning I also said
something else with lightning you also
hear thunder right so thunder and then
after or actually before thunder you see
the lightning you see the flash and then
a little bit later you hear the thunder
so thunder and lightning very common
thing in a storm to experience
okay so lightning the next word oh my
gosh look what happened it's terrible
right there was a strong wind may be a
very big storm very strong winds and it
pushed this tree over onto this house
that's terrible
these poor people who live there right
to make into nothing what did this tree
do it made the house into nothing well
maybe they can save it but you could say
destroy the tree destroyed the house
sometimes in a flood there's a lot of
water the water will come and it might
bury your car under the water and you
can't use your car anymore your car is
destroyed
okay so storms are very dangerous they
caused a lot of damage
storms destroy homes cars many things
that are destroyed in a storm
okay the next week we saw this picture
before right the people with no face
okay let's take a look of course but
we're looking at the water again a lot
of water that goes onto land
so usually the water is in the river or
it's in a lake but if it there's a lot
of water comes from the sky in rain or
in snow then maybe that water will come
on to the land and cover everywhere and
of course we say that is a flood now by
the way flood can be used as a noun for
example there is a flood there is a
flood that's a noun there is a flood but
flood can also be used as a verb the
river flooded over okay
or you could also say the town flooded
that means the the town was covered in
water so we can use flood as a noun
there is a flood or a verb the river
flooded over the river got too big and
it flooded the surrounding area so we
can use flood as a noun or as a verb
okay next one to begin these boys are
running in a race right at the start of
the race right at the start of the race
they begin to begin means to start okay
to start okay here we have another word
this is an interesting picture all these
pieces of wood seem to have fallen down
maybe they they they made something like
a tower before but they fell down so to
make something fall down this is a kind
of a special word it's a little bit of a
difficult word it is to topple to topple
pronunciation top pull top Bowl to
topple if something falls over
especially something that's very large
very big and tall it
fall over it will topple so imagine if
you cut down a tree the tree falls over
we say the tree topples over buildings
might topple over okay so to top will
mean something very tall falls over well
he looks kind of interesting does he
look like me maybe okay
he's a weatherman right now news that
tells us the weather news that tells us
the weather you want to know about
tomorrow will it be sunny will it be
windy is there a storm coming so you
want news that tells us the weather what
do you want to look at you want to look
at the weather report this is the news
that tells you about the weather okay
here we have an object here it's a very
colorful object they're not all like
this maybe I'm sure you have one of
these at home it's a tool a tool is
something we use right a tool we hold we
hold in our hand to keep the rain off
it's raining outside you don't want to
get wet so you use one of these to keep
the rain off you want to stay dry right
you don't want to get wet you want to
stay dry you want to keep the rain off
what is it Busan in Korean umbrella in
English okay
so I'm sure you have a Busan Jeep a Jeep
a moose on a sail
I'm not sure if my Korean is that good
but do you have an umbrella at home I'm
sure you do okay so umbrella okay now in
the summertime it's really hot isn't it
if you're in the park and you're out in
the Sun the Sun is hitting you all it's
so hot and you sweat down money hail
right Oh
normal normal topsoil right I'm very hot
so it's too hot in
son you want to but you don't want to go
inside a building you want to enjoy the
park so maybe you go under a tree or
maybe there's an umbrella a big umbrella
so you want to go to an outside place
with no Sun like these ducks are smart
right they're not in the sunlight they
went in the dark area under the tree a
place with no Sun what is this dark area
it's a little cooler there right we say
it's the shade shade so if you're
outside you're in a park or you're
playing soccer and the Sun is too strong
maybe you want to go in the shade go in
the shade in the shape because the shade
is cooler than in the Sun you don't have
the Sun hitting you directly so it's a
little cooler in the shade it's a little
cooler in the shade okay
numb of the next word to move air now we
talked about windy right this picture
looks like it's windy but windy is an
adjective it is windy right it is windy
outside
that's an adjutant but we're looking for
a verb here to move air why is it windy
what is the action what's happening well
we're looking for the verb blow when
when the wind blows right then the air
moves we can blow right you can put your
hand in front of your mouth you can feel
the air moving I am blowing right blow
blew blown this is an irregular verb so
it changes according to how we use it
when we use it in now to blow that means
right now blue past tense blown past
participle have
right blow blew blown blow blew blown so
in English I'm sorry some words you have
to some verbs you have to know the
different forms when you use them in
different time periods
okay so blow

## toggle timestamps Transcript

00:00
[Music]
00:04
and let's look at the words for this
00:08
lesson let's learn the words for this
00:10
lesson the first word what do we see
00:13
here this is an interesting picture
00:15
isn't it we have little pieces of wood
00:18
standing up right and we have somebody's
00:21
going to push it right and that's going
00:23
to hit that and they're all gonna fall
00:25
over so we're gonna make something
00:27
happen to make something happen we're
00:30
gonna cause one to hit the other and the
00:33
other and the other and I just use the
00:34
word there right to cause cause so if
00:38
you cause something that means you made
00:42
it happen if you cause all of these to
00:45
fall down right you made it happen to
00:48
cause something to happen the wit the
00:53
tornado caused the car to fly away okay
00:59
so something makes another thing happen
01:02
to cause okay next word this is a type
01:07
of weather right this this little girl
01:10
all right she's in her coat she's in her
01:12
knit hat and look it's very strong the
01:17
wind weather with fast-moving air the
01:20
air is moving pastor very quickly in
01:24
this case what is the weather we say the
01:27
weather is windy windy it's very windy
01:32
so the wind is strong it's windy okay
01:37
the next one strong dangerous weather
01:41
strong dangerous weather of course we
01:44
talked about tornado but we're looking
01:46
for not just tornado but any type of
01:49
weather any type of weather that is
01:52
dangerous or strong we could say storm
01:56
it is a storm so a tornado is a type of
02:01
storm but there are other types of
02:04
weather for example it rains a lot and
02:08
there's lightning and thunder the
02:11
a storm if it snows a lot too much snow
02:15
your parents can't drive their car
02:18
nobody can move everybody stays inside
02:21
that's a storm a snow storm
02:25
so some storms are very big and caused a
02:28
lot of water rain or snow to fall down
02:32
very quickly and we call those storms
02:36
okay I taught you this word before do
02:39
you remember seeing this picture before
02:41
right this is dangerous bright light
02:44
from storms okay
02:46
dangerous bright light from storms we
02:48
say it's lightning just two sounds
02:52
lightning lightning it's lightning and
02:55
of course with lightning I also said
02:57
something else with lightning you also
03:00
hear thunder right so thunder and then
03:05
after or actually before thunder you see
03:08
the lightning you see the flash and then
03:10
a little bit later you hear the thunder
03:13
so thunder and lightning very common
03:17
thing in a storm to experience
03:21
okay so lightning the next word oh my
03:25
gosh look what happened it's terrible
03:27
right there was a strong wind may be a
03:31
very big storm very strong winds and it
03:35
pushed this tree over onto this house
03:38
that's terrible
03:40
these poor people who live there right
03:42
to make into nothing what did this tree
03:45
do it made the house into nothing well
03:49
maybe they can save it but you could say
03:52
destroy the tree destroyed the house
03:57
sometimes in a flood there's a lot of
03:59
water the water will come and it might
04:02
bury your car under the water and you
04:05
can't use your car anymore your car is
04:08
destroyed
04:09
okay so storms are very dangerous they
04:13
caused a lot of damage
04:15
storms destroy homes cars many things
04:21
that are destroyed in a storm
04:23
okay the next week we saw this picture
04:26
before right the people with no face
04:28
okay let's take a look of course but
04:31
we're looking at the water again a lot
04:33
of water that goes onto land
04:36
so usually the water is in the river or
04:39
it's in a lake but if it there's a lot
04:42
of water comes from the sky in rain or
04:45
in snow then maybe that water will come
04:48
on to the land and cover everywhere and
04:51
of course we say that is a flood now by
04:54
the way flood can be used as a noun for
05:01
example there is a flood there is a
05:08
flood that's a noun there is a flood but
05:12
flood can also be used as a verb the
05:17
river flooded over okay
05:25
or you could also say the town flooded
05:28
that means the the town was covered in
05:30
water so we can use flood as a noun
05:32
there is a flood or a verb the river
05:35
flooded over the river got too big and
05:37
it flooded the surrounding area so we
05:40
can use flood as a noun or as a verb
05:43
okay next one to begin these boys are
05:48
running in a race right at the start of
05:51
the race right at the start of the race
05:54
they begin to begin means to start okay
05:57
to start okay here we have another word
06:02
this is an interesting picture all these
06:04
pieces of wood seem to have fallen down
06:07
maybe they they they made something like
06:10
a tower before but they fell down so to
06:13
make something fall down this is a kind
06:16
of a special word it's a little bit of a
06:18
difficult word it is to topple to topple
06:24
pronunciation top pull top Bowl to
06:28
topple if something falls over
06:31
especially something that's very large
06:35
very big and tall it
06:37
fall over it will topple so imagine if
06:40
you cut down a tree the tree falls over
06:43
we say the tree topples over buildings
06:46
might topple over okay so to top will
06:50
mean something very tall falls over well
06:55
he looks kind of interesting does he
06:57
look like me maybe okay
07:00
he's a weatherman right now news that
07:03
tells us the weather news that tells us
07:07
the weather you want to know about
07:10
tomorrow will it be sunny will it be
07:14
windy is there a storm coming so you
07:17
want news that tells us the weather what
07:21
do you want to look at you want to look
07:24
at the weather report this is the news
07:28
that tells you about the weather okay
07:33
here we have an object here it's a very
07:37
colorful object they're not all like
07:39
this maybe I'm sure you have one of
07:41
these at home it's a tool a tool is
07:45
something we use right a tool we hold we
07:49
hold in our hand to keep the rain off
07:53
it's raining outside you don't want to
07:56
get wet so you use one of these to keep
08:00
the rain off you want to stay dry right
08:06
you don't want to get wet you want to
08:08
stay dry you want to keep the rain off
08:11
what is it Busan in Korean umbrella in
08:16
English okay
08:18
so I'm sure you have a Busan Jeep a Jeep
08:21
a moose on a sail
08:22
I'm not sure if my Korean is that good
08:24
but do you have an umbrella at home I'm
08:26
sure you do okay so umbrella okay now in
08:32
the summertime it's really hot isn't it
08:35
if you're in the park and you're out in
08:39
the Sun the Sun is hitting you all it's
08:41
so hot and you sweat down money hail
08:43
right Oh
08:44
normal normal topsoil right I'm very hot
08:49
so it's too hot in
08:51
son you want to but you don't want to go
08:53
inside a building you want to enjoy the
08:56
park so maybe you go under a tree or
08:58
maybe there's an umbrella a big umbrella
09:01
so you want to go to an outside place
09:03
with no Sun like these ducks are smart
09:08
right they're not in the sunlight they
09:12
went in the dark area under the tree a
09:15
place with no Sun what is this dark area
09:18
it's a little cooler there right we say
09:22
it's the shade shade so if you're
09:25
outside you're in a park or you're
09:28
playing soccer and the Sun is too strong
09:30
maybe you want to go in the shade go in
09:35
the shade in the shape because the shade
09:41
is cooler than in the Sun you don't have
09:46
the Sun hitting you directly so it's a
09:50
little cooler in the shade it's a little
09:53
cooler in the shade okay
09:57
numb of the next word to move air now we
10:02
talked about windy right this picture
10:04
looks like it's windy but windy is an
10:07
adjective it is windy right it is windy
10:11
outside
10:12
that's an adjutant but we're looking for
10:14
a verb here to move air why is it windy
10:18
what is the action what's happening well
10:22
we're looking for the verb blow when
10:25
when the wind blows right then the air
10:30
moves we can blow right you can put your
10:35
hand in front of your mouth you can feel
10:39
the air moving I am blowing right blow
10:43
blew blown this is an irregular verb so
10:48
it changes according to how we use it
10:52
when we use it in now to blow that means
10:55
right now blue past tense blown past
10:59
participle have
11:00
right blow blew blown blow blew blown so
11:06
in English I'm sorry some words you have
11:10
to some verbs you have to know the
11:11
different forms when you use them in
11:15
different time periods
11:17
okay so blow