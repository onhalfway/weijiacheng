# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
say that they are what a very young
child zero to one year old all very cute
right
sleeping all right very cute what do we
call this person we call this person a
baby baby right 0 to 1 year-old zero is
interesting in American age when a baby
is born the first day we say they're
like zero years old they're just 1 day
old
two days old okay then we go 2 months
the baby is 3 months old
6 months old up to a year but before
there there have been in the world for 1
year we say that they are a baby
and by the way baby how do we say many
babies we say babies IES so the Y
changes to ie and then we put the S
babies babies so one baby many babies
Hey okay so that's the first stage in a
person's life
the first step the first step or the
first stage in a person's life and we're
talking about steps or stages in
people's lives the first step is baby
what's the next one the next step is a
child who is learning to walk a child
who is learning to walk from one to
three years old they are learning to
walk they can't walk very well yet
they're kind of going like this right
they're learning to walk there they're
like this and when they do this we say
they're kind of toddling right they are
a toddler toddler is kind of the idea of
you know a baby
wobbling right like this they're very
careful they don't walk very well
they're not like a mad robot right maybe
I'm not doing that right but you know
they're toddling right they're a toddler
a person who toddles a person who
doesn't walk very well yeah
they're still learning they're learning
to walk one two three years old they
would call those people a toddler
because they're learning how to walk
they haven't been able to walk well on
their own yet before they walk what do
people do before they walk like babies
they will crawl crawl is like this on
all arms and legs that's crawling after
crawling people will walk but when
they're learning to walk they are a
toddler okay a boy or girl between 3 and
12 years old what do we call that person
we use that word actually on the
previous slide when we talked about a
toddler of course we talk about that
person that person is a child a child
between 3 and 12 years old maybe some of
you are three between between 3 and 12
years old I don't think any of you are 3
years old you don't understand me but
maybe if some of you are maybe 10 or 11
or even 12 years old then you can be
called a child by the way in English
what is the plural of children if you
have one child but many do we say
child's no don't say child's say
children children many children at your
school there are many children in your
class there are many children okay so
one child many children now after a
person after 12 years old right they
become 13 14 15 they become one of these
people are in this stage a boy or girl
between 13 and 19 years old 13 and 19
years old so what do we call them of
course I'm saying it teen because 13 14
15 16 17 18 and 19 all of these words
and in
tene right so we say that these people
are called teens now you might also call
them teenagers teen agers teenagers
that's another word for teens okay
teenager or teenagers teen is the same
word okay now after the teenage years
right this isn't quite a lot after this
a long time after okay a man or woman
over 20 because after 19 then they are
20 19 then 20 20 years old that person
is now what what do we call those people
we call those people and adult adult
adults are no longer children they are
no longer teens they are adults they are
independent they are responsible for
themselves they can make their own
decisions they don't depend on their
parents anymore they are independent
they are adults a man or woman over 20
years old now these are older adults
right these are getting a little bit
older than adults of course you do have
different stages in adults you have
young adult middle-aged adult or senior
citizen let me write those down for you
very quickly just a little extra young
adult you can say a young adult usually
somebody who is in their 20s young adult
then after somebody gets to be about 40
years old
then you could say middle-aged middle
middle aged okay let me see if middle DD
that's a DD em i DD le aged that's an A
a GED middle aged and after middle age
maybe around 60 after 60 years old we
can say senior senior sit - Zen okay but
all of these people all of them are
adults okay so you also have different
stages in the adult stage okay let's
move on to get bigger and
Haller so we've just talked about baby
toddler child teen and adult this
process this change what do we say
what's going on here to get bigger
what's the verb we use we use of course
the verb grow to grow somebody who gets
bigger right they get bigger and they
get taller as they go along it's very
interesting the baby is so small when
you see babies wow they're so small
their fingers and their toes are so
small but they get much bigger right
they grow into a full adult so they grow
bigger and they grow taller they grow
what are the different forms of the verb
grow of course we have grow grew grown
right grow grew grown it's an irregular
verb you have to remember the different
forms for the different verb tenses grow
grew grown okay next we have this is
another verb to rest with your eyes
closed at night this is what you should
do
don't play computer games right get in
your bed and do this what is this right
what are you doing you need this
especially when you're growing when
you're young you need a lot of this what
is this person doing this person is
sleeping so she is sleeping get sleep go
to bed get some sleep or go to sleep
right sleep at night what are the
different verb forms of to sleep
we have sleep slept slept so this is the
same for past tense and present present
participle sleep slept slept sleep slept
slept okay that's another irregular verb
sleep slept slept to rest with your eyes
closed usually we do it at night but
sometimes we do it during the day for a
short time
if you sleep during the day for a short
time that is take a nap take a nap
that's a short sleep during the day
take a nap maybe you're tired take a nap
for 30 minutes or an hour but at night
you sleep at least eight hours usually
people sleep for eight hours
some people less some people more right
but don't play video games all night
it's important to get some sleep
okay now to begin life we're talking
about a baby of course the baby there's
a point when the baby comes into the
world that is the time that the baby we
say is beginning life of course babies
begin life in their mothers wombs in
their mothers bodies but the moment the
baby comes out into the world we have a
special verb for that what do we say we
say to be born to be born to begin life
when were you born when were you born
okay that's the very common question
when were you born
you could say well I was born in 1980
something or I was born in 1980 some of
you might have been born in 2000
something right maybe 2000 or 2001 when
were you born
what year were you born okay what year
did you come into the world born okay
now this is a verb that we talked about
before actually to go by moving your
feet right toddlers are learning how to
do this toddlers remember I talked about
this toddlers are learning how to do
this what is it it is of course to walk
to walk right to move by moving your
feet now of course walk
you could also say run but run is to
move fast or to go fast by moving your
feet to just go normally normally people
walk they don't run so to go by moving
your feet you walk okay if you go fast
that's run okay to say things so you're
with your friends right and you say
things to your friends they say
something
to you in return so what are they doing
of course we say they are talking to
talk talked talked talked okay talk to
talk with people of course talk is a
regular verb so we don't have to worry
about the different forms right talk
talk to talk okay so these people are
talking to say things to each other
let's talk okay or they are talking to
each other
okay what's their next word our next
word is another verb to write to make to
make pictures with a pen or pencil you
probably do this a lot even at school
you do this what are you doing you're
making pictures right maybe a house
people or landscape with trees maybe
fish or animals but you what are you
doing you're making pictures you are
drawing - draw - draw means to make
pictures with a pen or pencil now draw
is not a regular verb it's an irregular
verb so what are the different verb
forms what are the different forms of
this firm we have draw drew drawn draw
drew drawn so this verb draw drew drawn
okay so to draw is to make pictures with
a pen or a pencil also you could yeah
with those pens or pencils that's
drawing if you use a paintbrush then
you're not drawing you're painting okay
so that's different
okay paintbrush that's painting but
pencil or pen then you're drawing okay
that's an interesting point
okay very nice to look at whoa look at
this key up G all right cap G a little
cat is very what we say very cute a cat
is cute of course but not just a cat
there are many things that are cute like
for example we're talking about babies
babies are very cute right when they're
not crying if they're not that's not
cute but usually babies right and they
make the little faces that's very cute
right so we say very cute very nice to
look at it's very nice to look at
something that is cute it's also very
interest
thing right Jenny soil right but it's
also very cute
yep geo kept she Yeah Yeah right
Oh cue while right that's very cute okay

## toggle timestamps Transcript

00:00
[Music]
00:05
say that they are what a very young
00:08
child zero to one year old all very cute
00:12
right
00:12
sleeping all right very cute what do we
00:15
call this person we call this person a
00:18
baby baby right 0 to 1 year-old zero is
00:24
interesting in American age when a baby
00:28
is born the first day we say they're
00:31
like zero years old they're just 1 day
00:34
old
00:35
two days old okay then we go 2 months
00:38
the baby is 3 months old
00:40
6 months old up to a year but before
00:43
there there have been in the world for 1
00:46
year we say that they are a baby
00:48
and by the way baby how do we say many
00:52
babies we say babies IES so the Y
00:57
changes to ie and then we put the S
01:01
babies babies so one baby many babies
01:06
Hey okay so that's the first stage in a
01:10
person's life
01:11
the first step the first step or the
01:15
first stage in a person's life and we're
01:19
talking about steps or stages in
01:21
people's lives the first step is baby
01:25
what's the next one the next step is a
01:29
child who is learning to walk a child
01:34
who is learning to walk from one to
01:37
three years old they are learning to
01:40
walk they can't walk very well yet
01:42
they're kind of going like this right
01:43
they're learning to walk there they're
01:46
like this and when they do this we say
01:49
they're kind of toddling right they are
01:51
a toddler toddler is kind of the idea of
01:55
you know a baby
01:55
wobbling right like this they're very
01:58
careful they don't walk very well
02:01
they're not like a mad robot right maybe
02:03
I'm not doing that right but you know
02:04
they're toddling right they're a toddler
02:08
a person who toddles a person who
02:11
doesn't walk very well yeah
02:13
they're still learning they're learning
02:15
to walk one two three years old they
02:18
would call those people a toddler
02:20
because they're learning how to walk
02:22
they haven't been able to walk well on
02:25
their own yet before they walk what do
02:27
people do before they walk like babies
02:32
they will crawl crawl is like this on
02:35
all arms and legs that's crawling after
02:40
crawling people will walk but when
02:42
they're learning to walk they are a
02:44
toddler okay a boy or girl between 3 and
02:50
12 years old what do we call that person
02:52
we use that word actually on the
02:54
previous slide when we talked about a
02:57
toddler of course we talk about that
02:59
person that person is a child a child
03:02
between 3 and 12 years old maybe some of
03:07
you are three between between 3 and 12
03:10
years old I don't think any of you are 3
03:12
years old you don't understand me but
03:15
maybe if some of you are maybe 10 or 11
03:18
or even 12 years old then you can be
03:21
called a child by the way in English
03:24
what is the plural of children if you
03:27
have one child but many do we say
03:30
child's no don't say child's say
03:33
children children many children at your
03:38
school there are many children in your
03:41
class there are many children okay so
03:45
one child many children now after a
03:48
person after 12 years old right they
03:52
become 13 14 15 they become one of these
03:57
people are in this stage a boy or girl
03:59
between 13 and 19 years old 13 and 19
04:07
years old so what do we call them of
04:10
course I'm saying it teen because 13 14
04:15
15 16 17 18 and 19 all of these words
04:25
and in
04:26
tene right so we say that these people
04:29
are called teens now you might also call
04:32
them teenagers teen agers teenagers
04:39
that's another word for teens okay
04:42
teenager or teenagers teen is the same
04:46
word okay now after the teenage years
04:49
right this isn't quite a lot after this
04:53
a long time after okay a man or woman
04:56
over 20 because after 19 then they are
04:59
20 19 then 20 20 years old that person
05:04
is now what what do we call those people
05:06
we call those people and adult adult
05:10
adults are no longer children they are
05:13
no longer teens they are adults they are
05:15
independent they are responsible for
05:18
themselves they can make their own
05:21
decisions they don't depend on their
05:24
parents anymore they are independent
05:26
they are adults a man or woman over 20
05:30
years old now these are older adults
05:32
right these are getting a little bit
05:34
older than adults of course you do have
05:36
different stages in adults you have
05:38
young adult middle-aged adult or senior
05:43
citizen let me write those down for you
05:45
very quickly just a little extra young
05:47
adult you can say a young adult usually
05:51
somebody who is in their 20s young adult
05:54
then after somebody gets to be about 40
05:57
years old
05:58
then you could say middle-aged middle
06:02
middle aged okay let me see if middle DD
06:09
that's a DD em i DD le aged that's an A
06:13
a GED middle aged and after middle age
06:17
maybe around 60 after 60 years old we
06:20
can say senior senior sit - Zen okay but
06:28
all of these people all of them are
06:31
adults okay so you also have different
06:34
stages in the adult stage okay let's
06:37
move on to get bigger and
06:40
Haller so we've just talked about baby
06:42
toddler child teen and adult this
06:45
process this change what do we say
06:49
what's going on here to get bigger
06:51
what's the verb we use we use of course
06:55
the verb grow to grow somebody who gets
06:58
bigger right they get bigger and they
07:01
get taller as they go along it's very
07:04
interesting the baby is so small when
07:06
you see babies wow they're so small
07:08
their fingers and their toes are so
07:09
small but they get much bigger right
07:12
they grow into a full adult so they grow
07:14
bigger and they grow taller they grow
07:17
what are the different forms of the verb
07:20
grow of course we have grow grew grown
07:24
right grow grew grown it's an irregular
07:29
verb you have to remember the different
07:31
forms for the different verb tenses grow
07:35
grew grown okay next we have this is
07:40
another verb to rest with your eyes
07:43
closed at night this is what you should
07:47
do
07:47
don't play computer games right get in
07:50
your bed and do this what is this right
07:54
what are you doing you need this
07:55
especially when you're growing when
07:57
you're young you need a lot of this what
08:00
is this person doing this person is
08:02
sleeping so she is sleeping get sleep go
08:06
to bed get some sleep or go to sleep
08:10
right sleep at night what are the
08:13
different verb forms of to sleep
08:16
we have sleep slept slept so this is the
08:21
same for past tense and present present
08:24
participle sleep slept slept sleep slept
08:27
slept okay that's another irregular verb
08:30
sleep slept slept to rest with your eyes
08:33
closed usually we do it at night but
08:36
sometimes we do it during the day for a
08:39
short time
08:39
if you sleep during the day for a short
08:42
time that is take a nap take a nap
08:49
that's a short sleep during the day
08:53
take a nap maybe you're tired take a nap
08:56
for 30 minutes or an hour but at night
08:58
you sleep at least eight hours usually
09:02
people sleep for eight hours
09:03
some people less some people more right
09:06
but don't play video games all night
09:08
it's important to get some sleep
09:10
okay now to begin life we're talking
09:14
about a baby of course the baby there's
09:17
a point when the baby comes into the
09:19
world that is the time that the baby we
09:22
say is beginning life of course babies
09:24
begin life in their mothers wombs in
09:27
their mothers bodies but the moment the
09:30
baby comes out into the world we have a
09:32
special verb for that what do we say we
09:35
say to be born to be born to begin life
09:41
when were you born when were you born
09:46
okay that's the very common question
09:48
when were you born
09:55
you could say well I was born in 1980
10:00
something or I was born in 1980 some of
10:04
you might have been born in 2000
10:06
something right maybe 2000 or 2001 when
10:10
were you born
10:12
what year were you born okay what year
10:14
did you come into the world born okay
10:18
now this is a verb that we talked about
10:21
before actually to go by moving your
10:24
feet right toddlers are learning how to
10:27
do this toddlers remember I talked about
10:30
this toddlers are learning how to do
10:32
this what is it it is of course to walk
10:35
to walk right to move by moving your
10:39
feet now of course walk
10:42
you could also say run but run is to
10:45
move fast or to go fast by moving your
10:48
feet to just go normally normally people
10:51
walk they don't run so to go by moving
10:53
your feet you walk okay if you go fast
10:57
that's run okay to say things so you're
11:02
with your friends right and you say
11:04
things to your friends they say
11:06
something
11:07
to you in return so what are they doing
11:09
of course we say they are talking to
11:12
talk talked talked talked okay talk to
11:16
talk with people of course talk is a
11:18
regular verb so we don't have to worry
11:20
about the different forms right talk
11:21
talk to talk okay so these people are
11:25
talking to say things to each other
11:27
let's talk okay or they are talking to
11:31
each other
11:32
okay what's their next word our next
11:34
word is another verb to write to make to
11:38
make pictures with a pen or pencil you
11:42
probably do this a lot even at school
11:45
you do this what are you doing you're
11:47
making pictures right maybe a house
11:49
people or landscape with trees maybe
11:53
fish or animals but you what are you
11:56
doing you're making pictures you are
11:58
drawing - draw - draw means to make
12:03
pictures with a pen or pencil now draw
12:06
is not a regular verb it's an irregular
12:09
verb so what are the different verb
12:11
forms what are the different forms of
12:13
this firm we have draw drew drawn draw
12:19
drew drawn so this verb draw drew drawn
12:24
okay so to draw is to make pictures with
12:27
a pen or a pencil also you could yeah
12:31
with those pens or pencils that's
12:33
drawing if you use a paintbrush then
12:36
you're not drawing you're painting okay
12:38
so that's different
12:39
okay paintbrush that's painting but
12:42
pencil or pen then you're drawing okay
12:45
that's an interesting point
12:46
okay very nice to look at whoa look at
12:50
this key up G all right cap G a little
12:53
cat is very what we say very cute a cat
12:57
is cute of course but not just a cat
12:59
there are many things that are cute like
13:01
for example we're talking about babies
13:03
babies are very cute right when they're
13:05
not crying if they're not that's not
13:08
cute but usually babies right and they
13:11
make the little faces that's very cute
13:13
right so we say very cute very nice to
13:16
look at it's very nice to look at
13:18
something that is cute it's also very
13:20
interest
13:20
thing right Jenny soil right but it's
13:22
also very cute
13:23
yep geo kept she Yeah Yeah right
13:27
Oh cue while right that's very cute okay