# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
if we think about that this is a home
right a place where something lives is
of course a home many homes are made
from bricks and bricks are made from
soil or dirt we live in dirt homes is it
dirty
no it's clean because of the way we make
bricks that's what we're talking about
how different homes are made from bricks
and of course we're going to look at not
just this word but many other words for
this lesson let's go for number two
the second word to cook in an oven this
of course in the background that's an
oven right you put food usually you put
food in an oven lots of heat and you get
a nice loaf of bread or cake that comes
out and of course this means to bake
when you put food in the oven lots of
heat goes on it and you bake it so you
bake a cake bake a loaf of bread
something like that so to bake here of
course is what we were talking about
before right we just use this word it's
actually they say a space for cooking at
a high heat a space is on the inside of
course this is a device or appliance
that you find in your kitchen appliance
there are many appliances in your
kitchen one appliance of course is this
thing which we just talked about that's
an oven an oven by the way just for your
information this part is the oven this
part
don't say oven this part is stove the
top is the stove the middle part is the
oven okay next one
Wow big house right looks like a castle
right very strong and lasting lasting
means it will be there for a long time
right lasting for a long time like this
house this castle house just one house a
very rich person or big building this
has been there for a long long time
right
so what do we say it's sturdy
it's a sturdy building it's a sturdy
building it's very strong and it will
last for a long time it will be there
for a long time it's already been here
for hundreds of years that's a long time
this building is very sturdy
oh yeah next word this of course here is
what do we call this a couple of birds
are sitting on it I hope they're not
angry
they don't look angry they're just Birds
right okay so a couple birds on top of
this one what holds a roof up of course
this is a wall these birds are sitting
on a wall a wall holds a roof up right
if you have a roof over your head what
holds it up the walls the walls have to
be sturdy if the walls are not sturdy
the roof falls on top of you right so
wall walls should be sturdy what's this
here this looks interesting
it's a box that's not a box it's a block
a block used to build things and we we
put these things on top of each other we
call this of course is a brick we've
said it before when I talked about a
brick wall right bricks there are the
little blocks that you use to build a
brick wall
remember the wall we just saw the birds
were sitting on it it was red there are
many bricks in that wall now when you
take bricks and you put them on top of
one another or you take books
and you put on top of each other right
you take one one book and you put it on
top of that book and on top of each
other and you keep putting more and more
and more and more books what are you
doing
this is a special verb it's to stack it
means to keep putting on top of each
other right
if one book put another book another
book another book another book or one
brick another brick another brick
you're stacking the bricks or books on
top of each other or whatever it is
can you stack apples if you're really
good you can stack apples but not too
high they'll fall over books are easier
to stack bricks are easier to stack okay
a straight line so here we see that we
have many straight lines right going
this way this is a straight line a
straight line a straight line you could
also go like this a straight line a
straight line what do we call these we
call these rows so if you go to a movie
theater right young wagwan right you can
see many seats and your ticket has the
number and the row on your ticket so you
know where to go
it says row H so you go a b c d e f g h
h that's my row then you go over to the
number so look to find out what row you
are in and then you can find your seat
so a row especially when we talk about
seats we talk about rows in a big
theater or stadium for example okay
let's move on to number 9 whoa what's
that that's a really weird soo bahk
right Tsubaki son hang what the heck
okay that's just a funny picture it
doesn't really look like that right
having four straight sides four straight
sides of course it would be square is a
soo bahk square soo bahk what
turn melon water melon is a watermelon
square that's crazy right watermelons
don't look like that that's just a funny
picture watermelons are round right
they're round or not exactly round like
a like a ball
you could also say oval oval is like a
watermelon some watermelons are exactly
round like a ball that's true they were
round perfectly round but usually
watermelons are longer on the ends right
and not so long on the top and bottom so
we say they're oval so many different
shapes square would be like a box right
if you have a box that is a square box
am i good artist ah yeah kind of I guess
okay that would be a box it's a square
box okay that would be square okay
number 10
Oh what's wrong with this guy someone
who builds but he's not building very
well look he's making but what's going
on there you need another brick over
here Pablo okay and look he didn't fill
up that that position there he needs
more experience don't hire him okay but
anyway Oh someone who builds this is
interesting this is easy right someone
who builds this is your verb to build
but we want to say a person who does
this so it's very easy just take the
verb be you I L D and add e-r e-r ah
there we go that's our word builder and
you can do this with many verbs in
English yay right someone who drives to
drive if you go to school right
sometimes you ride in a school bus or
you just take the city bus the person
who drives the bus is a
Reimer driver okay so many verbs in
English you just add e are not all of
them but many of them it's a common way
to use the verb to talk about a person
who does that thing okay
so a builder but we have to be careful
with this guy he's not a good builder
right he's making some strange problems
here okay anyway let's move on number 11
now here we have a by the way this is an
exception right what is he doing he's
cooking - cook - cook but don't say
cooker and don't do that that's an
exception we say he's a cook
don't say cook her right that's that's
an exception I'm sorry
English has many exceptions but don't
say cooker he's a cook what is he doing
he's mixing together with the big iron
piece or sometimes your mom if she's
making soup she'll take a wooden spoon
and she'll mix together what is she
doing she is stirring to stir the pot
right to stir things is to mix it
together okay let's take a look number
12 glue this is not really glue but it's
like glue it's similar to glue glue made
from sand and water sand and water makes
glue well it can if you get the right
mix maybe you've seen this before
when you see construction workers they
are working they're called workers right
when you see construction workers making
a new sidewalk they have this material
it's just sand and water and it it's not
glue but it acts like glue it Behe
like glue it sticks things together what
do we call it we call it cement cement
cement is a common building material
most buildings are made from cement
probably if you are in an apartment
building right now your apartment
building was made from cement sand and
water dirt that's what we're talking
about right many homes were made from
dirt are made of dirt okay

## toggle timestamps Transcript

00:00
[Music]
00:04
if we think about that this is a home
00:08
right a place where something lives is
00:11
of course a home many homes are made
00:15
from bricks and bricks are made from
00:18
soil or dirt we live in dirt homes is it
00:23
dirty
00:23
no it's clean because of the way we make
00:27
bricks that's what we're talking about
00:29
how different homes are made from bricks
00:32
and of course we're going to look at not
00:35
just this word but many other words for
00:38
this lesson let's go for number two
00:40
the second word to cook in an oven this
00:45
of course in the background that's an
00:47
oven right you put food usually you put
00:51
food in an oven lots of heat and you get
00:55
a nice loaf of bread or cake that comes
01:00
out and of course this means to bake
01:02
when you put food in the oven lots of
01:06
heat goes on it and you bake it so you
01:09
bake a cake bake a loaf of bread
01:13
something like that so to bake here of
01:17
course is what we were talking about
01:19
before right we just use this word it's
01:22
actually they say a space for cooking at
01:24
a high heat a space is on the inside of
01:28
course this is a device or appliance
01:31
that you find in your kitchen appliance
01:37
there are many appliances in your
01:40
kitchen one appliance of course is this
01:44
thing which we just talked about that's
01:47
an oven an oven by the way just for your
01:52
information this part is the oven this
01:58
part
01:59
don't say oven this part is stove the
02:06
top is the stove the middle part is the
02:09
oven okay next one
02:13
Wow big house right looks like a castle
02:16
right very strong and lasting lasting
02:21
means it will be there for a long time
02:25
right lasting for a long time like this
02:34
house this castle house just one house a
02:37
very rich person or big building this
02:40
has been there for a long long time
02:43
right
02:44
so what do we say it's sturdy
02:47
it's a sturdy building it's a sturdy
02:52
building it's very strong and it will
02:55
last for a long time it will be there
02:58
for a long time it's already been here
03:00
for hundreds of years that's a long time
03:03
this building is very sturdy
03:05
oh yeah next word this of course here is
03:10
what do we call this a couple of birds
03:12
are sitting on it I hope they're not
03:14
angry
03:14
they don't look angry they're just Birds
03:16
right okay so a couple birds on top of
03:19
this one what holds a roof up of course
03:23
this is a wall these birds are sitting
03:26
on a wall a wall holds a roof up right
03:31
if you have a roof over your head what
03:34
holds it up the walls the walls have to
03:37
be sturdy if the walls are not sturdy
03:40
the roof falls on top of you right so
03:44
wall walls should be sturdy what's this
03:49
here this looks interesting
03:50
it's a box that's not a box it's a block
03:53
a block used to build things and we we
03:56
put these things on top of each other we
03:59
call this of course is a brick we've
04:02
said it before when I talked about a
04:04
brick wall right bricks there are the
04:08
little blocks that you use to build a
04:11
brick wall
04:12
remember the wall we just saw the birds
04:14
were sitting on it it was red there are
04:16
many bricks in that wall now when you
04:22
take bricks and you put them on top of
04:23
one another or you take books
04:26
and you put on top of each other right
04:32
you take one one book and you put it on
04:36
top of that book and on top of each
04:38
other and you keep putting more and more
04:41
and more and more books what are you
04:43
doing
04:43
this is a special verb it's to stack it
04:48
means to keep putting on top of each
04:50
other right
04:51
if one book put another book another
04:53
book another book another book or one
04:56
brick another brick another brick
04:58
you're stacking the bricks or books on
05:01
top of each other or whatever it is
05:04
can you stack apples if you're really
05:07
good you can stack apples but not too
05:10
high they'll fall over books are easier
05:13
to stack bricks are easier to stack okay
05:17
a straight line so here we see that we
05:22
have many straight lines right going
05:24
this way this is a straight line a
05:26
straight line a straight line you could
05:28
also go like this a straight line a
05:30
straight line what do we call these we
05:33
call these rows so if you go to a movie
05:38
theater right young wagwan right you can
05:41
see many seats and your ticket has the
05:46
number and the row on your ticket so you
05:50
know where to go
05:51
it says row H so you go a b c d e f g h
05:57
h that's my row then you go over to the
06:00
number so look to find out what row you
06:04
are in and then you can find your seat
06:07
so a row especially when we talk about
06:09
seats we talk about rows in a big
06:13
theater or stadium for example okay
06:17
let's move on to number 9 whoa what's
06:19
that that's a really weird soo bahk
06:21
right Tsubaki son hang what the heck
06:24
okay that's just a funny picture it
06:27
doesn't really look like that right
06:29
having four straight sides four straight
06:34
sides of course it would be square is a
06:37
soo bahk square soo bahk what
06:39
turn melon water melon is a watermelon
06:46
square that's crazy right watermelons
06:51
don't look like that that's just a funny
06:53
picture watermelons are round right
06:57
they're round or not exactly round like
07:00
a like a ball
07:02
you could also say oval oval is like a
07:06
watermelon some watermelons are exactly
07:09
round like a ball that's true they were
07:11
round perfectly round but usually
07:14
watermelons are longer on the ends right
07:16
and not so long on the top and bottom so
07:19
we say they're oval so many different
07:22
shapes square would be like a box right
07:25
if you have a box that is a square box
07:30
am i good artist ah yeah kind of I guess
07:34
okay that would be a box it's a square
07:36
box okay that would be square okay
07:40
number 10
07:41
Oh what's wrong with this guy someone
07:46
who builds but he's not building very
07:48
well look he's making but what's going
07:50
on there you need another brick over
07:52
here Pablo okay and look he didn't fill
07:56
up that that position there he needs
07:59
more experience don't hire him okay but
08:03
anyway Oh someone who builds this is
08:05
interesting this is easy right someone
08:08
who builds this is your verb to build
08:13
but we want to say a person who does
08:16
this so it's very easy just take the
08:19
verb be you I L D and add e-r e-r ah
08:27
there we go that's our word builder and
08:30
you can do this with many verbs in
08:33
English yay right someone who drives to
08:39
drive if you go to school right
08:42
sometimes you ride in a school bus or
08:45
you just take the city bus the person
08:48
who drives the bus is a
08:53
Reimer driver okay so many verbs in
08:58
English you just add e are not all of
09:02
them but many of them it's a common way
09:05
to use the verb to talk about a person
09:09
who does that thing okay
09:12
so a builder but we have to be careful
09:16
with this guy he's not a good builder
09:18
right he's making some strange problems
09:22
here okay anyway let's move on number 11
09:25
now here we have a by the way this is an
09:29
exception right what is he doing he's
09:31
cooking - cook - cook but don't say
09:36
cooker and don't do that that's an
09:39
exception we say he's a cook
09:45
don't say cook her right that's that's
09:49
an exception I'm sorry
09:51
English has many exceptions but don't
09:54
say cooker he's a cook what is he doing
09:57
he's mixing together with the big iron
10:01
piece or sometimes your mom if she's
10:04
making soup she'll take a wooden spoon
10:07
and she'll mix together what is she
10:10
doing she is stirring to stir the pot
10:15
right to stir things is to mix it
10:19
together okay let's take a look number
10:21
12 glue this is not really glue but it's
10:26
like glue it's similar to glue glue made
10:30
from sand and water sand and water makes
10:34
glue well it can if you get the right
10:38
mix maybe you've seen this before
10:41
when you see construction workers they
10:45
are working they're called workers right
10:47
when you see construction workers making
10:50
a new sidewalk they have this material
10:54
it's just sand and water and it it's not
10:56
glue but it acts like glue it Behe
11:01
like glue it sticks things together what
11:04
do we call it we call it cement cement
11:09
cement is a common building material
11:13
most buildings are made from cement
11:18
probably if you are in an apartment
11:22
building right now your apartment
11:24
building was made from cement sand and
11:28
water dirt that's what we're talking
11:31
about right many homes were made from
11:34
dirt are made of dirt okay
