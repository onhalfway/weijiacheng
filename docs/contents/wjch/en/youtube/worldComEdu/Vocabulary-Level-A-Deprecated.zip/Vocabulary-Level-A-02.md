# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestaps Transcript](#toggle-timestaps-transcript)

## un-toggle timestamps Transcript

[Music]
here we have we brush our teeth with
this we have the picture not the
toothbrush right that's a toothbrush
we're not talking about the toothbrush
we're talking about this here what is
this what's that stuff we put it on our
toothbrush and we brush chiki chiki
chaka choko choko right we brush our
teeth with this what do we call it we
call it tooth paste tooth paste paste is
the material that we use to brush our
teeth
tooth paste to words we put it together
so this is toothpaste that we put on the
toothbrush and we brush our teeth with
it
toothpaste okay next one we already saw
this word right we just saw this a
little bit ago the yellow fruit yellow
fruit it's a fruit because it has seeds
in it
the yellow fruit that tastes sour ah
right
lemons taste sour it means right it's
not a it's not a really good taste it's
not sweet we put sugar in it to make it
sweet and we like lemons then but it's a
sour taste and what did I say I just
said lemon
these are lemons so if you have many
lemons right you have many yellow fruits
it's yellow fruit that tastes sour okay
our next word that's an interesting
picture it's the liquid liquid is like
water right water inside a bottle that
girls use to smell nice
so girls like to smell nice they smell
so nice right usually girls use this
thing to smell nice it's made
of flowers many different types of
flowers what do we call it we call it
perfume perfume pop perfume so we have P
then we have F be careful because P is
pup-pup F is do you see the
difference P your lips are together pump
F your lips are not together your teeth
are on your bottom lip o thumb so per
fume perfume perfume perfume is liquid
that girls use to smell nice right they
put perfume on their bodies okay next
one we have another liquid it's also a
liquid we cook food in this so we pour
this on the pan and put food in there
and we cook it we heat it up very hot
and we cook food in this what is it it's
very slippery right we call it whale oil
oil right oil oh I oh I oh I'll boil so
we say that this is oil your mom uses
oil to cook in and we call that cooking
oil cooking oil there's many types of
oil but when we cook food in it we call
it cooking oil cooking oil okay what's
this here this is very strong right we
can tie it to one place and pull with it
a strong line we tie tie right can you
tie a rope to something can you tie your
shoes your shoelaces
together you tie something together you
tie two things of course I just said it
it is a rope our rope is very thick
right we call that a rope this is a rope
and we tie it to things and we can pull
right so rope rope okay the next word
here we talked about this before right
this is something that you wash with
when you wash your face right you'd get
a little bit on your hand or your cloth
and you put it on your face and you wash
your face with it when you wash your
hands you take this in your hands and
you wash your hands with this it helps
make your hands very clean if you just
use water that's not so good it's better
if you use soap soap use soap to wash
your hands by the way it's very
interesting you can see here it says
100% vegetal that's a different language
it's not English but it means 100%
vegetable this soap is made from
vegetables it's very natural soap 100%
vegetables it's made we use vegetables
to make soap okay oh are you hungry
whoa I'm hungry just looking at this wow
it looks really good
oh my ah right this is what we eat
to get energy we want energy sometimes
we get tired ah it's been a long day but
if we eat something we get more energy
right so and this looks very delicious
what is it it's food food food okay and
by the way there's two types of food
right this these are all plants we get
this from plants this is meat
meet we get that from animals so there's
two types of food right vegetables are
plants and meats these are food we eat
them to get energy food okay
here we have an interesting plant this
is a plant with a fresh smell ah smells
very fresh and it tastes fresh mmm it
tastes very fresh it's really good
sometimes we have this in ice cream
sometimes they put it into hot
chocolates right
it makes the hot chocolate taste fresh
or good it makes our ice cream taste
good
what is it it is mints mint so you know
mint ice cream like mint chocolate chip
ice cream wow really good right it's
green mint hot choco
don't say hot choco say hot chocolate
mint hot chocolate if we put mint in it
it tastes fresh it tastes fresh it's
very good so we put mint in food
sometimes but we also use mint for other
things like perfume soap toothpaste if
you have mint toothpaste for example
it tastes fresh and it smells fresh mint
okay what's our next word we talked
about lemons before we talked about
lemons before but this is a drink with a
lemon flavor a drink with a lemon flavor
and you can see lemon is here but this
is a drink so we put lemons in we put
sugar and water
mmm it's very delicious what is it it's
called Oh big word lemon aid lemon
lemonade lemonade if you say it quickly
it sounds like lemonade lemonade okay so
this is very delicious right if it's hot
on a summer day I'm very hot drink some
cold lemonade it's very refreshing it
tastes good so it's a drink with the
lemon flavor we say lemonade
okay the next one huh this looks good
right
are you hungry I was hungry before now I
see this I'm hungry again this is a long
it's long yellow this is the color of
yellow this is green this is yellow
yellow is this color here yellow
vegetable that has a green skin so this
is yellow this is green the skin is
green and then you pull back the skin
underneath it's yellow and there are
many little pieces right that we eat ah
it's very good with butter right what is
it
of course we say it's corn corn is what
we eat as a vegetable it's a long yellow
vegetable that has a green skin but we
use corn for many other things
corn corn okay Wow what's this girl
doing she has had a lot of food she has
a lot of energy right she is doing
something she is exercising it's an
exercise exercise something you do to
make your bodies strong an exercise in
which in which the player the player or
the person jumps over a rope many times
right the rope is going around and
around and around and that person is
jumping right they have to jump over the
rope many times I'm getting tired okay
what is it it's called jump rope very
easy
remember we said that this is like a
rope here and you jump over it it's jump
rope jump over a rope jump rope two
words
jump rope jump rope okay
this is another fun exercise or game
right that you can use a rope one is
jump rope the other is people pull pull
on the rope a game in which two teams
one team two teams and it can be many
people but two teams one team two teams
two teams hold a rope and pull against
each other they pull against each other
so these guys are pulling this way this
team is pulling that way they pull
against each other who will win right
who will win this game what is this game
we say it is tug-of-war it's like war
two teams they're fighting the war tug
tug means pull like this
pull that's tug so tug-of-war tug-of-war
tug-of-war
it's called tug-of-war let's play
tug-of-war it's a fun game you can use
with many people you have two teams make
sure the teams are even right it's not
fair
teams should have the same number of
people
so tug-of-war two teams okay it's a fun
game

## toggle timestaps Transcript

00:00
[Music]
00:07
here we have we brush our teeth with
00:11
this we have the picture not the
00:13
toothbrush right that's a toothbrush
00:15
we're not talking about the toothbrush
00:18
we're talking about this here what is
00:21
this what's that stuff we put it on our
00:24
toothbrush and we brush chiki chiki
00:28
chaka choko choko right we brush our
00:30
teeth with this what do we call it we
00:34
call it tooth paste tooth paste paste is
00:42
the material that we use to brush our
00:46
teeth
00:47
tooth paste to words we put it together
00:50
so this is toothpaste that we put on the
00:54
toothbrush and we brush our teeth with
00:57
it
00:58
toothpaste okay next one we already saw
01:03
this word right we just saw this a
01:05
little bit ago the yellow fruit yellow
01:09
fruit it's a fruit because it has seeds
01:12
in it
01:13
the yellow fruit that tastes sour ah
01:17
right
01:18
lemons taste sour it means right it's
01:21
not a it's not a really good taste it's
01:24
not sweet we put sugar in it to make it
01:27
sweet and we like lemons then but it's a
01:31
sour taste and what did I say I just
01:34
said lemon
01:35
these are lemons so if you have many
01:39
lemons right you have many yellow fruits
01:42
it's yellow fruit that tastes sour okay
01:47
our next word that's an interesting
01:50
picture it's the liquid liquid is like
01:54
water right water inside a bottle that
01:57
girls use to smell nice
02:01
so girls like to smell nice they smell
02:05
so nice right usually girls use this
02:09
thing to smell nice it's made
02:13
of flowers many different types of
02:16
flowers what do we call it we call it
02:19
perfume perfume pop perfume so we have P
02:26
then we have F be careful because P is
02:30
pup-pup F is do you see the
02:35
difference P your lips are together pump
02:38
F your lips are not together your teeth
02:42
are on your bottom lip o thumb so per
02:48
fume perfume perfume perfume is liquid
02:56
that girls use to smell nice right they
03:02
put perfume on their bodies okay next
03:07
one we have another liquid it's also a
03:10
liquid we cook food in this so we pour
03:16
this on the pan and put food in there
03:21
and we cook it we heat it up very hot
03:24
and we cook food in this what is it it's
03:28
very slippery right we call it whale oil
03:35
oil right oil oh I oh I oh I'll boil so
03:43
we say that this is oil your mom uses
03:47
oil to cook in and we call that cooking
03:54
oil cooking oil there's many types of
03:58
oil but when we cook food in it we call
04:01
it cooking oil cooking oil okay what's
04:07
this here this is very strong right we
04:10
can tie it to one place and pull with it
04:16
a strong line we tie tie right can you
04:21
tie a rope to something can you tie your
04:25
shoes your shoelaces
04:27
together you tie something together you
04:29
tie two things of course I just said it
04:32
it is a rope our rope is very thick
04:36
right we call that a rope this is a rope
04:39
and we tie it to things and we can pull
04:42
right so rope rope okay the next word
04:48
here we talked about this before right
04:51
this is something that you wash with
04:54
when you wash your face right you'd get
04:56
a little bit on your hand or your cloth
04:59
and you put it on your face and you wash
05:03
your face with it when you wash your
05:05
hands you take this in your hands and
05:08
you wash your hands with this it helps
05:12
make your hands very clean if you just
05:16
use water that's not so good it's better
05:20
if you use soap soap use soap to wash
05:26
your hands by the way it's very
05:29
interesting you can see here it says
05:33
100% vegetal that's a different language
05:38
it's not English but it means 100%
05:41
vegetable this soap is made from
05:45
vegetables it's very natural soap 100%
05:50
vegetables it's made we use vegetables
05:53
to make soap okay oh are you hungry
05:58
whoa I'm hungry just looking at this wow
06:01
it looks really good
06:03
oh my ah right this is what we eat
06:07
to get energy we want energy sometimes
06:11
we get tired ah it's been a long day but
06:14
if we eat something we get more energy
06:17
right so and this looks very delicious
06:20
what is it it's food food food okay and
06:26
by the way there's two types of food
06:29
right this these are all plants we get
06:35
this from plants this is meat
06:40
meet we get that from animals so there's
06:45
two types of food right vegetables are
06:48
plants and meats these are food we eat
06:53
them to get energy food okay
06:57
here we have an interesting plant this
07:01
is a plant with a fresh smell ah smells
07:06
very fresh and it tastes fresh mmm it
07:11
tastes very fresh it's really good
07:14
sometimes we have this in ice cream
07:18
sometimes they put it into hot
07:21
chocolates right
07:23
it makes the hot chocolate taste fresh
07:26
or good it makes our ice cream taste
07:30
good
07:30
what is it it is mints mint so you know
07:37
mint ice cream like mint chocolate chip
07:40
ice cream wow really good right it's
07:43
green mint hot choco
07:46
don't say hot choco say hot chocolate
07:49
mint hot chocolate if we put mint in it
07:53
it tastes fresh it tastes fresh it's
07:58
very good so we put mint in food
08:01
sometimes but we also use mint for other
08:05
things like perfume soap toothpaste if
08:09
you have mint toothpaste for example
08:12
it tastes fresh and it smells fresh mint
08:17
okay what's our next word we talked
08:21
about lemons before we talked about
08:25
lemons before but this is a drink with a
08:29
lemon flavor a drink with a lemon flavor
08:34
and you can see lemon is here but this
08:37
is a drink so we put lemons in we put
08:39
sugar and water
08:41
mmm it's very delicious what is it it's
08:46
called Oh big word lemon aid lemon
08:53
lemonade lemonade if you say it quickly
08:57
it sounds like lemonade lemonade okay so
09:03
this is very delicious right if it's hot
09:06
on a summer day I'm very hot drink some
09:11
cold lemonade it's very refreshing it
09:15
tastes good so it's a drink with the
09:17
lemon flavor we say lemonade
09:20
okay the next one huh this looks good
09:23
right
09:24
are you hungry I was hungry before now I
09:27
see this I'm hungry again this is a long
09:31
it's long yellow this is the color of
09:35
yellow this is green this is yellow
09:38
yellow is this color here yellow
09:41
vegetable that has a green skin so this
09:45
is yellow this is green the skin is
09:48
green and then you pull back the skin
09:52
underneath it's yellow and there are
09:55
many little pieces right that we eat ah
09:59
it's very good with butter right what is
10:02
it
10:03
of course we say it's corn corn is what
10:08
we eat as a vegetable it's a long yellow
10:11
vegetable that has a green skin but we
10:14
use corn for many other things
10:17
corn corn okay Wow what's this girl
10:22
doing she has had a lot of food she has
10:25
a lot of energy right she is doing
10:28
something she is exercising it's an
10:31
exercise exercise something you do to
10:35
make your bodies strong an exercise in
10:39
which in which the player the player or
10:43
the person jumps over a rope many times
10:48
right the rope is going around and
10:51
around and around and that person is
10:54
jumping right they have to jump over the
10:57
rope many times I'm getting tired okay
11:01
what is it it's called jump rope very
11:05
easy
11:06
remember we said that this is like a
11:07
rope here and you jump over it it's jump
11:11
rope jump over a rope jump rope two
11:15
words
11:16
jump rope jump rope okay
11:21
this is another fun exercise or game
11:24
right that you can use a rope one is
11:28
jump rope the other is people pull pull
11:32
on the rope a game in which two teams
11:35
one team two teams and it can be many
11:40
people but two teams one team two teams
11:43
two teams hold a rope and pull against
11:48
each other they pull against each other
11:51
so these guys are pulling this way this
11:54
team is pulling that way they pull
11:56
against each other who will win right
12:00
who will win this game what is this game
12:03
we say it is tug-of-war it's like war
12:09
two teams they're fighting the war tug
12:13
tug means pull like this
12:17
pull that's tug so tug-of-war tug-of-war
12:22
tug-of-war
12:24
it's called tug-of-war let's play
12:27
tug-of-war it's a fun game you can use
12:31
with many people you have two teams make
12:35
sure the teams are even right it's not
12:37
fair
12:38
teams should have the same number of
12:40
people
12:41
so tug-of-war two teams okay it's a fun
12:45
game