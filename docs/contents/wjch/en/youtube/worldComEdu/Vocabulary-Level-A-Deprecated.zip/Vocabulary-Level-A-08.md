# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
our word list for this unit of what kind
of vocabulary will we learn first of all
we have here a picture a place with
trees and animals a place with trees and
animals I was just talking about this
place do you remember what the name of
this place is starts with an F of course
it is a forest when you say forest to
remember what the f fo your teeth are on
your bottom lip
forest so this is a forest a place with
trees and animals what's next next we
have a safe place to be
remember this cute guy right here right
he's looking out from his home well he
of course lives in the forest or she
we're not sure but they live in the
forest this type of animal and many
types of animals will make what inside a
tree right they will make a shelter
shelter and shelter is the same word or
it's the same meaning really for many
animals it's their home isn't it right
so this animal will find shelter in a
tree
they'll make it their home so shelter is
like a home for many types of animals in
the forest ok what else we have what's
this boy doing right he's holding on to
a tree and he's going up into the tree
here it says to go up like a monkey
right so if you think about monkeys we
saw the picture before of the monkey
what do monkeys do really well right
they can go up in the tree very quickly
what is the verb that we use to describe
this action what is this boy doing he is
climbing of course climb is just the
root form climb to climb he is climbing
the tree whoops he is climbing the tree
the boy is climbing the tree
you climb a tree but be careful
right make sure your mother or your
father is watching you when you climb
the tree it can be dangerous so be
careful but he is climbing the tree okay
the next we saw this picture before
right here is a bird now a home built by
a bird before we talked about shelter
right and we saw the the squirrel the
the cute animal looking out from the
shelter this is a type of shelter but
it's a special word for birds only birds
make this right what do we use for this
I'll work we call it a nest a nest so
when we set talked about a nest
you should think ah it's a bird right a
bird makes a nest and a nest is the home
for the bird it's their shelter it's
also their home for birds we say it is a
nest okay interesting okay
now we have another type of home right
we've talked about shelter we've talked
about nest now this is another type of
home and this is a interesting looking
animal here right kind of looks like a
dog but it's not really a dog it's a
different type of animal and this animal
will live in a home in the ground so
many animals will dig in the ground and
they will make their shelter or their
home there's a special word for this
what is it we say it's a cave okay
now sometimes animals will will make a
small cave or maybe there's a big cave
that they don't make but they will live
in there what lives in caves
well wild dogs perhaps hyenas a hyena is
a type of dog a hyena is a type of wild
dog in Africa this looks like a hyena
but also big animals like bears right be
careful if you're in the woods and you
see a bear bears are very big animals
and they also live in caves
okay so cave is another type of shelter
okay these are all shelters a nest as a
shelter and a cave as a shelter okay
another word that we have here is the
plant part so it's a part of a plant the
part of a plant that holds the seeds so
the seeds of course are what the plant
makes and the seeds will go into the
ground and make a new plant right
seeds are how plants make more plants
what do we call the part of the plant
that holds the seeds weak for many
plants it's called
the fruit right so bananas are a type of
fruit apples are a type of fruit
watermelon Subic right that's a type of
fruit and if you look at each of these
fruits they all have seeds in them and
if you take those seeds and you put them
in the ground a new plant will grow okay
so we call that fruit okay not all
plants but many plants have fruits and
that's how they distribute their seeds
okay
insect we have an insect here and of
course another word for insect is bug
you may know this word from the movies
right so there's in English of course
there's a lot of words that have two
words that mean the same thing right
insect insect is more formal it's a
little bit more of a difficult word
isn't it it's much easier to say
bug bug right and that's what insects
are insects are bugs and this is an
example of a bug right so you can say
bug or you can say insect same thing
what is this we talked about this before
do you remember what I said at the
beginning of this lecture this is an
animal with long arms right has long
arms right and a long tail so a long
tail not just long arms but also a long
tail and what type of animal is this do
you remember what I said at the
beginning of this lecture we said monkey
so say it with me monkey monkey ok so
this isn't a monkey and we've learned
about the monkey we also when we looked
at the picture with climb the boy is
going up the tree like a monkey monkeys
are very good at climbing aren't they
so you find monkeys in forests but not
cold forests not up in Korea
well maybe up in Korea and in Japan you
find monkeys but also more commonly in
the south where the trees are where the
forests are warmer there's many monkeys
that live in the forests in the warmer
forests near in the south ok ok the next
one a place where people live we talked
about this already in terms of animals
right we've talked about shelter we've
talked about nests for birds we talked
about caves for wild dogs or bears but
people where do people live of course we
live in a house right people build a
house right you could also say home but
home and house is where somebody lives
house though is house means the building
home is like a place that you're
emotionally connected to this is my home
this is where I live people can live in
an apartment they can live in a tent
they can live in a cave those are all
homes right but a house is something
that's built like this right it has
doors it might have a chimney it has
walls that were built by people so we've
seen a lot of different types of
shelters because this is also a shelter
so we've seen nest cave house these are
all shelters ok
next we have something used to travel on
water can you walk on water no you'll
sink right be careful right you jump in
the water you will sink but if you want
to travel over water on
top of the water so you don't sink what
do you travel in what is this this of
course is called a boat a boat and some
boats are very small like this some
boats are very big they're like hotels
and they go across the water okay so
something used to travel on water is a
boat okay this young girl is doing
something very good right she's helping
her mom out she is getting rid of some
dirty stuff on the ground so if you say
something is not dirty if it's not dirty
the opposite of dirty what do we say it
is clean so clean can be an adjective
right we can use it as an adjective it
is clean we can use it as an adjective
the floor is clean we can also use it as
a verb please clean the floor so we can
use it in two ways okay as an adjective
it is clean the floor is clean or if mom
sees some dirt on the floor she will say
to her daughter please clean the floor
and that's a verb please clean up your
room right please clean up your desk for
example okay so we can use it as an
adjective or as a verb very commonly
okay the next one an animal with
feathers and wings we already talked
about this type of animal right this
type of animal what type of shelter
doesn't make in the trees it makes a
nest what is it of course we know it's a
bird and there are many different kinds
of birds right many different shapes
different sizes different colors but we
all if they have feathers and wings we
say it is a bird okay so we see a bird
here

## toggle timestamps Transcript

00:00
[Music]
00:05
our word list for this unit of what kind
00:08
of vocabulary will we learn first of all
00:11
we have here a picture a place with
00:15
trees and animals a place with trees and
00:18
animals I was just talking about this
00:22
place do you remember what the name of
00:24
this place is starts with an F of course
00:27
it is a forest when you say forest to
00:31
remember what the f fo your teeth are on
00:35
your bottom lip
00:36
forest so this is a forest a place with
00:40
trees and animals what's next next we
00:44
have a safe place to be
00:47
remember this cute guy right here right
00:49
he's looking out from his home well he
00:52
of course lives in the forest or she
00:54
we're not sure but they live in the
00:56
forest this type of animal and many
00:58
types of animals will make what inside a
01:01
tree right they will make a shelter
01:05
shelter and shelter is the same word or
01:09
it's the same meaning really for many
01:11
animals it's their home isn't it right
01:14
so this animal will find shelter in a
01:19
tree
01:19
they'll make it their home so shelter is
01:22
like a home for many types of animals in
01:25
the forest ok what else we have what's
01:30
this boy doing right he's holding on to
01:33
a tree and he's going up into the tree
01:36
here it says to go up like a monkey
01:38
right so if you think about monkeys we
01:41
saw the picture before of the monkey
01:43
what do monkeys do really well right
01:46
they can go up in the tree very quickly
01:48
what is the verb that we use to describe
01:51
this action what is this boy doing he is
01:56
climbing of course climb is just the
01:59
root form climb to climb he is climbing
02:05
the tree whoops he is climbing the tree
02:10
the boy is climbing the tree
02:13
you climb a tree but be careful
02:16
right make sure your mother or your
02:19
father is watching you when you climb
02:22
the tree it can be dangerous so be
02:24
careful but he is climbing the tree okay
02:28
the next we saw this picture before
02:30
right here is a bird now a home built by
02:35
a bird before we talked about shelter
02:38
right and we saw the the squirrel the
02:40
the cute animal looking out from the
02:43
shelter this is a type of shelter but
02:47
it's a special word for birds only birds
02:51
make this right what do we use for this
02:54
I'll work we call it a nest a nest so
02:58
when we set talked about a nest
03:00
you should think ah it's a bird right a
03:03
bird makes a nest and a nest is the home
03:08
for the bird it's their shelter it's
03:11
also their home for birds we say it is a
03:14
nest okay interesting okay
03:18
now we have another type of home right
03:21
we've talked about shelter we've talked
03:23
about nest now this is another type of
03:25
home and this is a interesting looking
03:27
animal here right kind of looks like a
03:29
dog but it's not really a dog it's a
03:32
different type of animal and this animal
03:34
will live in a home in the ground so
03:37
many animals will dig in the ground and
03:40
they will make their shelter or their
03:43
home there's a special word for this
03:45
what is it we say it's a cave okay
03:49
now sometimes animals will will make a
03:51
small cave or maybe there's a big cave
03:54
that they don't make but they will live
03:57
in there what lives in caves
03:59
well wild dogs perhaps hyenas a hyena is
04:04
a type of dog a hyena is a type of wild
04:08
dog in Africa this looks like a hyena
04:11
but also big animals like bears right be
04:15
careful if you're in the woods and you
04:17
see a bear bears are very big animals
04:19
and they also live in caves
04:21
okay so cave is another type of shelter
04:26
okay these are all shelters a nest as a
04:28
shelter and a cave as a shelter okay
04:32
another word that we have here is the
04:35
plant part so it's a part of a plant the
04:39
part of a plant that holds the seeds so
04:44
the seeds of course are what the plant
04:47
makes and the seeds will go into the
04:50
ground and make a new plant right
04:52
seeds are how plants make more plants
04:55
what do we call the part of the plant
04:57
that holds the seeds weak for many
05:00
plants it's called
05:01
the fruit right so bananas are a type of
05:05
fruit apples are a type of fruit
05:09
watermelon Subic right that's a type of
05:12
fruit and if you look at each of these
05:14
fruits they all have seeds in them and
05:19
if you take those seeds and you put them
05:20
in the ground a new plant will grow okay
05:24
so we call that fruit okay not all
05:27
plants but many plants have fruits and
05:30
that's how they distribute their seeds
05:33
okay
05:34
insect we have an insect here and of
05:37
course another word for insect is bug
05:41
you may know this word from the movies
05:43
right so there's in English of course
05:46
there's a lot of words that have two
05:49
words that mean the same thing right
05:52
insect insect is more formal it's a
05:55
little bit more of a difficult word
05:57
isn't it it's much easier to say
06:00
bug bug right and that's what insects
06:04
are insects are bugs and this is an
06:07
example of a bug right so you can say
06:11
bug or you can say insect same thing
06:16
what is this we talked about this before
06:18
do you remember what I said at the
06:20
beginning of this lecture this is an
06:23
animal with long arms right has long
06:26
arms right and a long tail so a long
06:31
tail not just long arms but also a long
06:36
tail and what type of animal is this do
06:39
you remember what I said at the
06:40
beginning of this lecture we said monkey
06:44
so say it with me monkey monkey ok so
06:49
this isn't a monkey and we've learned
06:52
about the monkey we also when we looked
06:54
at the picture with climb the boy is
06:56
going up the tree like a monkey monkeys
07:00
are very good at climbing aren't they
07:02
so you find monkeys in forests but not
07:06
cold forests not up in Korea
07:08
well maybe up in Korea and in Japan you
07:11
find monkeys but also more commonly in
07:13
the south where the trees are where the
07:16
forests are warmer there's many monkeys
07:18
that live in the forests in the warmer
07:21
forests near in the south ok ok the next
07:27
one a place where people live we talked
07:30
about this already in terms of animals
07:33
right we've talked about shelter we've
07:35
talked about nests for birds we talked
07:37
about caves for wild dogs or bears but
07:41
people where do people live of course we
07:45
live in a house right people build a
07:48
house right you could also say home but
07:51
home and house is where somebody lives
07:54
house though is house means the building
07:57
home is like a place that you're
08:00
emotionally connected to this is my home
08:03
this is where I live people can live in
08:06
an apartment they can live in a tent
08:09
they can live in a cave those are all
08:11
homes right but a house is something
08:14
that's built like this right it has
08:16
doors it might have a chimney it has
08:19
walls that were built by people so we've
08:21
seen a lot of different types of
08:23
shelters because this is also a shelter
08:26
so we've seen nest cave house these are
08:30
all shelters ok
08:33
next we have something used to travel on
08:37
water can you walk on water no you'll
08:42
sink right be careful right you jump in
08:45
the water you will sink but if you want
08:47
to travel over water on
08:49
top of the water so you don't sink what
08:52
do you travel in what is this this of
08:54
course is called a boat a boat and some
08:57
boats are very small like this some
08:59
boats are very big they're like hotels
09:01
and they go across the water okay so
09:04
something used to travel on water is a
09:07
boat okay this young girl is doing
09:13
something very good right she's helping
09:15
her mom out she is getting rid of some
09:20
dirty stuff on the ground so if you say
09:24
something is not dirty if it's not dirty
09:27
the opposite of dirty what do we say it
09:31
is clean so clean can be an adjective
09:35
right we can use it as an adjective it
09:38
is clean we can use it as an adjective
09:44
the floor is clean we can also use it as
09:49
a verb please clean the floor so we can
09:59
use it in two ways okay as an adjective
10:03
it is clean the floor is clean or if mom
10:06
sees some dirt on the floor she will say
10:09
to her daughter please clean the floor
10:13
and that's a verb please clean up your
10:15
room right please clean up your desk for
10:20
example okay so we can use it as an
10:22
adjective or as a verb very commonly
10:25
okay the next one an animal with
10:29
feathers and wings we already talked
10:32
about this type of animal right this
10:34
type of animal what type of shelter
10:36
doesn't make in the trees it makes a
10:39
nest what is it of course we know it's a
10:43
bird and there are many different kinds
10:46
of birds right many different shapes
10:48
different sizes different colors but we
10:52
all if they have feathers and wings we
10:55
say it is a bird okay so we see a bird
11:00
here