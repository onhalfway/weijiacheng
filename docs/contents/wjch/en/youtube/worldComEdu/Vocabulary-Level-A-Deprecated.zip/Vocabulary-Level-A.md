# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
okay let's start with our first
word the first word we don't see it
but we have the definition here and we
have a picture
over here let's see the definition let's
take a look
at the definition the definition is
the part the part there are many
parts of a plant but we're looking at
maybe one part or a few different parts
right i am a person i have many parts
right just like a plant has many parts
so we're looking at the part of a plant
that we eat we eat the part of the plant
so sometimes we have this part of the
plant over here we eat that
sometimes it's this part of the plant or
sometimes
this part of a plant they're different
parts of a plant
we eat them what do we call that we call
those
vegetable vegetable
if you look at the word it looks like
vegetable but no
we say vegetable everybody vegetable
so it sounds like you don't say e
vegetable vegetable don't say vegetable
manila vegetable is very common
vegetable
but there's an interesting point when i
see vegetable
i think fruit
so there's a question
what is the difference between vegetable
and fruit ego hago egohago otoketorani
right
how are they different it's very simple
think about this fruit has
seeds
if there are seeds in it it's a fruit
vegetable no seeds
a vegetable does not have
seeds no seeds so a fruit is a part of
the plant
yes but it's only one part of the plant
it's the part that has seeds
if it has seeds it's a fruit so an
apple cut open an apple there are seeds
an apple is a fruit watermelon
right you cut the watermelon watermelon
tsubak right
watermelon you cut the watermelon many
many many
seeds watermelon is a fruit
vegetable a carrot dangan
tangan right you cut the carrot where's
the seeds there's no seeds
carrot is a vegetable okay so that's how
you know the difference between
vegetable
and fruit but mostly in this lesson
we will talk about vegetables
okay the parts of the plant that we eat
many parts don't have seeds so
mostly we will talk about vegetables
okay okay let's go to the next word
the next word is the part remember
there's many parts of a plant we're
looking at one part
the part of a plant that makes
seeds it's the part of the plant
that makes the seeds before the fruit
right it's the part of the plant that
makes the seeds
before it becomes a fruit what part is
it
look at the picture there are many
pretty pretty what
we have yellow we have purple what are
they of course we say
they are flowers flower
be careful this is a little hymdero a
little
difficult to pronounce f and
l right f and l
very difficult combination f
put them together flower
flower that's not so hard
flower flower it's the part of the plant
that makes
seeds the flowers make seeds
okay let's move on to our next word
the next word we can see wow looks
really
bright here right very green this
is the flat green part
of a plant and there are many right
a plant has many of these
what do we call this one one of them
what do we call it
we call it a leaf
leaf here we have l and f at the end
right
now they're apart but l remember l
la la put your tongue
behind your teeth on the top la
leaf and then for
f leaf leaf that's only one
one leaf but a plant has many
so how do we make it plural we say
many leaves
many leaves leaves
leaves okay so if it's one
just one we say it's a leaf but of
course a plant has
many you look at a plant you see many
leaves on a plant the flat green part
of a plant usually green sometimes
they're yellow sometimes they're orange
right
depends but usually they're green the
green
parts of a plant okay now we're on the
next part of the plant
and this part we can't see it right we
can't see that part
of the plant because it's underground
underground let me write that for you
under
ground right
this is the ground this is the ground
it's under
under the ground under ground
it's underground the part of a plant
that grows it grows down
in the dirt it's in the dirt
right in the dirt it's underground
so what part of this plant is it what do
we say
what's the word there we say that part
of the plant is called the root
root right strong word of course the
roots are strong
because they have to be strong because
they hold the plant
in the ground right these roots we can't
see them
unless we pull the plant out right we
pull the plant
out of the ground then we can see the
roots
we can see the roots right but one root
many roots okay so root
root right strong word root okay what's
our next word
okay our next word we're talking about a
different part of the plant this
is this part right here actually it's
this whole piece right here right that
whole thing
we're talking about that part of the
plant now
now it's the part of a plant that holds
the plant up it holds the plant up
right it supports the rest of the plant
it's kind of like my body right my trunk
of my body holds my body up right but
this part
we don't usually say trunk for a small
plant we can say what
stem stem yes we can say
trunk for a tree but this is a small
plant
we say stem stem
many plants all plants have a stem
the stem is like the body of a plant
right
it's like the body of a plant it's their
body right
some bodies are thin some bodies are
thick right
so these are the stems of
the plant right some of them are are
thick and big
some of them are very thin and not so
strong
but they are called stems stem
the stem of a plant the part that
holds the plant up okay
the next one is the part of a plant
that grows into a new
plant we talked about this part before
we've mentioned it several times
already we're looking at this very
small piece of the plant that piece
that part will fly away on the wind
it'll fall in the ground
and a new plant will grow okay so
that's just one type of plant of course
there are many types
of these sometimes people eat them right
and they throw them away in different
places and a new plant will grow
what are we talking about we're talking
about the seed
the seed the seed of a plant
remember when we talked about fruits and
vegetables
where is the seed the seed is in
the fruit but not all plants have fruit
some plants there's no fruit like this
plant here
there's no fruit because the seeds
break off and fly away on the wind
but many plants grow fruit the seeds are
in them because
animals eat the fruit and they eat the
seeds too
and they walk away and they go they go
they go to the bathroom somewhere else
but the seeds are in that and the seeds
will grow
in a different location and those are
seeds okay
so plants have many ways to spread
their seeds okay
now we've come here to this type
of plant we're talking about a type of
plant
a long orange vegetable
so it's a vegetable you can see it right
here you know what that is right
we can only see part of it but we know
what the rest of it is
the rest of it is underground right
what did we call that this of course is
called the carrot
right before i said tangan right tangan
one of the
first words i learned in korean because
carrots are very common they're good for
you
carrots are very good for your eyes you
eat many carrots
you have good eyesight i don't know what
happened with me
i think i read too much but if you eat
many carrots you have good
eyesight okay but carrots are long
orange vegetable they're very good for
you
okay now here we have
an action it's not a noun we're looking
for a verb an
action to put food
into your mouth and chew
and swallow swallow it so
you chew it and you swallow it actually
you do three things right
first you put it in your mouth that's
first
second you chew it and
third you swallow it right
make sure you chew before you swallow
don't just put and
gulp chew don't be so fast
take your time chew your food well but
there's three actions right
to put food in your mouth chew it and
then
swallow it what are we talking about of
course we're talking about to
eat eat okay so when we eat
that's what we're doing we're actually
doing three things put food in your
mouth
chew it and then swallow of course we
can also talk about
the different times right present tense
past tense right and past participle
okay
so when we talk about present tense eat
eat
that's what we're doing now what will we
do now let's eat
let's go eat okay and that's also a
little bit of future right
let's eat i want to eat now you're
talking about the present time
or just a little bit in the future what
about eight
eat eight i ate
breakfast did you eat breakfast yes
i ate breakfast i hope you ate breakfast
right but you're talking about eating a
long time ago right
i have eaten or i've done something
before right
i have eaten breakfast i have eaten
have you ever eaten eggs for breakfast
right so if you're talking about if you
ever did something in your life
you have done it you have eaten
eggs okay so eat ate
eaten one more time eat ate
eaten those are the different verb forms
of this verb to eat
by the way you should eat breakfast
every day
right always eat breakfast i ate
breakfast today
i hope you ate breakfast today okay
our next word is another type of
vegetable
another type of vegetable we saw carrot
before
that's one type of vegetable but now we
have
another type of vegetable and this
is the picture you know this one right
this is very common
round white they're white maybe
a little yellow but usually white
vegetables
that grow in the dirt they grow
underground
just like the carrot right what do we
call
these vegetables we call them
potato potato right you know of course
kamja right kamja
potato is very very common and of course
we know potatoes as potato chips
right potato chips are very common too
made from potatoes
and i just gave you of course when you
talk about plural
say potatoes potatoes
with the e we add e-s at the end
it is potatoes
so potatoes of course are very common
you
probably eat them maybe every day
if not every day then probably many
times a week right i'm sure you eat
potatoes
very often okay okay let's move on
now this is also very common especially
with korean dishes right i really like
bulgogi
right and i like when i eat bulgogi i
use this
to put the bulgogi in what do we call
this a plant with
large green leaves it has many
large green leaves okay what do we call
it
in english we say it's lettuce
lettuce now lettuce is very similar to
another
uh vegetable we call cabbage
but cabbage is very
similar but lettuce is not so heavy
lettuce is
lighter it's thinner and it tastes a
little bit better
lettuce is a different kind but cabbage
they're very close they're like brothers
right
they're like sisters they're very close
lettuce or cabbage
lettuce of course is very common we use
it in salads
of course in many korean dishes you can
use it to eat with meat
i like to put the meat the rice the
garlic the onion and the dwenjang right
right but we use the lettuce in many
different ways
okay we say lettuce lettuce
it almost sounds like let us go but it
doesn't mean that right
it's lettuce lettuce and that is a plant
with large
green leaves okay here we have
another type of plant that we eat right
we eat these things right here these
actually are seeds right
but there's in this case they're soft
and they're good for you
the seed of a pea plant that we eat
the seed of a pea plant that we eat
remember pea plant right that's very
easy because we say pea
right it's a pea peas eat your peas
peas are very good for you now
usually we don't eat the seeds of a
plant
like apple seeds they're very hard right
look they don't taste good but we can
eat peas the seeds
of a pea plant we eat those very often
so sometimes we can eat seeds but
sometimes we
don't eat the seeds right but in the
case of peas
we eat the seeds okay it's part of the
plant
that we eat okay our next word
is a verb to have an
odor that's a verb right a verb
when we see to do something we're
talking about
a verb to have an odor
an odor that means i can
sense it with my nose right
there are good odors that's nice
and there are bad odors themselves right
bad odors so to have an odor what is the
word
what is going on here we say that this
is
smell smell to have an odor
is to smell there's two ways
you can use this verb one way
is this the flower smells so in this
case
the flower smells that's a good odor but
sometimes there's a
bad odor for example my oops where
my socks
smell whoops smell
my sock what is this sock you say yang
mao right
so sock is like this
it smells right don't smell that smell
it smells my socks smell
that's one way another way you can use
this
is i smell i
smell i smell what my sock no
yuck that's horrible right i smell a
flower that's much better i smell a
flower
ah much better right don't smell your
socks
right that's that's terrible right so
my sock smell it has an odor
it gives an odor some good odors
and some bad odors right my socks
smell or i smell
a flower so there's two ways you can use
this verb some things smell
or people or animals
smell something so there's two ways the
flower
smells the boy smells the flower
two ways right okay so smell
very interesting verb here we have
we brush our teeth with this we have the
picture
not the toothbrush right that's a
toothbrush we're not talking about the
toothbrush
we're talking about this here what is
this
what's that stuff we put it on our
toothbrush
and we brush cheeky cheeky
we brush our teeth with this
what do we call it we call it tooth
paste tooth
paste paste is the
material that we use to brush our
teeth toothpaste two words
we put it together so this is toothpaste
that we put
on the tooth brush and we brush our
teeth with it toothpaste okay
next one we already saw this word right
we just saw this
a little bit ago the yellow fruit yellow
fruit it's a fruit because it has seeds
in it the yellow fruit that tastes sour
right lemons taste sour it means
right it's not a it's not a really good
taste it's not
sweet we put sugar in it to make it
sweet
and we like lemons then but it's a sour
taste
and what did i say i just said lemon
these are lemons so if you have many
lemons
right you have many yellow fruits it's
yellow fruit that tastes
sour okay our next word
that's an interesting picture it's the
liquid
liquid is like water right water
inside a bottle that girls use
to smell nice so girls like to smell
nice
they smell so nice right
usually girls use this thing
to smell nice it's made of flowers
many different types of flowers what do
we call it
we call it perfume
perfume per
fume so we have p then we have f be
careful
because p is f is
f do you see the difference
p your lips are together
f your lips are not together your teeth
are on your bottom lip
so perfume
per fume perfume
perfume is liquid that girls use to
smell
nice right
they put perfume on their bodies
okay next one
we have another liquid it's also a
liquid
we cook food in this
so we pour this on the pan
and put food in there and we cook it we
heat it up very hot and we cook food
in this what is it it's very
slippery right we call it oil
oil oil right oil
o i o i oil
oil so we say that this is oil
your mom uses oil to cook
in and we call that
cooking oil cooking oil
there's many types of oil but when we
cook
food in it we call it cooking oil
cooking oil okay
what's this here this is very strong
right
we can tie it to one place
and pull with it a
strong line we tie tie
right can you tie a rope
to something can you tie your shoes your
shoelaces together you tie
something together you tie to things of
course i just said it
it is a rope a rope is very
thick right we call that a rope
this is a rope and we tie it to things
and we can
pull right so rope
rope okay the next word here
we talked about this before right this
is something that you
wash with when you wash your face right
you get a little bit on your hand
or your cloth and you put it on your
face
and you wash your face with it when you
wash your hands
you take this in your hands and you wash
your hands with this it helps make
your hands very clean if you just use
water
that's not so good it's better if you
use
soap soap use
soap to wash your hands
by the way it's very interesting you can
see here
it says 100 percent
vegetal that's a different language it's
not english
but it means 100 percent vegetable
this soap is made from vegetables
it's very natural soap 100
vegetables it's made we use vegetables
to make soap okay
oh are you hungry whoa i'm hungry just
looking at this wow it looks really good
this is what we eat to get energy
we want energy sometimes we get tired
it's been a long day but if we eat
something
we get more energy right so and this
looks
very delicious what is it it's
food food food
okay and by the way there's two types
of food right this
these are all plants we get this
from plants this is meat
meat we get that from animals
so there's two types of food right
vegetables are plants and meats
these are food we eat them to get
energy food okay
here we have an interesting plant
this is a plant with a fresh smell
ah smells very fresh and
it tastes fresh it tastes very fresh
it's really good sometimes we have this
in
ice cream sometimes they put it
into hot chocolate right
it makes the hot chocolate taste
fresh or good it makes our ice cream
taste good what is it it
is mint mint
so you know mint ice cream like
mint chocolate chip ice cream wow really
good right it's
green mint hot choco don't say hot choco
say hot chocolate mint hot chocolate
if we put mint in it it tastes
fresh it tastes fresh it's very good
so we put mint in food sometimes
but we also use mint for other things
like perfume soap toothpaste
if you have mint toothpaste for example
it tastes fresh and it smells
fresh mint okay what's her next word
we talked about lemons before
we talked about lemons before
but this is a drink with a lemon
flavor a drink with a lemon
flavor and you can see lemon is here but
this is a drink
so we put lemons in we put sugar and
water mmm it's very delicious
what is it it's called big word
lemon aid lemon
aid lemonade lemonade
if you say it quickly it sounds like
lemonade lemonade okay
so this is very delicious right if it's
hot
on a summer day oh i'm very hot drink
some cold lemonade it's very
refreshing it tastes good so it's a
drink with a lemon flavor
we say lemonade okay the next one ah
this looks
good right are you hungry i was hungry
before
now i see this i'm hungry again
this is a long it's long yellow
this is the color of yellow this is
green
this is yellow yellow is this color here
yellow vegetable that has a green
skin so this is yellow this is green
the skin is green and then you
pull back the skin underneath it's
yellow
and there are many little pieces right
that we eat oh it's very good with
butter
right what is it of course we say it's
corn
corn is what we eat as a vegetable
it's a long yellow vegetable that has a
green skin
but we use corn for many other things
corn corn okay
wow what's this girl doing she has had a
lot of food she has a lot of energy
right
she is doing something she is exercising
it's an exercise exercise something you
do to make your body strong
an exercise in which in which
the player the player or the person
jumps over a rope many times right
the rope is going around and around
and around and that person is jumping
right they have to jump
over the rope many times
i'm getting tired okay what is it it's
called
jump rope very easy remember we said
that this is like a rope
here and you jump over it it's jump
rope jump over a rope jump rope
two words jump rope jump rope
okay this is another
fun exercise or game right that you can
use a rope
one is jump rope the other is people
pull pull on the rope a game in which
two teams one team
two teams and it can be many people
but two teams one team two teams
two teams hold a rope and pull
against each other they pull against
each other
so these guys are pulling this way this
team is pulling that
way they pull against each other who
will win right who will win this
game what is this game we say it is
tug of war it's like
war two teams they're fighting the war
tug tug means pull
like this pull that's tug so tug
of war tug of war tug of war
it's called tug of war let's play
tug of war it's a fun game you can use
with many people you have two teams
make sure the teams are even right it's
not fair
teams should have the same number of
people
so tug of war two teams okay it's a fun
game
now we see the picture this is what it
is
and this is the definition so let's go
over the definition
a warm coat with sleeves
it's very similar to coat coat and
another word
mean the same thing what is the other
word
we say jacket jacket
jacket jacket and coat
are basically the same right
we say jacket for the covering that we
wear
it's the same as a coat we wear them in
the winter
or when it's cold outside we want to
stay
warm put on a jacket
put on a coat same thing
the next one is another type of
clothing that we wear when it's
cold outside but we wear these over
our hands so this is the picture
the warm thing that you wear
on your hand so if i wear it on my hand
right i put it on what is it
what do we call that we call that a
glove this is a glove this is a very
colorful glove this is a very warm
glove right so we wear gloves
when we want to stay warm a glove
very easy okay the next word
that's so cute isn't it okay to
hold it's a verb two we're looking for a
verb
to hold somebody close in your arms
so to hold that's a verb to hold
somebody close in your arms like wow
these
very cute monkeys right they're holding
each other
they love each other right they're maybe
they're doing it to stay
warm too but in this case we say
cuddle cuddle these two monkeys are
cuddling by the way you may have thought
hug hug
what's the difference between hug
and cuddle ego hago
ego hago otoke torani right
what's the difference between hug
and cuddle hug is very quick it's like
you see your friend hey how are you
doing you hug that person
done finished quick but cuddle
is a long time right and be careful
cuddle usually means like romantic right
boyfriend or girlfriend or parent
and child that's not romantic right but
that's just
people who hold on to each other for a
long time
right cuddle and maybe you know pet the
hair or something
you cuddle you might cuddle your pet
if you have a dog or a cat you cuddle
that pet for a long time hug
hug done finished okay so hug is short
time
cuddle is for a longer time so
to cuddle to hold somebody close
in your arms okay
not thin whoa look at that book can you
read that book
it would take a very very long
time to read this book why because it's
not
thin it's not a thin book it's really
thick it's a thick book
so if we see something that is very wide
right like this then we say it's thick
it has a lot of
thickness not thin thin is like this
thick is like this right okay so thick
not thin the next word we have
look at this it looks like it looks very
soft
right you can put your hand on it and oh
it feels very soft right
it's hair that covers an animal's
body an animal's body not
human right if it's hair that covers an
animal's body we call it
fur fur
not human do not say
human fur we say hair
right so for humans
humans have hair
animals have fur
so humans have hair on their head if we
have hair on our arms
it's not fur it's hair okay
humans have hair animals have
fur and animals have a lot of fur
if you have a dog or a cat they have fur
all over their body so an animal's
fur hair that covers an animal's body
it covers it everywhere
next is a piece of cloth
that you wear it's a type of clothing a
piece of cloth
that you wear there are many types
of clothing this one you wear around
your neck here it is right so if it's
cold outside you wear this and you put
it around your neck
it keeps your neck warm because it's
very cold outside
you can put it up over your face right
to protect your nose and your mouth
so some people wear it up here if it's
really cold
what do we call it we call it a scarf
scarf s c scarf
scarf okay and then rf at the end
scarf okay that's one scarf
but if we have many two three four
five or many we say
scarves scarves
okay you guys try scarves
scarves okay so we have v and
s scars okay don't pronounce the e
scarves so one scarf
two scarves okay so scarf is singular
plural is scarves another piece of
clothing
that we wear to keep warm
okay the next word is a large animal
with thick fur that's a very
simple definition we're looking for
this animal here because there are many
large animals with thick fur right but
we're looking for this
specific one we where do we find him
we find him at the north
pole at the north pole way
up north we find this animal large
animal with thick
fur we call this animal a bear
right now there are many kinds of bears
right
this is a polar
bear a polar bear a polar bear
is a bear that lives at the north pole
it's very large it has thick fur
not all bears live at the north pole
there are other bears that live
further south like black bears
brown bears okay many types of bears
but the bear that lives at the north
pole is a polar
bear okay next word
having a low temperature if something
has a low
temperature low what do we say
it is cold it's
cold outside in the winter time
it is cold it has a low temperature
temperature is the number that says
how cold or how hot it is
outside or inside what is the
temperature
of the air right if it's a low
temperature
it's cold if it's a high temperature
it's hot okay okay
but what about not very hot
or very cold so we have hot
high temperature we have cold
low temperature high temperature low
temperature
but we want in the middle not very hot
not very cold in between we say
it's warm so warm
warm is between hot and cold
it's not it's not high temperature it's
not low temperature
it's in the middle it's warm
usually we are warm in your house
it's warm at your school i hope
it's warm because they're inside
we like to have the temperature
to be warm that's normal not very hot
not very cold it's warm in the middle
okay here we have another piece of
clothing
another piece of clothing this is
something
you wear on your head so you put it
on your head right there are many styles
many types this is one style it's a
woman's
style a woman would wear this this is
a hat very easy hat
do you have a hat sometimes you can say
a cap
like a baseball cap is very common
baseball cap
right that's the cap that you put on
your head it has the long part out here
that protects your face from the sun
most hats
protect your face from the sun but there
are many styles of hats
many different types of hats
okay now here we have an interesting
word the soft part of your body
under your skin so under my skin
it's soft right yeah my stomach is soft
right
if it's hard it's not this but if it's
soft
what do we call it we call it fat
so under my skin on my belly
on my stomach that is fat right
if you work out if you exercise it's not
fat then it's muscle
if it's hard it's muscle if it's soft
and weak then it's fat but fat
keeps you warm right okay so fat the
soft part of your body
under your skin is fat but if you have a
lot of fat
you're warm but you shouldn't have too
much
fat right you should also have muscle
okay an animal that lives
in the water an animal that lives
in the water like this animal right here
that animal
lives in the water it breathes
it breathes in the water what is it
it is of course a fish fish
are very common that and they live
in the water fish are common animals
that live
in the water sometimes they jump out of
the water
and they're fish fish
now the first vocabulary word we're
going to
listen to or learn is this one here
this is a picture of a place
in front of your house what is this it's
a
bell outside the door you
press it it goes ding dong
right ding dong what is that
it's a kind of bell and it's at the door
it's at the door and it's a bell it's a
doorbell that's pretty easy it's a door
bell it's outside the door and it is a
bell
you push it ding dong sounds like a bell
so it's a doorbell in front of your
house
you have a doorbell when somebody visits
you
they press the door bell
so doorbell doorbell
it's two words that make one word
door and bell doorbell very easy
okay the next word what is this this is
very
old right probably you have a small
one in your pocket something you
use to talk to your friend
so you want to talk to your friend you
take this out of your pocket
or your backpack you can
call your friend on it and you can talk
to your friend
what is it what is it called it's a
telephone
teller phone telephone
telephone three syllables or three
sounds
ta la phone telephone
telephone very easy of course this is a
very old
telephone right we don't use those
anymore we use the very small
or sometimes big uh pocket or cell
phones
and we but it's a telephone it's
basically a telephone
that we use to talk with our friend
okay the next word what's this this
looks very interesting doesn't it
this is a clock so it's a type of clock
right
we tell time but look at this what are
these things here those are bells again
another another type of bell right and
at a certain time
those bells sound
right so what is this it's a clock
that wakes you up in the morning
maybe you use this maybe you use your
cell phone
probably you use your cell phone but a
long time ago
when i was younger we used one of these
to wake up in the morning what is it
called
it's an alarm clock
so it's a clock right it's a clock what
kind of clock
alarm alarm means make a big sound alarm
right so an alarm clock is what we use
to wake up in the morning we need a very
loud sound to wake up right
some people need a really really loud
sound to wake up some people they sleep
they keep sleeping okay so you need a
very
loud alarm clock to wake up
in the morning alarm clock
okay our next word wow this looks very
interesting right unhappy
he looks very sad right
because you are alone if he's alone
he's very sad right it almost looks like
a human right
but it looks like a baby gorilla so very
interesting picture
but he looks sad because he's what
he's alone so he is lonely
if you are alone you are by yourself
you are by your self
there are no friends no family
around you you are by yourself you are
alone how do you feel you
are lonely lonely
be careful with el la lonely
we have two l's lonely
lonely lonely so hopefully
i hope you don't feel lonely but
sometimes
we feel lonely because we are alone
there are no friends or family around us
in that time
we feel lonely
okay next somewhere where only
animals live only animals no
humans so it's in nature
some place where there are no humans
and animals live without humans
they don't live with humans what do we
call this place we say it's in the wild
in the wild the wild is a place where
there are no
humans no villages
no towns no roads no
humans around just animals only animals
live there
in the wild wild w is like
wild and then we have ld
wild da da is when your jaw
drops duh wild wild
so in the wild okay the next word
giving help so if something is giving
help
what are they doing what do we say for
this word we say
help full because it's like full right
this word here
full two else means you have a lot of
it's full right
but we only have one l here when we put
it
as an adjective helpful helpful
if somebody or something is
helpful they are giving help so
help full helpful helpful
that is the word that means you are
giving help
okay here's another word this is a very
funny picture right
very cute right we have a small animal
on top of the girl's head
it's her pet right a small animal that
lives
with you and i just said the word right
so a small
animal that lives with you it can be a
gerbil it can be a hamster
it can be a dog it can be a cat
it can be a bird but it's a small animal
that lives with you
not in the wild but in your house we
call that of course
a pet i said that before right do you
have a pet
many houses have a pet like a dog or a
cat
very common pets but also a hamster you
could say
hamster a hamster
is also a very common type of pet
they're fun aren't they they're uh
they're very cute
and also they make us so we are not
lonely
we have some thing to play with or
something
to uh love and to play with okay
what's this guy doing what's crazy what
is he doing
he's it's exciting and not boring
so this kid is exciting right it's kind
of exciting we look at him
what is he doing with his eyes that's
very strange
and his his smile is very funny too
right because he's missing a tooth he's
missing
a tooth so if something is exciting not
boring we say it is fun
it's fun let's do something for fun
let's have fun we want to be excited
we don't want to be bored it's fun let's
have
fun okay here
this man he cannot see
not able to see we know that
very quickly because people who
are like him have a long stick
and it's this color white and red and
they use it
so they can feel where they are going
because they
cannot see what do we call the situation
we say blind this person
is blind it's unfortunate it's too bad
but sometimes this happens so this
person is
blind they cannot see blind
okay so the word is blind
okay now to move from one side
to the other so you're on one side
of the street and you want to go to the
other side of the street
or river or anything you want to go from
one side
you want to go to the other side what do
we say
we say cross i want to cross
the street cross is a verb right
so cross the street
cross the street let's
cross the
street we want to
cross the street so use cross as a verb
let's go across that's different
let's cross the street if you use a
cross that's a different word
cross is the word that we use for a verb
let's
cross the street you should cross the
street here
not here you should cross here
okay so cross is a verb let's cross
the street okay this
is another verb to try to try to hear
sounds carefully so it's very cute isn't
he with the little feet
okay but look at these big headphones by
the way these are
head phones
they're very big for this little boy
really big
and he's listening right he is
listening carefully he's trying to hear
sounds
listen so you listen to something
he's probably listening to music
to listen listen listen
carefully okay if i'm telling you
something
listen carefully but we listen to
different things
to listen to try to hear sounds
carefully
listen okay another one
to stay until something happens
so you're staying in one place and
you're what until something happens
you're staying until
something happens what are you doing you
are waiting so if you before you
cross the street wait don't just cross
the street
stop wait look both sides
then cross the street when it's safe but
you should wait
before crossing the street to stay stay
here don't move wait
until something happens it's safe okay
then we can cross but you should wait
first
to stay until something happens
wait this object here
it's a strange object i've never seen
that before
right what is that things that help you
see
things that help you see what is oh wait
a minute i've got them on my head
right what are these things okay what do
you call them
they're glasses glasses note that we use
plural we say it's like plural it's
one thing yes it's one thing but we use
it as plural
because there are two lenses we say
glasses
glasses okay so these are glasses
okay the next word now this is something
to do
with the one of the senses we talked
about when you use your tongue
right when you taste something the taste
of candy or in this case ice cream
ice cream candy cake
things that have sugar what
does it taste like it tastes
sweet mmm that's good sugar
things that have sugar in them taste
sweet
it's very good right like ice cream
candy
we really like those things right don't
eat too much
i know it's sweet it tastes good but
don't eat too much
because it's bad for your teeth anyway
these things taste
sweet what is the opposite of sweet
pandero
well that would be oh look at this poor
boy right
what is he doing he's eating a lemon the
taste of
lemons did you ever take a lemon and
lick it
right what it what do we say it is very
not sweet
pandiro it's sour
sour right sour is the taste
of lemons it's the opposite of sweet
okay okay now here we have another word
this has to do
with this object here it's
something that grows on a bird's
wing it grows on a bird's wing so a bird
can fly
right but the bird has to have many of
these things
on its wing also all over its body not
just its wing
it looks like this it's very soft if you
take a
if you take this and you brush it
against your cheek right you can use
your cheek
to feel or to touch something ah it's
very soft
what is it it of course is a feather
feather be careful with the f
feather and th the
the feather so we say feather
it's a feather it grows on a bird's wing
and it's very soft if we touch it very
nice
now we have this here now this is an
interesting picture this boy is between
his
father and his mother right and his
mother and his father are holding his
hand
how does this boy feel he's out of
harm's way harm is like danger right
joshua right harm is something that can
hurt you
so be careful you want to stay away
from harm you want to stay away from
danger
if you are out of the way of danger
or you're away from harm what are you
then
you are safe i'm safe right
nothing is going to harm him he's happy
he's
safe between his parents so he is
safe okay before we talked about
feather right we said a feather is very
soft
well here we have an object here and the
word that we have to define it is stone
so basically we're looking for another
word
that means the same as stone
stone is very hard right what is another
word
that we can use to talk about this of
course it's very simple
it's rock rock r
er er rock okay so it's a rock
a rock is very hard don't throw rocks
because if the rock hits you oh it hurts
your head because it's very hard
and it's heavy right so be careful with
rocks
do not throw rocks okay uh
at other people right you can throw
rocks in the water
okay but don't throw rocks at other
people that's very dangerous
okay rocks are hard okay
our next word is this right here what is
that right we have two of them
right i have two of them behind my
glasses
right you see things with this
with this we're only talking about one
now you see
things with this what is it it is
an i and of course we have two so we
have
eyes everybody has two
eyes but if you want to talk about one
you just say ah i
can see with one eye right or cover
one eye so i is singular
eyes plural we all have
two eyes everybody has two eyes
and what do we use our eyes for we see
things that's one of our five senses we
talked about before
another one of the five senses we talked
about before
is to hear and do you remember what i
said we use to here with of course we
have two
but we're talking about just one here
what is this do you remember
it's called an ear ear
so we have one ear two ears
again we just say two ears one
ear two ears
two ears okay so of course you're
listening to me right now you're
hearing me with your ears and you're
watching me
with your eyes okay so those are two of
the senses
we talked about okay oh look at poor
doggy
he's he looks so so sad right so
so pitiful right he's covered
with water if he's covered with water
or you go outside in the rain it rains a
lot
you don't have an umbrella all the water
falls on you
you're covered with water like the poor
doggy here
what do you say the doggy is
wet the dog is wet and we can feel
right if we're wet with our skin that's
one of our senses
we can with our touch with our skin we
can feel oh we're very wet
let's dry off right so we're wet
this is wet covered with water
okay don't do this this is not good for
her
ears right what's going on she's making
a big
noise to make a big noise what do we
call that
we say it's loud it's very loud making
a big noise if something makes a big
noise
we say it's loud right this woman
is very loud and this poor woman
is going to hurt her ear right so be
careful don't do this
it's just a picture but it's showing
loud
something is very loud makes a big noise
okay okay here we have to have
a particular flavor so this woman she
looks like
a cook right she is a cook
and she is making looks like soup and
she wants to
find the flavor she wants to know
what is the flavor of the soup
so what is what is she doing she is
tasting
this is one of these senses we talked
about before to taste
she's using her tongue all right she's
using her tongue
to taste the soup because it's your
tongue not your mouth
but your tongue that we use to taste
food what does it taste like
what does it taste like that is
to have a particular flavor it tastes
now we can taste
something but an object can also
have a taste right the strawberries
taste sweet and that has a particular
flavor
lemons taste sour
so we can use taste in two ways we
people can taste something but objects
can have a taste what do they taste
like what do they taste like okay
then we have to look at something to
look at something wow he's using these
are by the way these are
q binocular that's a big word
binoculars or binoculars binoculars are
really big they're like glasses right
but they're really strong they let you
see things
wow it comes really close whoa right you
look at some whoa it's really close and
it's a lot bigger
so you can really see things that are
far away with binoculars
what is he doing he's looking at
something another word
another word for look is see
i can see that's one of our five senses
now down here we have the verb the verb
changes in form whether we use it
present tense
past tense or present participle pp
right so what are the different forms we
have
see saw scene
see saw seen i see
you i saw him this morning
i have seen that movie
see saw seen okay okay so that's c
to look at something a very young
child zero to one year old oh very
cute right he's sleeping right very cute
what do we
call this person we call this person a
baby baby right zero
to one year old zero is interesting
in american age when a baby is born
the first day we say they're like zero
years old they're just one day old two
days
old okay then we go to months the baby
is three months old
six months old up to a year but before
they're there have been in the world for
one year
we say that they are a baby and by the
way baby
how do we say many babies we say
babies i e s so the y
changes to i e and then we put the s
babies babies so one baby
many babies right okay so that's the
first stage
in a person's life the first step the
first
step or the first stage
in a person's life and we're talking
about steps or stages
in people's lives the first step is
baby what's the next one the next step
is a child who is learning
to walk a child who is learning to walk
from one to three years old they are
learning
to walk they can't walk very well yet
they're kind of going like this right
they're learning to walk they're they're
like this and when they do this
we say they're kind of luck toddling
right they are a
toddler toddler is kind of the idea of
you know a baby
wobbling right like this they're very
careful
they don't walk very well they're not
like a mad robot right maybe i'm not
doing that right but you know
they're toddling right they're a toddler
a person who toddles a person who
doesn't walk
very well yet they're still learning
they're learning
to walk one to three years old they we
call those people a toddler
because they're learning how to walk
they haven't been able to walk
well on their own yet before they walk
what do people do
before they walk like babies
they will crawl crawl is like this
on all arms and legs that's crawling
after crawling people will walk but when
they're learning to walk they are a
toddler okay a boy
or girl between 3 and 12 years old what
do we call that person we use that word
actually on the previous slide when we
talked about a toddler
of course we talk about that person that
person is a
child a child between 3
and 12 years old maybe some of you
are three between between three
and 12 years old i don't think any of
you are three years old
you don't understand me but maybe if
some of you are maybe 10 or 11
or even 12 years old then you can be
called a
child by the way in english what is the
plural
of children if you have one child but
many
do we say childs no don't say childs
say children children
many children at your school there are
many
children in your class there are many
children okay so one child many
children now after a person
after 12 years old right they become 13
14 15 they become one of
these people or in this stage a boy or
girl between
13 and 19 years old
13 and 19
years old so what do we call them of
course i'm saying it
teen because 13 14
15 16
17 18
and 19. all of these words end in
teen right so we say that these people
are called teens now you might also call
them
teen agers teen
agers teenagers that's another word for
teens okay teenager or teenagers
teen is the same word okay now
after the teenage years right this is
quite a lot after
this a long time after okay
a man or woman over 20 because after 19
then they are 20 19 then 20
20 years old that person is now what
what do we call those people we call
those people
an adult adult adults are no longer
children
they are no longer teens they are adults
they are
independent they are responsible for
themselves they can make
their own decisions they don't depend
on their parents anymore they are
independent they are
adults a man or woman over 20 years old
now these are older adults right these
are getting a little bit older
than adults and of course you do have
different stages in adults you have
young adult middle aged adult
or senior citizen let me write those
down for you
very quickly just a little extra young
adult
you can say young adult usually somebody
who is in their 20s young adult
then after somebody gets to be about 40
years old
then you could say middle aged middle
middle aged okay
let me see if middle d d that's d d
m i d d l e h that's an
a a g e d middle aged
and after middle age maybe around 60
after 60 years old
we can say senior
senior sit zen
okay but all of these people all of them
are adults okay so you also have
different stages in the adult stage
okay let's move on to get bigger and
taller so we've just talked about baby
toddler
child teen and adult this process
this change what do we say what's going
on here to get bigger what's the verb we
use
we use of course the verb grow to grow
somebody who gets bigger right they get
bigger and they get taller
as they go along it's very interesting
the baby is so small
when you see babies oh wow they're so
small their fingers and their toes are
so small
but they get much bigger right they grow
into a full adult
so they grow bigger and they grow taller
they grow
what are the different forms of the verb
grow of course we have
grow grew grown
right grow grew grown it's an irregular
verb
you have to remember the different forms
for the different verb
tenses grow grew grown
okay next we have this is another verb
to rest with your eyes closed
at night this is what you should do
don't play computer games right
get in your bed and do this what is this
right what are you doing you need this
especially when you're growing when
you're young
you need a lot of this what is this
person doing this person is sleeping
so she is sleeping get sleep
go to bed get some sleep or go
to sleep right sleep at night what are
the different
verb forms of to sleep
we have sleep slept slept
so this is the same for past tense and
present uh
present participle sleep slept slept
sleep slep slept
okay that's another irregular verb sleep
slept slept to rest with your eyes
closed
usually we do it at night but sometimes
we do it during the day
for a short time if you sleep during the
day for a short time
that is take a
nap take a nap that's a short
sleep during the day take a nap maybe
you're tired
take a nap for 30 minutes or an hour but
at night
you sleep at least eight hours usually
people sleep for eight hours
some people less some people more right
but don't play video games all night
it's important to get some sleep okay
now to begin life we're talking about a
baby
of course the baby there's a point when
the baby comes into the world
that is the time that the baby we say is
beginning life of course
babies begin life in their mother's
wombs in their mother's bodies
but the moment the baby comes out into
the world we have a special verb for
that
what do we say we say to be born
to be born to begin life
when were you born
when were you born okay that's the very
common question
when were
you born you could say well
i was born in 1980 something
or i was born in 1980 some of you might
have been born
in 2000 something right maybe 2000 or
2001.
when were you born what year were you
born
okay what year did you come into the
world born
okay now this is a verb that
we talked about before actually to go by
moving
your feet right toddlers are learning
how to do this
toddlers you remember i talked about
this toddlers are learning how to do
this
what is it it is of course to walk
to walk right to move by moving your
feet
now of course walk you could also say
run but run is to move fast or to go
fast
by moving your feet to just go normally
normally people walk
they don't run so to go by moving your
feet you
walk okay if you go fast that's run
okay to say things
so you're with your friends right and
you say
things to your friends they say some
things to you
in return so what are they doing of
course we say
they are talking to talk talk talked
talked okay talk to talk with people
of course talk is a regular verb so we
don't have to worry about the different
forms right
talk talk talk okay so these people are
talking to say
things to each other let's talk okay
or they are talking to each other okay
what's our next word
our next word is another verb to right
to make to make pictures with
a pen or pencil you probably
do this a lot even at school you do this
what are you doing you're making
pictures
right maybe a house people or
landscape with trees maybe fish or
animals
but you what are you doing you're making
pictures you are
drawing to draw
to draw means to make pictures with a
pen or
pencil now draw is not a regular verb
it's an irregular verb so what are the
different
verb forms what are the different forms
of this verb
we have draw drew drawn
draw drew drawn
so this verb draw drew drawn okay so to
draw is to make pictures
with a pen or a pencil also you could
yeah with those pens or pencils that's
drawing
if you use a paint brush then you're not
drawing you're painting
okay so that's different okay paintbrush
that's painting
but pencil or pen then you're drawing
okay that's an interesting point okay
very nice to look at oh look at this kia
jio right kipchi
a little cat is very what we say very
cute a cat is cute of course but not
just a cat
there are many things that are cute like
for example we're talking about babies
babies are very cute right when they're
not crying and they're like
that's not cute but usually babies right
and they make the little faces
that's very cute right so we say very
cute
very nice to look at it's very nice to
look at something
that is cute it's also very interesting
right cha misoyo
right but it's also very cute
right oh kia wild right that's very cute
okay the first word has to do with this
picture here
what do we call this here
this is trees cut up
cut up for making something
we make a lot of things from trees
we've talked about this in previous
lessons probably you've
we've studied together on a previous
lesson we can see that trees are used
for what
trees are used to make wood we use
wood to make other things like houses
furniture desk chair toys
you can have toys made out of wood
these things are wooden right a
wooden chair a wooden desk
a wooden toy things made
out of wood wood
okay what's our next word the next word
has to do with this here
of course it's been cut this is a tree
that has been cut
but what is the main stem of a tree
if you remember or if you studied about
plants you know there are many different
parts of a plant right there are the
roots
there's the stem there's the branches
the leaves right the flower in some
plants
but on a tree right the stem we have a
special word for it
because a small plant we don't say this
word but for a big tree
it's strong it's thick and we use it to
make
wood what is this part of the tree
we call it the trunk trunk
tr tr
trunk trunk we call it the trunk
of a tree we don't really say the stem
of a tree that sounds a little strange
in instead we say the trunk of a tree
but if it's a small plant yes you can
say the stem
but a big plant like a tree that's weird
we would say the trunk of a tree not
really the stem of a tree that sounds a
little bit strange
so it's better to say the trunk of a
tree and it's the trunk
where we get our wood from most of our
wood
you can get some wood from the branches
yes but mostly
it's the trunk where we get our wood
okay if you look at the trunk of a tree
that's been cut right this way not this
way
but this way you can see these things
here what are these there's
round circles these are a
circle or many circles inside a tree
trunk
so we want to know about one we're
talking about singular not
plural one of these is called a
ring a ring a ring basically
is a circular shape right many married
people
have a ring on their finger right it's
just
it's a round shape like a circle right
and we call these
rings right rings many we say
rings so r sound er
ring an ng
so we say ring a circle inside a tree
trunk
wow you can see many rings inside the
tree
now we have another word that we can use
look at this tree this
is a very very big tree
it's big we use a special word to say
something that's very big
this tree trunk of course this tree
trunk is big but look at this tree
wow it goes from here all the way over
to there
that's really big and this is a person
here right so that's your scale
right it's very very big these trees
probably are growing in northern
california or
oregon washington the trees are really
big
in those states in america what do we
say they're really big
one word we can say they're huge
they're huge they're really really big
if you go to northern california oregon
or washington state you can see these
trees
in the forest you are you go wow they're
huge
they're so amazing we say huge huge is a
good word to use
it means very very big
okay now we have another word here
that's interesting
because we want to say that this person
is
in the middle point of something
they are right in the middle of
something
you have an area or maybe a room but
you're right
at the middle point of that room
or that area where are you you are in
the center
we say in oops in
the center in the center
in the center of the room in the center
of the field right in the center of the
paper
something that is in the very middle of
something the exact
middle of something they are in the
center of it
in the center so here we have
a lot of fruit a lot of fruit right
more than enough there's there's enough
food to make us full but there's more
than enough we can't eat all of this
food we can't eat it
so we have plenty we have plenty
of food we have plenty of fruit
we have plenty of wood we have plenty of
air right so we have more than enough we
have
plenty we have plenty of food please
come over
share our lunch i have plenty of food
i can share my lunch with you i have
plenty
okay another word we have to watch
something if you're watching something
what are you doing you're looking at it
so this woman is
looking at her shoe right she's trying
to get her shoe
maybe she can't but she's looking at it
right she's trying to grab it
her shoe is under her bed but we look at
things
look at and watch are very similar you
watch a television show you look at
your television you watch a television
show
you watch your dog you look at your dog
right
so when you watch something you but by
the way when you watch something you
watch it for a long time
when you look at something it can mean
you look at it for a long time
it can also mean you look at it to
examine it what what's going on what is
it okay
so look at and watch are very similar
you look at something
you watch it c is very quick do you see
it
yeah i see it it's over there go get out
but i see it right that's very quick
but you look at it
oh okay i'm watching it okay so you look
at or watch something
and then you see it very quick well i
see it it's right there okay
okay so those are the differences
between look at watch and see
okay to make a tree fall down to make a
tree fall down
this was a huge tree it fell down and
then they cut it
into pieces they're gonna make wood out
of it right what do we say
we cut down i just said it they cut the
tree down they cut it down
and they cut it into different pieces
but when you cut down a tree
that means it falls down by the way in
america
when the workers go in the forest and
they cut down a tree
they yell something what do they yell
they yell timber
right timber timber
timber it means the tree is falling down
but timber also is another word for
wood it's interesting right so it's like
the workers are
going out they cut down the tree wood
but they don't say wood they say
timber and that means watch out joshua
male get out of the way
right so that's very interesting if
you're in the forest in america
and you hear somebody say timber look
around right
there might be a tree falling down
hopefully not
but probably not but anyway that's what
they say when you cut down a tree
that's what happens you make a tree fall
down you make it
fall down okay something round
we talked about that our ring is round
but a ring makes a shape what is the
shape called
it's a circle this is a
circle we can also say it's a ring like
the ring on my finger
or the ring in a tree it's a circle it
makes a circle
it's round so something that is round
it makes
a circle makes a circle that's the
shape the circle is the shape it is
round you could also say
it has a round shape also a ring
a ring is a round shape it is a circle a
ring
makes a circle okay
not inside these people are not inside
their house
they are what the opposite of inside is
outside that's very easy right
in in out opposite
inside means inside a building in a
building
in a building
someplace where you have a roof a
ceiling
and walls around you you are inside
in a building but if you are out
of a building there's no ceiling
above you is sky around you just
air right then you are outside so
inside in a building outside out of a
building
okay so inside outside
next to add up to find the total
so this girl is using a very old device
to do what she's doing what what is she
doing she is
counting to count one
two three four that's one way to count
another way is to add up to find the
total let's say you have many pieces of
candy
you want to know how many pieces of
candy do you have
you go one two
three four da 15
20 50. i have 50 pieces of candy right
so you're counting the pieces of candy
don't eat 50 pieces of candy you will
get a stomach ache right just eat one or
two pieces of candy
but to add up the to find the total
you're counting something
one two three four and so on
to count okay the next word is kind of a
funny picture right
these guys are buddies but you can see
there's a big difference
between these two gentlemen here right
this guy's
huge this guy is not huge
he's not thick by the way thick thick
also means
you're gonna like this right he's not
fat it doesn't necessarily mean fat
it just means that he's got a wide
body right he's got a wide body he's
thick
he's not thick when a person isn't thick
we say that they are
thin thin so thick
and thin are opposites pandero right
pandiro
this man is thick this man is
thin but we don't really say people are
thick
we kind of say he's big right he's a big
guy
he's a thin guy you can't say thin thin
is used for people it's also used for
trees
right or other things right a book a
book can be thick
or a book can be thin a thick book
a thin book a big person a thin person
okay we don't really say he's a thick
person we say he's a big person we have
here
a picture a place with trees and animals
a place with trees
and animals i was just talking about
this place
do you remember what the name of this
place is
starts with an f of course it is a
forest when you say forest remember with
the f
your teeth are on your bottom lip
forest so this is a forest a place with
trees
and animals what's next next we have
a safe place to be remember this cute
guy right here
right he's looking out from his home
well he
of course lives in the forest or she
we're not sure but they live in the
forest this type of animal
and many types of animals will make
what inside a tree right they will
make a shelter shelter
and shelter is the same word or it's the
same meaning
really for many animals it's their home
isn't it
right so this animal will find
shelter in a tree they'll make it their
home
so shelter is like a home for many types
of animals
in the forest okay what else
we have what's this boy doing right he's
holding on to a tree and he's going up
into the tree here it says to go
up like a monkey right so if you think
about monkeys we saw the picture before
of the monkey
what do monkeys do really well right
they can go up in the tree
very quickly what is the verb that we
use to describe
this action what is this boy doing he
is climbing of course climb
is just the root form climb to
climb he is climbing
the tree whoops he is climbing
the tree the boy is climbing the tree
can you climb a tree but be careful
right make sure your mother or your
father
is watching you when you climb the tree
it can be dangerous so be careful
but he is climbing the tree okay
the next we saw this picture before
right here is a bird
now a home built by a bird
before we talked about shelter right and
we saw the
the squirrel the the cute animal looking
out from the shelter
this is a type of shelter but it's a
special word
for birds only birds make
this right what do we use for this a
word we call it
a nest a nest so we set talk about a
nest
you should think ah it's a bird right a
bird
makes a nest and a nest is the home
for the bird it's their shelter it's
also their home
for birds we say it is a nest
okay interesting okay now we have
another type of home right we've talked
about
shelter we've talked about nest now this
is another type of home and this is a
interesting looking animal here right
kind of looks like a dog
but it's not really a dog it's a
different type of animal
and this animal will live in a home in
the ground
so many animals will dig in the ground
and they will make their shelter or
their home there's a special word for
this what is it
we say it's a cave okay
now sometimes animals will will make a
small cave
or maybe there's a big cave that they
don't make
but they will live in there what lives
in caves
well wild dogs perhaps hyenas
a hyena is a type of dog a hyena
is a type of wild dog in africa this
looks like a hyena but also big animals
like bears right be careful if you're in
the woods
and you see a bear bears are very big
animals
and they also live in caves okay so
cave is another type of shelter okay
these are all shelters a nest is a
shelter and a cave is a shelter
okay another word that we have here
is the plant part so it's a part
of a plant the part of a plant
that holds the seeds so the seeds of
course
are what the plant makes and the seeds
will go into the ground
and make a new plant right seeds are how
plants
make more plants what do we call the
part of the plant that holds the seeds
we for many plants it's called the fruit
right so bananas are a type
of fruit apples are a type of fruit
watermelon right that's a type of fruit
and if you look at each of these fruits
they all
have seeds in them and if you take those
seeds and you put them in the ground
a new plant will grow okay so we call
that fruit
okay not all plants but many plants
have fruits and that's how they
distribute their seeds
okay insect we have an insect here
and of course another word for insect is
bug you may know this word from the
movies right
so there's in english of course there's
a lot of uh
words that have two words that mean the
same thing right
insect insect is more formal it's a
little bit more of a difficult word
isn't it it's much easier to say bug
bug right and that's what insects are
insects
are bugs and this is an example of
a bug right so you can say bug or you
can say
insect same thing
is this we talked about this before do
you remember what i said at the
beginning
of this lecture this is an animal with
long arms right he has long arms right
and a long tail so a long tail
not just long arms but also a long
tail and what type of animal is this do
you remember what i said at the
beginning
of this lecture we said monkey
so say it with me monkey monkey
okay so this isn't a monkey and we
learned about uh the monkey we also when
we looked at the picture with climb
the boy is going up the tree like a
monkey
monkeys are very good at climbing aren't
they so
you find monkeys in forests but not
cold forests not up in korea well maybe
up in korea
and in japan you find monkeys but also
more commonly
in the south where the trees where the
forests are
warmer there's many monkeys that live in
the forests
in the warmer forests uh
near in the south okay
again the next one a place where people
live we talked about this already
in terms of animals right we've talked
about shelter we've talked about
nests for birds we talked about caves
for wild dogs or bears but people
where do people live of course we live
in a house right
people build a house right you could
also say
home but home and house is where
somebody lives house though is house
means the building
home is like a place that you're
emotionally connected to
this is my home this is where i live
people can live in an apartment they can
live in a tent
they can live in a cave those are all
homes right
but a house is something that's built
like this right it has doors it might
have a chimney it has walls
that were built by people so we've seen
a lot of different types of shelters
because this is
also a shelter so we've seen uh nest
cave house these are all shelters
okay next we have something
used to travel on water
can you walk on water no you'll sink
right
be careful right you jump in the water
you will sink
but if you want to travel over water on
top of the water so you don't
sink what do you travel in what is this
this of course is called
a boat a boat and some boats are very
small
like this some boats are very big
they're like hotels
and they go across the water okay so
something used to travel on water
is a boat
okay this young girl is doing something
very good right she's helping her mom
out she is getting rid of
some dirty uh stuff on the ground
so if you say something is not dirty if
it's
not dirty the opposite of dirty what do
we say
it is clean so clean can be an
adjective right we can use it as an
adjective
it is clean
we can use it as an adjective the floor
is clean we can also use it as
a verb please
clean the floor
so we can use it in two ways okay
as an adjective it is clean the floor is
clean or if mom
sees some dirt on the floor she will say
to her daughter
please clean the floor and that's a verb
please clean up your room right please
clean up your desk for example okay
so we can use it as an adjective or as a
verb
very commonly okay the next one
an animal with feathers and wings
we already talked about this type of
animal right this type of animal
what type of shelter does it make in the
trees
it makes a nest what is it of course
we know it's a bird and there are many
different kinds of birds right
many different shapes different sizes
different colors but we all if they have
feathers and wings we say it is
a bird okay so we see a bird here
a warm and rainy season
so it's a warm season a lot of rain
comes down
and as we can see there's lots of
insects come out
flowers bloom what season is it
we say it is spring spring
okay so in spring life comes out
it and it also rains a lot okay next one
is a hot season kids go swimming they
enjoy swimming it's very hot
so you can wear a bathing suit no
problem
we talked about that what season is it
it is
summer summer is a
hot season okay next one
we talked about this a dry and cool
season it's dry
doesn't rain a lot leaves fall
from the trees it's cool so you have to
wear more clothes
this of course is fall you can also say
autumn but a simpler word is fall
it's easier to say fall in
the fall okay next one we talked about
this one
a cold season there are snow
flakes falling down we can make snowmen
so there's a lot of snow
it's a cold season what season is it
of course it's winter winter
it is cold in winter
let's learn some more words about
seasons let's take a look at this this
is an
interesting picture here when we talk
about the seasons
remember i said there are four seasons
and this picture shows all four
seasons usually we
start with spring spring
summer fall winter
and then it starts again it's like a
circle right
we start with spring because that's when
life comes back out
in the winter everything seems dead but
in the spring it comes back out
and the time of the year with special
weather there are four of them
and i use that word already of course
we're talking about
season there are four seasons spring
summer fall and winter they are all
called seasons and there are four of
them
okay let's take a look at this word
here we have a lot lots of vegetables
here clean
and new is our definition what word are
we looking for
of course we're looking for fresh
because
especially when you think about food
you want your food to be fresh
so tomatoes are bright red they're
round and they're strong right if
they're not fresh they're
old and they don't taste so good right
but you want fresh food right so clean
it's clean and it's new not old
it is fresh
let's take a look at another word look
at this here are two birds right here
is a small bird and here is a
what not small of course we're looking
for big here's a big
bird right big bird okay so sometimes
you can see very big birds
sometimes they're small birds but of
course there are many things that are
big
many things that are small something
that is not small
the opposite pandero is big
not small pandito small big okay
very warm if something is very warm
remember
when i talked about summer i said it is
what
it is hot it is hot
in summer so very warm warm
is kind of a little warm but
hot is very warm right so you go from
cold let's do a little chart here cold
is really right freezing lots of snow
but next is cool
right cool is not as strong as cold
it's a little warmer and then after cool
we come to warm okay
so warm not cool anymore and then after
warm a little stronger is
hot so we can have a little chart here
cold
cool warm hot and of course they go in
degrees
okay so hot is very warm
now we have to move through the air like
a bird
can you move through the air like a bird
i'm sorry you can't
unless your big brother or sister throws
you
right then you do what you
fly but your big brother or sister
shouldn't throw you
unless you're going to land in a
swimming pool okay
flying can be dangerous because landing
well flying isn't dangerous
landing is dangerous right okay so to
move through the air like a bird
means to fly and that's very interesting
okay
so fly but fly is
a special verb in english it changes
form depending on how you use it
especially in the past tense
what are the three changes we say fly
flew flown so remember
fly flew flown fly flew
flown those are the three different verb
tenses
for the verb fly okay
now we have a word here for water to
fall
from clouds so when sometimes
right you go outside and you feel wet
what's going on
there's water falling from the sky from
the clouds in the sky
it falls down what do we say it's doing
we say
it is raining now rain can be
a noun right it
is rain so we say it
is rain we can say
there is a lot of rain or there's just
a little rain that's a noun we can also
use it as a verb it
is whoa it is raining
it is raining today or it will
rain tomorrow it rained
yesterday so noun or verb
with rain it is rain a lot of rain a
little rain
noun verb it is raining it will
rain it rained this morning
okay moving on being alive
a short time okay so we have
actually it's kind of like a contrast
here here we have an old man
right he's been alive for a long time
then we have a boy here right and the
word we want is the word to put
next to the boy because the boy has been
alive
only a short time so what do we say
about the boy
if the old man is old we say the boy is
young right so that would be the
opposite
of old young and old opposites
okay to get ready
looks like this woman she wants to make
a meal right she has a lot of food
she's going to get ready what is she
going to do she's going to prepare
prepare a meal probably your mother
or maybe your father prepares a meal
every day sometimes prepares three meals
a day
but at least it's prepared once a day
that's dinner right
dinner is prepared every day to get
ready
but prepare isn't just food you
prepare to prepare is like jun bi hada
right june bihar i think so
when you get ready for school you
prepare
you put your books in your bag you put
on
your school clothes you're preparing to
go to school
so when we get ready for something we
are preparing
we prepare for something we prepare for
dinner
or you can prepare something you prepare
dinner
you prepare your bag you prepare your
notes
okay what do we see here this is an
interesting picture
isn't it we have little pieces of wood
standing up
right and we have somebody's going to
push it right
and that's going to hit that and they're
all going to fall over
so we're going to make something happen
to make something happen
we're going to cause one to hit the
other and the other and the other and i
just use the word there
right to cause cause
so if you cause something that means
you made it happen if you cause all of
these to fall down
right you made it happen to cause
something to happen the wit
the tornado caused the car
to fly away okay so something
makes another thing happen to cause
okay next word this is a type of weather
right
this this little girl right she's in her
coat she's in her
knit hat and look it's
very strong the wind weather with
fast moving air the air is moving
past her very quickly in this case
what is the weather we say the weather
is
windy windy it's very windy so the wind
is strong it's windy
okay the next one
strong dangerous weather strong
dangerous weather of course we talked
about tornado
but we're looking for not just tornado
but any type of weather
any type of weather that is
dangerous or strong we could say storm
it is a storm so a tornado is a
type of storm but there are other types
of weather
for example it rains a lot
and there's lightning and thunder that's
a storm
if it snows a lot too much snow
your parents can't drive their car
nobody can
move everybody stays inside that's a
storm a snow storm so
some storms are very big and cause a lot
of water
rain or snow to fall down
very quickly and we call those storms
okay i taught you this word before do
you remember seeing this picture before
right this is dangerous bright light
from storms okay dangerous bright light
from storms we say it's light ning
just two sounds light ning lightning
it's lightning and of course with
lightning i also said something else
with lightning you also hear thunder
right so thunder and then after
oh actually before thunder you see the
lightning you see the flash
and then a little bit later you hear the
thunder
so thunder and lightning very common
uh thing in a storm to experience
okay so lightning the next word oh my
gosh
look what happened it's terrible right
there was a
strong wind maybe a very big storm
very strong winds and it pushed this
tree
over onto this house that's terrible
these poor people who live there right
to make
into nothing what did this tree do
it made the house into nothing well
maybe they can save it but you could say
destroy
the tree destroyed the house
sometimes in a flood there's a lot of
water the water will come
and it might bury your car under the
water
and you can't use your car anymore your
car is destroyed
okay so storms are very dangerous they
cause a lot of damage storms destroy
homes cars many
things that are destroyed in a storm
okay the next word we saw this picture
before right the people with no face
okay let's take a look of course but
we're looking at the water again
a lot of water that goes onto land
so usually the water is in the river
or it's in a lake but if it there's a
lot of water comes from the sky
in rain or as snow then maybe that water
will come onto the land
and cover everywhere and of course we
say that is a
flood now by the way flood
can be used as a noun
for example there
is a flood
there is a flood that's a noun
there is a flood but flood can also be
used
as a verb the
river flooded
over okay or you could also say
the town flooded that means the town was
covered in water
so we can use flood as a noun there is a
flood
or a verb the river flooded over the
river got too big
and it flooded the surrounding area so
we can use flood as a noun or as a verb
okay next one to begin these
uh boys are running in a race right
at the start of the race right at the
start of the race
they begin to begin means to start
okay to start okay
here we have another word this is a an
interesting picture all these pieces of
wood seem to have fallen down maybe they
they they made something like a tower
before
but they fell down so to make something
fall
down this is a kind of a special word
it's a little bit of
a difficult word it is to
topple to topple pronunciation
topple topple to topple
if something falls over especially
something that's very
large very big and tall it will fall
over
it will topple so imagine if you cut
down a tree
the tree falls over we say the tree
topples over
buildings might topple over okay
so to topple means something very tall
falls over whoa
he looks kind of interesting does he
look like me
maybe okay he's a weatherman right
now news that tells us the weather
news that tells us the weather you want
to know
about tomorrow will it be
sunny will it be windy is there a storm
coming
so you want news that tells us the
weather
what do you want to look at you want to
look at
the weather report this is the
news that tells you about
the weather okay
here we have an object here it's a very
colorful object
they're not all like this maybe i'm sure
you have
one of these at home it's a tool
a tool is something we use right
a tool we hold we hold in our hand
to keep the rain off it's raining
outside
you don't want to get wet so you use one
of these
to keep the rain off you want to stay
dry right you don't want to get wet
you want to stay dry you want to keep
the rain
off what is it usan
in korean umbrella in english
okay so i'm sure you have a uson jipe
i'm not sure if my korean's that good
but do you have an umbrella at home
i'm sure you do okay so umbrella
okay now in the summertime oh
it's really hot isn't it if you're in
the park
and you're out in the sun the sun is
hitting you oh it's so hot
and you sweat dumb money hail right oh
no
right i'm very hot so it's too hot in
the sun
you want to but you don't want to go
inside a building you want to enjoy the
park
so maybe you go under a tree or maybe
there's an umbrella
a big umbrella so you want to go to an
outside place
with no sun like these
ducks are smart right they're not
in the sunlight they went in the dark
area under the tree a place with no sun
what is this dark area it's a little
cooler there right we say it's the shade
shade so if you're outside you're in a
park
or you're playing soccer and the sun is
too strong
maybe you want to go in the shade
go in the
shade in the shade
because the shade is cooler
than in the sun you don't have the sun
hitting you directly so it's a little
cooler
in the shade it's a little cooler
in the shade okay
num the next word to move air
now we talked about windy right this
picture looks like it's windy
but windy is an adjective it is
windy right it is windy outside
that's imaginative but we're looking for
a verb here to move
air why is it windy what is the
action what's happening well we're
looking for the verb
blow when when the wind
blows right then the air
moves we can blow
right you can put your hand in front of
your mouth
you can feel the air moving i am blowing
right blow blue
blown this is an irregular verb so it
changes
according to how we use it when we use
it
in now to blow that means right now
blue past tense blown past participle
have blown
right blow blue blown
blow blue blown so
in english i'm sorry some words you have
to some verbs you have to know the
different
forms when you use them in different
time periods okay so blow
first word that we're going to go over
here is
to become something else this is a nice
picture right
it's the picture of the same thing it's
changing it's changing from this little
uh
piece here you can see the butterfly is
coming out
so the caterpillar used to be here
but the caterpillar changes
becomes something else what does it do
it
turns into it turns into
a butterfly to turn into means
to change from one thing to another
the caterpillar caterpillar
you know the caterpillar the the little
green insect that crawls around looks
like a worm
the caterpillar turns into
a butterfly a beautiful butterfly
and that's what turned into means to
change okay next word
number two these are very pretty rocks
aren't they
very nice looking rocks what are they
they are a special type of rocks an
important part of rocks
they are minerals now these are large
you know they're kind of big right but
when plants grow in dirt
right the plants take the minerals up
from the dirt
and the minerals are in the plants when
we eat the plants
we eat some minerals very small very
small pieces
of minerals but they're good for our
bodies we need those
things we need minerals and we need
vitamins
so minerals are an important part of
rocks
they're also good for us but don't eat
these you'll break your teeth
right just eat the plants you can't see
the minerals
in the plants but they're good for you
okay
next word oh it's too bad it's sad
here's a fish the fish is out of water
the fish cannot live out of water so
it's not alive
what's another word that means not
alive the word of course is dead
dead the fish is dead so something that
is not alive
is dead okay the next word number four
here we have a picture of a lot of dirt
but there's also some plants here
right and we have this uh definition
to break down to break
down if you imagine that this is a lot
of plants or maybe we could put some old
fruit like some old apples or some old
oranges
on top of there and after a while it
begins to smell
right because what is it doing it is
rotting too rot this is a verb
to rot means to break down
and usually things get oh they get
smelly right
and they break down over time and they
go back
into the dirt they go back into the soil
to rot to break down
okay the next word look at these guys
they're having fun
right they were hiking all day now they
are at the
highest position in the mountains where
are they
they are on the top on the top
on the top
right they are on the top of the
mountain so
top is the highest in position it's the
top
thing the thing that is on top right
to be on the top top okay
number six the gas that we breathe
right if you breathe
you can feel the wind right the wind is
gas
what is that gas that's all around us we
breathe it
we need it so that we don't die so
that we stay alive what is it it's
called
air air air is all around us
right it's the gas that we breathe
remember we can't really see the gas
the gas is very light we can move around
in it
right but we breathe it that's the gas
that we're breathing
that's called air okay next word
number seven to keep in place
okay this is an interesting picture
somebody has
a strong grip on their money
right ton okay because it's very
important
but what are they doing if you have like
baguan or obeguan in your hand
you don't want to lose it you put in
your hand you close your fingers around
it
what are you doing what is that verb
hold you are holding your money
also when you go on the street and
you're walking on a busy street
hold your mother's hand hold your
father's hand
because you don't want to get in the
street it could be dangerous hold your
brother's hand or your sister's hand to
take care of them okay
so you hold now this is an irregular
verb
it changes so we say hold
held held right hold it's a present
tense held past tense and held
pp right hold held held
okay good next word i kind of talked
about this before
a little bit when i talked about air i
said
air is all around us in all places
another word we could use everywhere
it's a big word right everywhere that's
a really big word
if you look at the sand right there is
sand
sand is a type of dirt by the way but
sand is not
good dirt things don't grow well in sand
but
in the desert sand is everywhere
right right now air is everywhere
right okay so everywhere in all places
everywhere around us okay next word
number nine at a lower place
so here we see a man he's sitting by a
tree the tree is very tall
right the branches and the leaves are on
top
there they're on top where is he he is
below he's below the branches
and the leaves he is below so what could
say
here is a pen right here's my hand the
pen
is below my hand okay so below
at a lower place
number 10 kind of
slimy right i said slimy slimy is
uh you know it's a little wet
and it's a little soft right that's
slimy
do you want to pick up that worm i'm
sure the girls in the audience they
don't want to pick up that worm
the boys are like yeah let's pick up the
worm right okay but it's a little
slimy right and we can see this worm
in the dirt which is very wet it's
also slimy but when we see a mix
of rotting stuff and soil
so imagine that there's like old uh
fruit
on the top right it's just kind of
rotting and and breaking down
uh and it's a mix of that stuff and soil
there's a special word we use for it
it's a little hard to pronounce but look
at this word
it's humous
hue mus two sounds two sounds
hue mus humus so we say
humus that is the mix of rotting stuff
and soil good for growing plants
okay now here we have an interesting
picture we have many green apples
they're a little sour
right green apples are a little sour and
then we have one
red apple it's a little more sweet right
when we say not the same there's many
words that mean not the same we're going
to look at one word here is
other right these are the all the green
apples
i the other apple is red
i have many green apples but the other
apple
is red so something that is not the same
as
other as as the what you have that is
the other right when you're saying
something is different not the same
the other okay
having a special use something that has
a special use
what do we call that we can say it's
important
right here we have a picture of a little
girl
and she's getting ready for bed maybe
she's praying
and she has a little teddy bear with her
right
the teddy bear is very important
to the girl what is important
in your life do you have a toy that is
your favorite toy
it's very important to you maybe you
have a book
that you like to read that book is
important
but also think about your family your
family members are
very important your mom is important
your dad is important
your brothers and sisters i know
sometimes we fight
but they're important to you too these
are things that have
not just a special use but a special
value
to you they are important okay
this is a home right a place where
something
lives is of course a home many homes
are made from bricks and bricks are made
from soil or dirt we live in dirt
homes is it dirty no
it's clean because of the way we make
bricks
that's what we're talking about how
different homes are made
from bricks and of course we're going to
look at not just this word
but many other words for this lesson
let's go for number two
the second word to cook in an
oven this of course in the background
that's an
oven right you put food usually
you put food in an oven lots of heat
and you get a nice loaf
of bread or cake that comes out and of
course this means to
bake when you put food in the oven
lots of heat goes on it and you bake it
so you bake a cake bake a loaf
of bread something like that so to bake
here of course is what we were talking
about before right we just used this
word
it's actually they say a space for
cooking at a high heat
a space is on the inside of course this
is a device
or appliance that you find in your
kitchen
appliance
there are many appliances in your
kitchen
one appliance of course is this thing
which we just
talked about that's an oven an
oven by the way just for your
information this part
is the oven this part
don't say oven this part is
stove the top is the stove
the middle part is the oven
okay next one wow big house right
looks like a castle right very
strong and lasting lasting means
it will be there for a long time
right lasting for
a long
time like this house this
castle house just one house very rich
person
or big building this has been there for
a long
long time right so what do we say it's
sturdy it's a sturdy
building it's a sturdy building
it's very strong and it will last for a
long time
it will be there for a long time it's
already been here for hundreds of years
that's a long time this
building is very sturdy okay next word
this of course here is what do we call
this couple of birds are sitting on it i
hope they're not angry they don't look
angry
they're just birds right okay so a
couple birds on top of this one
what holds a roof up of course this is a
wall
these birds are sitting on a wall
a wall holds a roof up right if you
have a a roof over your head what holds
it up
the walls the walls have to be sturdy
if the walls are not sturdy the roof
falls on top of you
right so walls walls should be sturdy
what's this here this looks interesting
it's a box that's not a box
it's a block a block used to build
things and we
we put these things on top of each other
we call this of course
is a brick we said it before when i
talked about a brick
wall right bricks there are the little
blocks
that you use to build a brick wall
remember the wall we just saw
the birds were sitting on it it was red
there are many bricks
in that wall now
when you take bricks and you put them on
top of one another or you take
books and you put on top of
each other right you take
one one book and you put it on top of
that book and on top of each other you
keep putting more and more and more
and more books what are you doing this
is a special
verb it's to stack it means
to keep putting on top of each other
right you have one book
put another book another book another
book another book
or one brick another brick another brick
you're stacking the bricks or books
on top of each other or whatever it is
can you stack
apples if you're really good you can
stack
apples but not too high they'll fall
over
books are easier to stack bricks are
easier
to stack ok
a straight line so here we see that we
have many straight lines right going
this way
this is a straight line a straight line
a straight line
you could also go like this a straight
line a straight line
what do we call these we call these rows
so if you go to a movie theater right
younghua
right you can see many uh
seats and your ticket has the number
and the row on your ticket so you know
where to go it says
row h so you go a b c
d e f g h
h that's my row then you go over to the
number
so look to find out what row you are
in and then you can find your seat so a
row especially when we talk about
seats we talk about rows in a big
theater or stadium for example
okay let's move on to number nine whoa
what's that
that's a really weird soup right tsubaki
what the heck okay that's just a funny
picture
it doesn't really look like that right
having
four straight sides
four straight sides of course it would
be square
is a subac square tsubak watermelon
watermelon
is a watermelon square
that's crazy right watermelons don't
look like that
that's just a funny picture watermelons
are round right they're round
or not exactly round like a like a ball
you could also say oval oval
is like a watermelon some watermelons
are exactly
round like a ball that's true they are
round perfectly round
but usually watermelons are longer on
the ends
right and not so long on the top and
bottom so we say they're
oval so many different shapes square
would be like a box
right if you have a box that is
a square box am i a good artist
yeah kind of i guess okay that would be
a box it's a square
box okay that would be square okay
number ten
uh-oh what's wrong with this guy
someone who builds but he's not building
very well
look he's making what what's going on
there you need another brick over here
pablo okay and look he didn't fill up
that that
position there he needs more experience
don't hire him okay but anyway oh
someone who builds this is
interesting this is easy right someone
who
builds this is your verb to
build but we want to say a
person who does this so it's very easy
just take the verb
b u i l d
and add e r e
r ah there we go that's our word builder
and you can do this with many verbs in
english
yay right someone who
drives to drive if you go to
school right sometimes you ride in a
school bus
or you just take the city bus the person
who drives the bus is a
driver driver
okay so many verbs in english
you just add er not all of them
but many of them it's a common way to
use the verb to talk about a
person who does that thing
okay so uh a builder but we have to be
careful with this guy he's not a
good builder right he's making some
strange uh
problems here okay anyway let's move on
number 11.
now here we have a by the way this is an
exception right what is he doing he's
cooking
to cook to cook but don't say
cooker don't do that that's an exception
we say he's a
cook don't say cook er
right that's that's an exception i'm
sorry
english has many exceptions but don't
say cooker
he's a cook what is he doing he's
mixing together with a big iron piece
or sometimes your mom if she's making
soup
she'll take a wooden spoon and she'll
mix together what is she doing she is
stirring to stir the pot
right to stir things is to mix it
together
okay let's take a look number 12
glue this is not really glue but it's
like glue it's similar to glue glue
made from sand and water sand and water
makes
glue well it can if you get the right
mix maybe you've seen this before when
you see
construction workers they are working
they're called
workers right when you see construction
workers
making a new sidewalk they have this
material it's just sand and water and it
it's not glue
but it acts like glue it behaves
like glue it sticks things together
what do we call it we call it cement
cement cement is a common
building material most buildings
are made from cement probably
if you are in an apartment building
right now your apartment building
was made from cement sand and water
dirt that's what we're talking about
right
many homes were made from dirt are made
of dirt okay first word
is a hole in a building
that we look through a hole
now usually it's not a hole that
somebody made because they were angry
no it's a hole that people make that the
builder of the building makes
we call it a window right it's not just
a hole
and sometimes we cover that window with
glass
right so air can't come in and out but
we can look out
right a hole in the building that we can
look through
because if there are no windows oh no mo
shimsham hail right
it's very boring we feel we don't feel
good
so we want windows we can look through
and light
natural light from outside can come in
that's good
chung moon right in karim you say
changmun that would be
window a window
number two on a bright
sunny day you see this a lot don't you
this is a place where light doesn't go
right light goes here and here and here
and here and here and here right but
light
does not go here or here so a place
where light
doesn't go is a shadow
and on a sunny day your shadow
is always with you right you can always
see your shadow and you can see
other people's shadow too you can see
the shadow
of buildings you can see the shadow
of cars sometimes you see the shadow of
an
airplane whoa right and that's very
interesting
an airplane up in the sky can make a
shadow on the ground okay so that's
shadow
number three to trap and hold
wow he's a he looks like a good yagu
player right he's a good baseball player
and he's going to see the ball right
here he's getting ready it's going to go
in his glove
what is he going to do he's going to
catch
catch the ball to trap something
because something's moving you stop it
that means to trap it
and then you hold it right that means to
catch
something okay so he's going to catch
now let's take a look
catch caught caught because catch
is an irregular verb it's not a regular
verb so
catch caught caught okay that is the
verb to use
to trap and hold something okay the next
word
number four to keep from going
stop right if you see the policeman
if you're going to walk across the
street be careful the policemen might
say stop
it's a red light don't go stop
wait okay that means to keep from going
stop stop opposite of go of course
okay so be careful when you're on the
street pay attention you need to know
when
you should stop and when you should go
number five energy that warms
things these two girls are sitting in
front of a fire
we talked about three types of energy
before right
remember one type of energy that warms
things that makes you
warm in front of a fire or a fireplace
you feel heat you
feel heat ah it keeps you warm
maybe outside it's cold it's winter
you want to stay inside next to a fire
to feel heat
ah choil number six
to use heat we use heat not just to warm
our bodies
but we also use heat with food we
change food right if you have
um for example a steak right
the steak is not brown when you mother
buys it
at the store it's pink it's red
do you want to eat it well that's raw
meat
you don't want to eat that you want to
change it you want to change it so it's
brown warm and it's juicy
right that's what you do
with heat then is you cook you cook
the food that's changing the food use
heat to change the food
that is to cook are you a cook
or do you let your mom cook all the time
probably let your mom
but help her out see if you can help her
to cook
okay number seven this man
seems like he's trying to hear something
something we
hear right it's another type of energy
we talked about
in the beginning we talked about three
kinds of energy
right this is one type this of course is
sound sound is something we
hear there are many different kinds of
sounds right there's loud sounds there's
soft sounds right there's long
sounds and short sounds there's all
different kinds of sounds
good sounds and bad sounds right but
they are all sounds
here we have to pass a thing to someone
else
this woman here is giving the little
girl a basket and i just use the word
right
she's giving to give
give and give is an irregular verb so we
say
give gave given one more time
give gave given okay good so that's
very easy verb you give something you do
this all the time don't you
you give something to somebody else very
common thing to do
number nine what makes things happen
what makes things happen that's a good
question
work makes things happen i'm sorry
but around the house you need to work if
you want your clothes to be clean
well your mom has to work she washes
your clothes but you have to pick up the
clothes
off your floor put your clothes away
if you want things to happen in your
room you have to work
right and that's good it's good to work
because it helps you
get things done it makes things
happen okay then we have number 10
to be straight on your feet not like
this
right that's lean right if i do that
that's called to lean right i'm like
this right
some people like to lean against the
wall don't lean against the wall
especially not an elevator wall right
you should stand
up right stand stand stand
straight on your feet sometimes if
you're like this your teacher
or your mom might say stand up right
don't
don't lean okay stand
stand stood stood okay it's a regular
verb
one more time stand stood
stood okay good
number eleven whoa that's what is that
that looks like ice cream
no it's not ice cream okay kind of looks
like
ice cream a very bright ice cream maybe
orange flavor
but that's not ice cream that is a huge
ball of light and heat
it doesn't normally look like this in
fact don't look at it
because it's not good for your eyes but
if you had a special camera
maybe a telescope scientists can take
pictures of it
and it looks like this it's huge this is
so big we can't imagine how big this
thing is
what is it of course i'm talking about
the sun
the sun is a big ball of light and heat
huge ball of light and heat in the sky
and it's far away really far away so it
looks small to us
but it's really really big but even
though it's so
far away it's so big we can still feel
the light
and we can feel the heat from the sun
without the sun we couldn't live
okay so it's a very important thing to
us it's the sun
okay the next word uh wow
right this guy's really driving how is
he driving he's moving quickly
his wheels aren't even on the ground
that's how
fast he's going he's going so
fast his wheels are off the ground right
he just jumped
but you have to be moving fast to do
that don't drive fast it's dangerous
you don't drive anyway but don't drive
fast it's a little dangerous
okay but if you walk fast walk quickly
you can walk you can run
but be careful when you do so let's
begin with our first word
electricity is a type of energy isn't it
electricity is a type of energy but what
is the word
from the unit from our lesson that is
the same as
energy what is that word we can see that
that word is
power power now be careful when
pronouncing
p when you pronounce
p your lips are together
and you have power sound behind it
power okay so it's a powerful word isn't
it
power so power is the same as
energy power and energy are the same
thing okay so that's our first word
let's move on to the second word
okay let's look at our second word our
second
word is about this device here
we can see it's a device that turns
sunlight into electricity
so let's look at this here a device a
device
is a machine or a tool
that you use to do something in this
case
it's a device a machine that turns
turns turns changes
okay so when you say it turns a into
b it changes a into b
in this case it's turning sunlight
into electricity so this device
turns sunlight into electricity isn't
that great
imagine we have sunlight coming down
right
and it's being turned into electricity
so what are these things what are they
well if we look at our word list we can
see that they're
solar panel solar panels
many but one is solar panel
this is a little difficult of a word
right think about it this way
solar means from the sun
solar is associated with the sun solar
panel a panel is a flat
uh device here like this this is one
panel there are many
panels so solar panel
and remember the p pronunciation panel
panel lips together so we have solar
panel
you guys practice solar panel
okay good solar panel okay let's move on
this is one device of course to make
electricity
let's move on to our third word
our third word our clue is a building
well this is a strange looking building
right but it's a building
where electricity is made
a building where electricity is made
what kind of building can that be
remember
our word that we learned in the first
time it was power right
so we put these two words together power
and we have plant
plant now you may know plant
are we talking about a bush or a flower
no
another meaning of plant is like a
factory
where something is made especially
energy
energy plant or power plant
so here this building which looks very
strange
it's a very interesting looking building
is a
power plant we make electricity
at this building okay so this is a
building where
electricity is made this is a little
difficult of a word
let's practice power plant
remember we have two p's here power
plant power plant you guys try it
power plant okay good
let's move on then to our fourth word
here our clue is a giant fan
a giant fan these are huge aren't they
they're really
really big fans uh not in your house
right you don't have these in your house
to make you cool
these are outside it's interesting let's
look at this be careful
this is giant fan
we have the f sound be careful
between f and
oops f versus p
before we learn p p p
is the sound for that but be careful
with f
with f we put our teeth on our bottom
lip
like this
so we have fan
fan let the air flow through your teeth
fan okay so p there's no air going
through your lips are closed tight
and then you release it powerfully okay
so a giant fan what is a giant fan
this is also where we use uh we can get
electricity where does it come from we
can make electricity
with a turbine a turbine these are
turbines
also be careful here if we just said if
there's no e e
then it's turbine right but e ismian
turbine it makes the i
a longer sound turbine
let's practice turbine turbine
okay so these are turbines they
generate they make electricity they turn
wind energy into electricity
okay let's move on now
we've talked about where electricity
comes from how can we
get electricity that we've we found out
how we can make
electricity but how can we use
electricity
where can we get the electricity from
we can get electricity from this you can
see this
in your house right how many do you have
in your house
wait you can count them later let's
study okay
you can count how many you have in your
house later but
what is this what is this we can
describe it as
a spot a spot a place right
a spot where you can get
electricity so you want electricity
for your computer for your smartphone
where can you get it if your battery is
dead
you can get it from here this is an
outlet look this is like
two words out out going out
and let out let think of it this way
it lets the electricity out
of this place so you can get it and you
can use it
it's an outlet so this is where you can
get
your electricity okay so that's very
useful
let's move on now behind the
outlet right we have these things
okay we're talking about the metal part
here right this is a long
thin piece of metal
metal that's this part here
not this part this part is plastic but
inside the plastic
is metal what is this called
this is called a wire
wire again remember e opsamian
we're okay but e is a
wire stretch the i sound makes it long
wire so practice wire
okay wire why are we concerned about
wire electricity moves
through the wire goes to your outlet and
that's important
so there are wires inside your house
okay okay
some the wires are inside your house but
we also have
wires on the outside of your computer
this is a special word
for these kinds of wires this is a
short wire for moving electricity
electricity travels through a wire but
on your computer or on your battery pack
for your cell phone
you have small wires we have a special
word
for that what is that word that word is
chord chord a chord is a small wire
with two uh ends you put one end in the
outlet
the other end goes into your device into
your computer
or smartphone that short wire we call
a chord a chord okay let's move on
on number eight at the end of the chord
this is the chord here
this is the cord part here what is this
part
what is that this is the part
of a cord that goes into an outlet
right you have to connect your cord
to your outlet to get the electricity
out what do we call this part we call
this part
a plug plug let's practice that
we have a blend p and l pu
plug plug you guys
plug very good okay
plug so we use this plug we put it
into the outlet and then we can get our
electricity
okay great let's move on here what's
this boy doing
right he's very happy he is using
a device we use for many things
maybe right now you're watching me
on this device what is this device
of course you know this this is very
easy right
it is a computer computer
computer right computer of course you
know that
that's an easy one so this boy is using
a computer
we don't see the chord but of course
there's probably a chord
that the electricity is coming into and
these are
this is one example of many devices
we use with electricity we need
electricity
to use these devices so this is a
computer now let's take a look at
uh word number 10 okay sometimes we want
to
make electricity go from one place to
another
so what verb can we use to describe that
motion going from one place to another
to move something to move something
to somewhere else i'm in korea
i want to send a present to my friend in
america
i will do what with that present i will
go to the post office
and i will send the present to my friend
when we talk about electricity we need
to send electricity
from the power plant to the outlet
in your house okay so this is a verb
be careful some verbs in english are
uh not regular they change form
when you use them in different
situations for example
send that's now chigum i i
i am sending i will send also future
scent is passed quago right sent
and sent so i sent my present
i sent a present to my friend in america
that's quago okay past tense okay send
sent sent practice that you guys
send sent sent
okay very good okay let's move on then
wow look at these birds where are they
going right um
they are going of course it must be uh
getting cold and they're going south
right well what are they doing
they are moving from one place to
another
so if you move from one place to another
what are you doing it's a verb
travel travel so i want to go
to america i will travel to
america travel to
somewhere move from one place to
another place i will travel to
america i will travel to another country
so these birds are traveling south
okay let's take a look at the next one
our last word here
is kind of a a scary word right
that's be careful of this right be
careful of this sign
if you see that sign on a bottle stay
away from that bottle right this
what what can we say this about this
it's causing death
death somebody dies right it's very
dangerous
what word are we looking at here we are
looking at
deadly deadly is a description word
right adjective it describes something
we can look at this and say oh be
careful it's
deadly it can cause death why are we
looking at this word deadly
in our topic about electricity because
you have to be careful
electricity can be deadly it can be very
dangerous
so although electricity is very useful
we use it for many things you also have
to be
careful electricity can also be
dangerous
it can be deadly

## toggle timestamps Transcript

00:00
[Music]
00:07
okay let's start with our first
00:09
word the first word we don't see it
00:12
but we have the definition here and we
00:15
have a picture
00:17
over here let's see the definition let's
00:20
take a look
00:21
at the definition the definition is
00:24
the part the part there are many
00:28
parts of a plant but we're looking at
00:32
maybe one part or a few different parts
00:35
right i am a person i have many parts
00:39
right just like a plant has many parts
00:42
so we're looking at the part of a plant
00:46
that we eat we eat the part of the plant
00:51
so sometimes we have this part of the
00:54
plant over here we eat that
00:56
sometimes it's this part of the plant or
00:59
sometimes
01:00
this part of a plant they're different
01:02
parts of a plant
01:04
we eat them what do we call that we call
01:07
those
01:08
vegetable vegetable
01:12
if you look at the word it looks like
01:15
vegetable but no
01:16
we say vegetable everybody vegetable
01:20
so it sounds like you don't say e
01:24
vegetable vegetable don't say vegetable
01:28
manila vegetable is very common
01:31
vegetable
01:32
but there's an interesting point when i
01:34
see vegetable
01:36
i think fruit
01:40
so there's a question
01:43
what is the difference between vegetable
01:47
and fruit ego hago egohago otoketorani
01:52
right
01:53
how are they different it's very simple
01:57
think about this fruit has
02:01
seeds
02:04
if there are seeds in it it's a fruit
02:08
vegetable no seeds
02:13
a vegetable does not have
02:16
seeds no seeds so a fruit is a part of
02:20
the plant
02:21
yes but it's only one part of the plant
02:24
it's the part that has seeds
02:27
if it has seeds it's a fruit so an
02:30
apple cut open an apple there are seeds
02:34
an apple is a fruit watermelon
02:39
right you cut the watermelon watermelon
02:42
tsubak right
02:43
watermelon you cut the watermelon many
02:45
many many
02:47
seeds watermelon is a fruit
02:51
vegetable a carrot dangan
02:55
tangan right you cut the carrot where's
02:57
the seeds there's no seeds
02:59
carrot is a vegetable okay so that's how
03:02
you know the difference between
03:04
vegetable
03:05
and fruit but mostly in this lesson
03:08
we will talk about vegetables
03:12
okay the parts of the plant that we eat
03:15
many parts don't have seeds so
03:18
mostly we will talk about vegetables
03:22
okay okay let's go to the next word
03:25
the next word is the part remember
03:27
there's many parts of a plant we're
03:29
looking at one part
03:31
the part of a plant that makes
03:34
seeds it's the part of the plant
03:38
that makes the seeds before the fruit
03:41
right it's the part of the plant that
03:43
makes the seeds
03:45
before it becomes a fruit what part is
03:48
it
03:49
look at the picture there are many
03:51
pretty pretty what
03:53
we have yellow we have purple what are
03:55
they of course we say
03:58
they are flowers flower
04:01
be careful this is a little hymdero a
04:03
little
04:04
difficult to pronounce f and
04:07
l right f and l
04:10
very difficult combination f
04:18
put them together flower
04:22
flower that's not so hard
04:25
flower flower it's the part of the plant
04:29
that makes
04:30
seeds the flowers make seeds
04:33
okay let's move on to our next word
04:37
the next word we can see wow looks
04:39
really
04:40
bright here right very green this
04:43
is the flat green part
04:47
of a plant and there are many right
04:51
a plant has many of these
04:54
what do we call this one one of them
04:56
what do we call it
04:58
we call it a leaf
05:01
leaf here we have l and f at the end
05:04
right
05:05
now they're apart but l remember l
05:08
la la put your tongue
05:11
behind your teeth on the top la
05:14
leaf and then for
05:18
f leaf leaf that's only one
05:22
one leaf but a plant has many
05:25
so how do we make it plural we say
05:28
many leaves
05:33
many leaves leaves
05:37
leaves okay so if it's one
05:40
just one we say it's a leaf but of
05:43
course a plant has
05:44
many you look at a plant you see many
05:47
leaves on a plant the flat green part
05:51
of a plant usually green sometimes
05:54
they're yellow sometimes they're orange
05:56
right
05:56
depends but usually they're green the
05:59
green
06:00
parts of a plant okay now we're on the
06:02
next part of the plant
06:04
and this part we can't see it right we
06:07
can't see that part
06:09
of the plant because it's underground
06:12
underground let me write that for you
06:15
under
06:18
ground right
06:21
this is the ground this is the ground
06:23
it's under
06:25
under the ground under ground
06:28
it's underground the part of a plant
06:32
that grows it grows down
06:35
in the dirt it's in the dirt
06:38
right in the dirt it's underground
06:41
so what part of this plant is it what do
06:45
we say
06:45
what's the word there we say that part
06:49
of the plant is called the root
06:53
root right strong word of course the
06:56
roots are strong
06:57
because they have to be strong because
06:59
they hold the plant
07:01
in the ground right these roots we can't
07:04
see them
07:05
unless we pull the plant out right we
07:08
pull the plant
07:08
out of the ground then we can see the
07:12
roots
07:13
we can see the roots right but one root
07:16
many roots okay so root
07:20
root right strong word root okay what's
07:23
our next word
07:24
okay our next word we're talking about a
07:27
different part of the plant this
07:30
is this part right here actually it's
07:32
this whole piece right here right that
07:35
whole thing
07:36
we're talking about that part of the
07:39
plant now
07:40
now it's the part of a plant that holds
07:44
the plant up it holds the plant up
07:48
right it supports the rest of the plant
07:51
it's kind of like my body right my trunk
07:54
of my body holds my body up right but
07:58
this part
07:59
we don't usually say trunk for a small
08:01
plant we can say what
08:03
stem stem yes we can say
08:07
trunk for a tree but this is a small
08:10
plant
08:11
we say stem stem
08:14
many plants all plants have a stem
08:18
the stem is like the body of a plant
08:21
right
08:22
it's like the body of a plant it's their
08:25
body right
08:26
some bodies are thin some bodies are
08:29
thick right
08:30
so these are the stems of
08:33
the plant right some of them are are
08:35
thick and big
08:36
some of them are very thin and not so
08:39
strong
08:40
but they are called stems stem
08:43
the stem of a plant the part that
08:47
holds the plant up okay
08:51
the next one is the part of a plant
08:54
that grows into a new
08:58
plant we talked about this part before
09:02
we've mentioned it several times
09:05
already we're looking at this very
09:08
small piece of the plant that piece
09:11
that part will fly away on the wind
09:14
it'll fall in the ground
09:15
and a new plant will grow okay so
09:19
that's just one type of plant of course
09:21
there are many types
09:22
of these sometimes people eat them right
09:25
and they throw them away in different
09:28
places and a new plant will grow
09:31
what are we talking about we're talking
09:33
about the seed
09:35
the seed the seed of a plant
09:39
remember when we talked about fruits and
09:42
vegetables
09:44
where is the seed the seed is in
09:47
the fruit but not all plants have fruit
09:50
some plants there's no fruit like this
09:53
plant here
09:54
there's no fruit because the seeds
09:58
break off and fly away on the wind
10:01
but many plants grow fruit the seeds are
10:03
in them because
10:04
animals eat the fruit and they eat the
10:07
seeds too
10:08
and they walk away and they go they go
10:10
they go to the bathroom somewhere else
10:13
but the seeds are in that and the seeds
10:15
will grow
10:17
in a different location and those are
10:19
seeds okay
10:20
so plants have many ways to spread
10:23
their seeds okay
10:26
now we've come here to this type
10:30
of plant we're talking about a type of
10:33
plant
10:34
a long orange vegetable
10:37
so it's a vegetable you can see it right
10:39
here you know what that is right
10:40
we can only see part of it but we know
10:42
what the rest of it is
10:44
the rest of it is underground right
10:47
what did we call that this of course is
10:49
called the carrot
10:51
right before i said tangan right tangan
10:53
one of the
10:55
first words i learned in korean because
10:58
carrots are very common they're good for
11:01
you
11:01
carrots are very good for your eyes you
11:04
eat many carrots
11:05
you have good eyesight i don't know what
11:07
happened with me
11:08
i think i read too much but if you eat
11:11
many carrots you have good
11:13
eyesight okay but carrots are long
11:16
orange vegetable they're very good for
11:19
you
11:19
okay now here we have
11:23
an action it's not a noun we're looking
11:26
for a verb an
11:27
action to put food
11:31
into your mouth and chew
11:35
and swallow swallow it so
11:38
you chew it and you swallow it actually
11:40
you do three things right
11:42
first you put it in your mouth that's
11:45
first
11:46
second you chew it and
11:49
third you swallow it right
11:52
make sure you chew before you swallow
11:55
don't just put and
11:56
gulp chew don't be so fast
12:00
take your time chew your food well but
12:03
there's three actions right
12:05
to put food in your mouth chew it and
12:07
then
12:08
swallow it what are we talking about of
12:11
course we're talking about to
12:12
eat eat okay so when we eat
12:16
that's what we're doing we're actually
12:17
doing three things put food in your
12:19
mouth
12:20
chew it and then swallow of course we
12:24
can also talk about
12:25
the different times right present tense
12:29
past tense right and past participle
12:33
okay
12:33
so when we talk about present tense eat
12:36
eat
12:37
that's what we're doing now what will we
12:40
do now let's eat
12:42
let's go eat okay and that's also a
12:44
little bit of future right
12:46
let's eat i want to eat now you're
12:49
talking about the present time
12:51
or just a little bit in the future what
12:53
about eight
12:54
eat eight i ate
12:57
breakfast did you eat breakfast yes
13:01
i ate breakfast i hope you ate breakfast
13:04
right but you're talking about eating a
13:07
long time ago right
13:09
i have eaten or i've done something
13:12
before right
13:13
i have eaten breakfast i have eaten
13:16
have you ever eaten eggs for breakfast
13:20
right so if you're talking about if you
13:22
ever did something in your life
13:24
you have done it you have eaten
13:27
eggs okay so eat ate
13:30
eaten one more time eat ate
13:34
eaten those are the different verb forms
13:38
of this verb to eat
13:41
by the way you should eat breakfast
13:44
every day
13:44
right always eat breakfast i ate
13:47
breakfast today
13:48
i hope you ate breakfast today okay
13:51
our next word is another type of
13:54
vegetable
13:55
another type of vegetable we saw carrot
13:58
before
13:59
that's one type of vegetable but now we
14:02
have
14:02
another type of vegetable and this
14:06
is the picture you know this one right
14:08
this is very common
14:10
round white they're white maybe
14:13
a little yellow but usually white
14:16
vegetables
14:17
that grow in the dirt they grow
14:20
underground
14:21
just like the carrot right what do we
14:24
call
14:24
these vegetables we call them
14:28
potato potato right you know of course
14:31
kamja right kamja
14:33
potato is very very common and of course
14:37
we know potatoes as potato chips
14:40
right potato chips are very common too
14:43
made from potatoes
14:45
and i just gave you of course when you
14:47
talk about plural
14:49
say potatoes potatoes
14:52
with the e we add e-s at the end
14:55
it is potatoes
14:58
so potatoes of course are very common
15:01
you
15:02
probably eat them maybe every day
15:05
if not every day then probably many
15:08
times a week right i'm sure you eat
15:11
potatoes
15:12
very often okay okay let's move on
15:16
now this is also very common especially
15:20
with korean dishes right i really like
15:23
bulgogi
15:24
right and i like when i eat bulgogi i
15:27
use this
15:28
to put the bulgogi in what do we call
15:30
this a plant with
15:32
large green leaves it has many
15:35
large green leaves okay what do we call
15:39
it
15:39
in english we say it's lettuce
15:43
lettuce now lettuce is very similar to
15:46
another
15:47
uh vegetable we call cabbage
15:50
but cabbage is very
15:54
similar but lettuce is not so heavy
15:56
lettuce is
15:57
lighter it's thinner and it tastes a
15:59
little bit better
16:01
lettuce is a different kind but cabbage
16:04
they're very close they're like brothers
16:06
right
16:06
they're like sisters they're very close
16:08
lettuce or cabbage
16:11
lettuce of course is very common we use
16:13
it in salads
16:14
of course in many korean dishes you can
16:17
use it to eat with meat
16:18
i like to put the meat the rice the
16:21
garlic the onion and the dwenjang right
16:26
right but we use the lettuce in many
16:28
different ways
16:29
okay we say lettuce lettuce
16:33
it almost sounds like let us go but it
16:36
doesn't mean that right
16:38
it's lettuce lettuce and that is a plant
16:41
with large
16:42
green leaves okay here we have
16:46
another type of plant that we eat right
16:50
we eat these things right here these
16:52
actually are seeds right
16:54
but there's in this case they're soft
16:56
and they're good for you
16:58
the seed of a pea plant that we eat
17:01
the seed of a pea plant that we eat
17:05
remember pea plant right that's very
17:07
easy because we say pea
17:09
right it's a pea peas eat your peas
17:12
peas are very good for you now
17:16
usually we don't eat the seeds of a
17:19
plant
17:19
like apple seeds they're very hard right
17:23
look they don't taste good but we can
17:26
eat peas the seeds
17:27
of a pea plant we eat those very often
17:31
so sometimes we can eat seeds but
17:34
sometimes we
17:35
don't eat the seeds right but in the
17:38
case of peas
17:39
we eat the seeds okay it's part of the
17:42
plant
17:43
that we eat okay our next word
17:46
is a verb to have an
17:49
odor that's a verb right a verb
17:54
when we see to do something we're
17:56
talking about
17:57
a verb to have an odor
18:01
an odor that means i can
18:05
sense it with my nose right
18:08
there are good odors that's nice
18:12
and there are bad odors themselves right
18:16
bad odors so to have an odor what is the
18:20
word
18:20
what is going on here we say that this
18:24
is
18:24
smell smell to have an odor
18:27
is to smell there's two ways
18:30
you can use this verb one way
18:34
is this the flower smells so in this
18:37
case
18:38
the flower smells that's a good odor but
18:41
sometimes there's a
18:42
bad odor for example my oops where
18:46
my socks
18:51
smell whoops smell
18:54
my sock what is this sock you say yang
18:57
mao right
18:58
so sock is like this
19:01
it smells right don't smell that smell
19:05
it smells my socks smell
19:08
that's one way another way you can use
19:11
this
19:12
is i smell i
19:15
smell i smell what my sock no
19:19
yuck that's horrible right i smell a
19:23
flower that's much better i smell a
19:26
flower
19:28
ah much better right don't smell your
19:30
socks
19:31
right that's that's terrible right so
19:34
my sock smell it has an odor
19:38
it gives an odor some good odors
19:41
and some bad odors right my socks
19:44
smell or i smell
19:48
a flower so there's two ways you can use
19:52
this verb some things smell
19:55
or people or animals
19:58
smell something so there's two ways the
20:01
flower
20:02
smells the boy smells the flower
20:07
two ways right okay so smell
20:10
very interesting verb here we have
20:13
we brush our teeth with this we have the
20:16
picture
20:17
not the toothbrush right that's a
20:19
toothbrush we're not talking about the
20:21
toothbrush
20:23
we're talking about this here what is
20:26
this
20:27
what's that stuff we put it on our
20:29
toothbrush
20:30
and we brush cheeky cheeky
20:34
we brush our teeth with this
20:37
what do we call it we call it tooth
20:41
paste tooth
20:44
paste paste is the
20:48
material that we use to brush our
20:51
teeth toothpaste two words
20:54
we put it together so this is toothpaste
20:57
that we put
20:58
on the tooth brush and we brush our
21:01
teeth with it toothpaste okay
21:05
next one we already saw this word right
21:08
we just saw this
21:10
a little bit ago the yellow fruit yellow
21:14
fruit it's a fruit because it has seeds
21:17
in it the yellow fruit that tastes sour
21:22
right lemons taste sour it means
21:25
right it's not a it's not a really good
21:28
taste it's not
21:29
sweet we put sugar in it to make it
21:32
sweet
21:32
and we like lemons then but it's a sour
21:36
taste
21:37
and what did i say i just said lemon
21:40
these are lemons so if you have many
21:43
lemons
21:44
right you have many yellow fruits it's
21:47
yellow fruit that tastes
21:49
sour okay our next word
21:53
that's an interesting picture it's the
21:56
liquid
21:57
liquid is like water right water
22:00
inside a bottle that girls use
22:04
to smell nice so girls like to smell
22:07
nice
22:08
they smell so nice right
22:11
usually girls use this thing
22:15
to smell nice it's made of flowers
22:19
many different types of flowers what do
22:22
we call it
22:23
we call it perfume
22:26
perfume per
22:29
fume so we have p then we have f be
22:32
careful
22:33
because p is f is
22:37
f do you see the difference
22:40
p your lips are together
22:43
f your lips are not together your teeth
22:47
are on your bottom lip
22:51
so perfume
22:55
per fume perfume
22:59
perfume is liquid that girls use to
23:02
smell
23:03
nice right
23:06
they put perfume on their bodies
23:09
okay next one
23:12
we have another liquid it's also a
23:15
liquid
23:16
we cook food in this
23:20
so we pour this on the pan
23:23
and put food in there and we cook it we
23:26
heat it up very hot and we cook food
23:30
in this what is it it's very
23:34
slippery right we call it oil
23:38
oil oil right oil
23:42
o i o i oil
23:46
oil so we say that this is oil
23:50
your mom uses oil to cook
23:53
in and we call that
23:57
cooking oil cooking oil
24:01
there's many types of oil but when we
24:04
cook
24:04
food in it we call it cooking oil
24:08
cooking oil okay
24:11
what's this here this is very strong
24:14
right
24:14
we can tie it to one place
24:18
and pull with it a
24:21
strong line we tie tie
24:24
right can you tie a rope
24:27
to something can you tie your shoes your
24:30
shoelaces together you tie
24:33
something together you tie to things of
24:36
course i just said it
24:37
it is a rope a rope is very
24:40
thick right we call that a rope
24:43
this is a rope and we tie it to things
24:46
and we can
24:46
pull right so rope
24:50
rope okay the next word here
24:53
we talked about this before right this
24:56
is something that you
24:57
wash with when you wash your face right
25:00
you get a little bit on your hand
25:02
or your cloth and you put it on your
25:06
face
25:06
and you wash your face with it when you
25:09
wash your hands
25:10
you take this in your hands and you wash
25:14
your hands with this it helps make
25:17
your hands very clean if you just use
25:21
water
25:22
that's not so good it's better if you
25:25
use
25:26
soap soap use
25:29
soap to wash your hands
25:32
by the way it's very interesting you can
25:35
see here
25:36
it says 100 percent
25:40
vegetal that's a different language it's
25:43
not english
25:44
but it means 100 percent vegetable
25:47
this soap is made from vegetables
25:51
it's very natural soap 100
25:55
vegetables it's made we use vegetables
25:58
to make soap okay
26:01
oh are you hungry whoa i'm hungry just
26:05
looking at this wow it looks really good
26:10
this is what we eat to get energy
26:14
we want energy sometimes we get tired
26:17
it's been a long day but if we eat
26:20
something
26:20
we get more energy right so and this
26:23
looks
26:23
very delicious what is it it's
26:27
food food food
26:30
okay and by the way there's two types
26:33
of food right this
26:36
these are all plants we get this
26:40
from plants this is meat
26:45
meat we get that from animals
26:49
so there's two types of food right
26:52
vegetables are plants and meats
26:55
these are food we eat them to get
26:58
energy food okay
27:02
here we have an interesting plant
27:05
this is a plant with a fresh smell
27:10
ah smells very fresh and
27:13
it tastes fresh it tastes very fresh
27:17
it's really good sometimes we have this
27:20
in
27:21
ice cream sometimes they put it
27:24
into hot chocolate right
27:27
it makes the hot chocolate taste
27:31
fresh or good it makes our ice cream
27:34
taste good what is it it
27:37
is mint mint
27:40
so you know mint ice cream like
27:44
mint chocolate chip ice cream wow really
27:47
good right it's
27:48
green mint hot choco don't say hot choco
27:52
say hot chocolate mint hot chocolate
27:56
if we put mint in it it tastes
27:59
fresh it tastes fresh it's very good
28:04
so we put mint in food sometimes
28:07
but we also use mint for other things
28:10
like perfume soap toothpaste
28:13
if you have mint toothpaste for example
28:17
it tastes fresh and it smells
28:20
fresh mint okay what's her next word
28:25
we talked about lemons before
28:28
we talked about lemons before
28:32
but this is a drink with a lemon
28:35
flavor a drink with a lemon
28:38
flavor and you can see lemon is here but
28:41
this is a drink
28:42
so we put lemons in we put sugar and
28:45
water mmm it's very delicious
28:49
what is it it's called big word
28:53
lemon aid lemon
28:57
aid lemonade lemonade
29:00
if you say it quickly it sounds like
29:04
lemonade lemonade okay
29:07
so this is very delicious right if it's
29:10
hot
29:11
on a summer day oh i'm very hot drink
29:15
some cold lemonade it's very
29:18
refreshing it tastes good so it's a
29:20
drink with a lemon flavor
29:22
we say lemonade okay the next one ah
29:27
this looks
29:28
good right are you hungry i was hungry
29:30
before
29:31
now i see this i'm hungry again
29:34
this is a long it's long yellow
29:38
this is the color of yellow this is
29:40
green
29:41
this is yellow yellow is this color here
29:45
yellow vegetable that has a green
29:48
skin so this is yellow this is green
29:52
the skin is green and then you
29:55
pull back the skin underneath it's
29:58
yellow
29:59
and there are many little pieces right
30:03
that we eat oh it's very good with
30:06
butter
30:06
right what is it of course we say it's
30:09
corn
30:10
corn is what we eat as a vegetable
30:14
it's a long yellow vegetable that has a
30:17
green skin
30:18
but we use corn for many other things
30:22
corn corn okay
30:26
wow what's this girl doing she has had a
30:29
lot of food she has a lot of energy
30:31
right
30:32
she is doing something she is exercising
30:35
it's an exercise exercise something you
30:39
do to make your body strong
30:42
an exercise in which in which
30:45
the player the player or the person
30:49
jumps over a rope many times right
30:53
the rope is going around and around
30:57
and around and that person is jumping
30:59
right they have to jump
31:01
over the rope many times
31:04
i'm getting tired okay what is it it's
31:06
called
31:07
jump rope very easy remember we said
31:11
that this is like a rope
31:12
here and you jump over it it's jump
31:16
rope jump over a rope jump rope
31:19
two words jump rope jump rope
31:23
okay this is another
31:27
fun exercise or game right that you can
31:30
use a rope
31:32
one is jump rope the other is people
31:35
pull pull on the rope a game in which
31:39
two teams one team
31:42
two teams and it can be many people
31:45
but two teams one team two teams
31:48
two teams hold a rope and pull
31:52
against each other they pull against
31:55
each other
31:55
so these guys are pulling this way this
31:58
team is pulling that
32:00
way they pull against each other who
32:03
will win right who will win this
32:06
game what is this game we say it is
32:10
tug of war it's like
32:13
war two teams they're fighting the war
32:17
tug tug means pull
32:21
like this pull that's tug so tug
32:24
of war tug of war tug of war
32:28
it's called tug of war let's play
32:31
tug of war it's a fun game you can use
32:35
with many people you have two teams
32:39
make sure the teams are even right it's
32:42
not fair
32:43
teams should have the same number of
32:45
people
32:46
so tug of war two teams okay it's a fun
32:50
game
32:51
now we see the picture this is what it
32:53
is
32:54
and this is the definition so let's go
32:56
over the definition
32:58
a warm coat with sleeves
33:02
it's very similar to coat coat and
33:05
another word
33:06
mean the same thing what is the other
33:08
word
33:09
we say jacket jacket
33:13
jacket jacket and coat
33:16
are basically the same right
33:20
we say jacket for the covering that we
33:23
wear
33:24
it's the same as a coat we wear them in
33:27
the winter
33:28
or when it's cold outside we want to
33:31
stay
33:31
warm put on a jacket
33:34
put on a coat same thing
33:38
the next one is another type of
33:41
clothing that we wear when it's
33:44
cold outside but we wear these over
33:48
our hands so this is the picture
33:51
the warm thing that you wear
33:54
on your hand so if i wear it on my hand
33:58
right i put it on what is it
34:01
what do we call that we call that a
34:05
glove this is a glove this is a very
34:08
colorful glove this is a very warm
34:12
glove right so we wear gloves
34:15
when we want to stay warm a glove
34:18
very easy okay the next word
34:22
that's so cute isn't it okay to
34:25
hold it's a verb two we're looking for a
34:29
verb
34:30
to hold somebody close in your arms
34:34
so to hold that's a verb to hold
34:37
somebody close in your arms like wow
34:41
these
34:41
very cute monkeys right they're holding
34:44
each other
34:45
they love each other right they're maybe
34:47
they're doing it to stay
34:49
warm too but in this case we say
34:52
cuddle cuddle these two monkeys are
34:55
cuddling by the way you may have thought
35:00
hug hug
35:04
what's the difference between hug
35:07
and cuddle ego hago
35:11
ego hago otoke torani right
35:14
what's the difference between hug
35:17
and cuddle hug is very quick it's like
35:21
you see your friend hey how are you
35:23
doing you hug that person
35:24
done finished quick but cuddle
35:28
is a long time right and be careful
35:32
cuddle usually means like romantic right
35:35
boyfriend or girlfriend or parent
35:38
and child that's not romantic right but
35:41
that's just
35:42
people who hold on to each other for a
35:45
long time
35:46
right cuddle and maybe you know pet the
35:48
hair or something
35:49
you cuddle you might cuddle your pet
35:52
if you have a dog or a cat you cuddle
35:55
that pet for a long time hug
35:58
hug done finished okay so hug is short
36:01
time
36:02
cuddle is for a longer time so
36:05
to cuddle to hold somebody close
36:08
in your arms okay
36:12
not thin whoa look at that book can you
36:15
read that book
36:17
it would take a very very long
36:20
time to read this book why because it's
36:24
not
36:24
thin it's not a thin book it's really
36:29
thick it's a thick book
36:32
so if we see something that is very wide
36:35
right like this then we say it's thick
36:38
it has a lot of
36:40
thickness not thin thin is like this
36:44
thick is like this right okay so thick
36:47
not thin the next word we have
36:51
look at this it looks like it looks very
36:53
soft
36:54
right you can put your hand on it and oh
36:56
it feels very soft right
36:58
it's hair that covers an animal's
37:02
body an animal's body not
37:06
human right if it's hair that covers an
37:09
animal's body we call it
37:12
fur fur
37:15
not human do not say
37:19
human fur we say hair
37:22
right so for humans
37:27
humans have hair
37:32
animals have fur
37:35
so humans have hair on their head if we
37:38
have hair on our arms
37:40
it's not fur it's hair okay
37:44
humans have hair animals have
37:47
fur and animals have a lot of fur
37:51
if you have a dog or a cat they have fur
37:54
all over their body so an animal's
37:58
fur hair that covers an animal's body
38:01
it covers it everywhere
38:05
next is a piece of cloth
38:08
that you wear it's a type of clothing a
38:11
piece of cloth
38:13
that you wear there are many types
38:16
of clothing this one you wear around
38:20
your neck here it is right so if it's
38:23
cold outside you wear this and you put
38:26
it around your neck
38:28
it keeps your neck warm because it's
38:31
very cold outside
38:32
you can put it up over your face right
38:34
to protect your nose and your mouth
38:37
so some people wear it up here if it's
38:39
really cold
38:40
what do we call it we call it a scarf
38:44
scarf s c scarf
38:49
scarf okay and then rf at the end
38:53
scarf okay that's one scarf
38:57
but if we have many two three four
39:00
five or many we say
39:03
scarves scarves
39:07
okay you guys try scarves
39:11
scarves okay so we have v and
39:14
s scars okay don't pronounce the e
39:18
scarves so one scarf
39:22
two scarves okay so scarf is singular
39:26
plural is scarves another piece of
39:30
clothing
39:30
that we wear to keep warm
39:34
okay the next word is a large animal
39:38
with thick fur that's a very
39:41
simple definition we're looking for
39:44
this animal here because there are many
39:47
large animals with thick fur right but
39:50
we're looking for this
39:52
specific one we where do we find him
39:55
we find him at the north
40:00
pole at the north pole way
40:03
up north we find this animal large
40:06
animal with thick
40:07
fur we call this animal a bear
40:11
right now there are many kinds of bears
40:14
right
40:14
this is a polar
40:18
bear a polar bear a polar bear
40:21
is a bear that lives at the north pole
40:25
it's very large it has thick fur
40:28
not all bears live at the north pole
40:31
there are other bears that live
40:33
further south like black bears
40:37
brown bears okay many types of bears
40:40
but the bear that lives at the north
40:42
pole is a polar
40:44
bear okay next word
40:47
having a low temperature if something
40:51
has a low
40:52
temperature low what do we say
40:55
it is cold it's
40:58
cold outside in the winter time
41:02
it is cold it has a low temperature
41:06
temperature is the number that says
41:09
how cold or how hot it is
41:12
outside or inside what is the
41:15
temperature
41:16
of the air right if it's a low
41:19
temperature
41:20
it's cold if it's a high temperature
41:24
it's hot okay okay
41:27
but what about not very hot
41:30
or very cold so we have hot
41:34
high temperature we have cold
41:38
low temperature high temperature low
41:41
temperature
41:41
but we want in the middle not very hot
41:45
not very cold in between we say
41:49
it's warm so warm
41:53
warm is between hot and cold
41:57
it's not it's not high temperature it's
41:59
not low temperature
42:00
it's in the middle it's warm
42:04
usually we are warm in your house
42:08
it's warm at your school i hope
42:11
it's warm because they're inside
42:14
we like to have the temperature
42:17
to be warm that's normal not very hot
42:22
not very cold it's warm in the middle
42:26
okay here we have another piece of
42:30
clothing
42:31
another piece of clothing this is
42:34
something
42:34
you wear on your head so you put it
42:38
on your head right there are many styles
42:41
many types this is one style it's a
42:45
woman's
42:45
style a woman would wear this this is
42:49
a hat very easy hat
42:53
do you have a hat sometimes you can say
42:56
a cap
42:56
like a baseball cap is very common
43:00
baseball cap
43:03
right that's the cap that you put on
43:06
your head it has the long part out here
43:08
that protects your face from the sun
43:11
most hats
43:13
protect your face from the sun but there
43:16
are many styles of hats
43:18
many different types of hats
43:21
okay now here we have an interesting
43:25
word the soft part of your body
43:29
under your skin so under my skin
43:32
it's soft right yeah my stomach is soft
43:35
right
43:36
if it's hard it's not this but if it's
43:38
soft
43:39
what do we call it we call it fat
43:43
so under my skin on my belly
43:46
on my stomach that is fat right
43:49
if you work out if you exercise it's not
43:53
fat then it's muscle
43:58
if it's hard it's muscle if it's soft
44:02
and weak then it's fat but fat
44:05
keeps you warm right okay so fat the
44:08
soft part of your body
44:09
under your skin is fat but if you have a
44:12
lot of fat
44:14
you're warm but you shouldn't have too
44:16
much
44:17
fat right you should also have muscle
44:20
okay an animal that lives
44:24
in the water an animal that lives
44:27
in the water like this animal right here
44:30
that animal
44:31
lives in the water it breathes
44:37
it breathes in the water what is it
44:40
it is of course a fish fish
44:43
are very common that and they live
44:46
in the water fish are common animals
44:49
that live
44:50
in the water sometimes they jump out of
44:52
the water
44:53
and they're fish fish
44:56
now the first vocabulary word we're
44:58
going to
45:00
listen to or learn is this one here
45:04
this is a picture of a place
45:07
in front of your house what is this it's
45:10
a
45:10
bell outside the door you
45:14
press it it goes ding dong
45:17
right ding dong what is that
45:20
it's a kind of bell and it's at the door
45:24
it's at the door and it's a bell it's a
45:28
doorbell that's pretty easy it's a door
45:32
bell it's outside the door and it is a
45:35
bell
45:35
you push it ding dong sounds like a bell
45:39
so it's a doorbell in front of your
45:41
house
45:42
you have a doorbell when somebody visits
45:45
you
45:46
they press the door bell
45:49
so doorbell doorbell
45:52
it's two words that make one word
45:55
door and bell doorbell very easy
45:59
okay the next word what is this this is
46:02
very
46:02
old right probably you have a small
46:06
one in your pocket something you
46:09
use to talk to your friend
46:13
so you want to talk to your friend you
46:16
take this out of your pocket
46:17
or your backpack you can
46:20
call your friend on it and you can talk
46:23
to your friend
46:24
what is it what is it called it's a
46:27
telephone
46:29
teller phone telephone
46:33
telephone three syllables or three
46:36
sounds
46:37
ta la phone telephone
46:40
telephone very easy of course this is a
46:43
very old
46:44
telephone right we don't use those
46:46
anymore we use the very small
46:48
or sometimes big uh pocket or cell
46:51
phones
46:52
and we but it's a telephone it's
46:54
basically a telephone
46:56
that we use to talk with our friend
46:59
okay the next word what's this this
47:01
looks very interesting doesn't it
47:03
this is a clock so it's a type of clock
47:06
right
47:06
we tell time but look at this what are
47:10
these things here those are bells again
47:13
another another type of bell right and
47:16
at a certain time
47:17
those bells sound
47:20
right so what is this it's a clock
47:24
that wakes you up in the morning
47:28
maybe you use this maybe you use your
47:30
cell phone
47:32
probably you use your cell phone but a
47:34
long time ago
47:35
when i was younger we used one of these
47:38
to wake up in the morning what is it
47:41
called
47:42
it's an alarm clock
47:45
so it's a clock right it's a clock what
47:47
kind of clock
47:49
alarm alarm means make a big sound alarm
47:54
right so an alarm clock is what we use
47:58
to wake up in the morning we need a very
48:01
loud sound to wake up right
48:04
some people need a really really loud
48:08
sound to wake up some people they sleep
48:12
they keep sleeping okay so you need a
48:15
very
48:15
loud alarm clock to wake up
48:18
in the morning alarm clock
48:22
okay our next word wow this looks very
48:25
interesting right unhappy
48:28
he looks very sad right
48:31
because you are alone if he's alone
48:35
he's very sad right it almost looks like
48:38
a human right
48:39
but it looks like a baby gorilla so very
48:42
interesting picture
48:43
but he looks sad because he's what
48:46
he's alone so he is lonely
48:50
if you are alone you are by yourself
48:55
you are by your self
48:59
there are no friends no family
49:02
around you you are by yourself you are
49:05
alone how do you feel you
49:08
are lonely lonely
49:12
be careful with el la lonely
49:15
we have two l's lonely
49:19
lonely lonely so hopefully
49:23
i hope you don't feel lonely but
49:25
sometimes
49:26
we feel lonely because we are alone
49:30
there are no friends or family around us
49:33
in that time
49:34
we feel lonely
49:37
okay next somewhere where only
49:41
animals live only animals no
49:44
humans so it's in nature
49:48
some place where there are no humans
49:51
and animals live without humans
49:55
they don't live with humans what do we
49:58
call this place we say it's in the wild
50:02
in the wild the wild is a place where
50:06
there are no
50:07
humans no villages
50:10
no towns no roads no
50:13
humans around just animals only animals
50:17
live there
50:18
in the wild wild w is like
50:23
wild and then we have ld
50:27
wild da da is when your jaw
50:31
drops duh wild wild
50:34
so in the wild okay the next word
50:38
giving help so if something is giving
50:42
help
50:42
what are they doing what do we say for
50:44
this word we say
50:46
help full because it's like full right
50:49
this word here
50:50
full two else means you have a lot of
50:53
it's full right
50:54
but we only have one l here when we put
50:56
it
50:57
as an adjective helpful helpful
51:00
if somebody or something is
51:03
helpful they are giving help so
51:07
help full helpful helpful
51:11
that is the word that means you are
51:13
giving help
51:15
okay here's another word this is a very
51:17
funny picture right
51:19
very cute right we have a small animal
51:22
on top of the girl's head
51:24
it's her pet right a small animal that
51:27
lives
51:27
with you and i just said the word right
51:30
so a small
51:31
animal that lives with you it can be a
51:34
gerbil it can be a hamster
51:36
it can be a dog it can be a cat
51:39
it can be a bird but it's a small animal
51:42
that lives with you
51:43
not in the wild but in your house we
51:46
call that of course
51:47
a pet i said that before right do you
51:50
have a pet
51:51
many houses have a pet like a dog or a
51:54
cat
51:54
very common pets but also a hamster you
51:58
could say
51:59
hamster a hamster
52:02
is also a very common type of pet
52:05
they're fun aren't they they're uh
52:07
they're very cute
52:08
and also they make us so we are not
52:11
lonely
52:12
we have some thing to play with or
52:15
something
52:16
to uh love and to play with okay
52:20
what's this guy doing what's crazy what
52:22
is he doing
52:23
he's it's exciting and not boring
52:26
so this kid is exciting right it's kind
52:29
of exciting we look at him
52:30
what is he doing with his eyes that's
52:32
very strange
52:33
and his his smile is very funny too
52:36
right because he's missing a tooth he's
52:39
missing
52:40
a tooth so if something is exciting not
52:43
boring we say it is fun
52:46
it's fun let's do something for fun
52:49
let's have fun we want to be excited
52:53
we don't want to be bored it's fun let's
52:56
have
52:57
fun okay here
53:00
this man he cannot see
53:03
not able to see we know that
53:07
very quickly because people who
53:11
are like him have a long stick
53:14
and it's this color white and red and
53:17
they use it
53:18
so they can feel where they are going
53:20
because they
53:21
cannot see what do we call the situation
53:24
we say blind this person
53:28
is blind it's unfortunate it's too bad
53:32
but sometimes this happens so this
53:34
person is
53:36
blind they cannot see blind
53:39
okay so the word is blind
53:43
okay now to move from one side
53:47
to the other so you're on one side
53:50
of the street and you want to go to the
53:52
other side of the street
53:54
or river or anything you want to go from
53:58
one side
53:59
you want to go to the other side what do
54:02
we say
54:02
we say cross i want to cross
54:06
the street cross is a verb right
54:10
so cross the street
54:13
cross the street let's
54:17
cross the
54:21
street we want to
54:24
cross the street so use cross as a verb
54:27
let's go across that's different
54:31
let's cross the street if you use a
54:33
cross that's a different word
54:35
cross is the word that we use for a verb
54:38
let's
54:39
cross the street you should cross the
54:41
street here
54:42
not here you should cross here
54:45
okay so cross is a verb let's cross
54:49
the street okay this
54:52
is another verb to try to try to hear
54:56
sounds carefully so it's very cute isn't
54:59
he with the little feet
55:00
okay but look at these big headphones by
55:03
the way these are
55:04
head phones
55:08
they're very big for this little boy
55:10
really big
55:11
and he's listening right he is
55:14
listening carefully he's trying to hear
55:17
sounds
55:18
listen so you listen to something
55:21
he's probably listening to music
55:25
to listen listen listen
55:28
carefully okay if i'm telling you
55:31
something
55:32
listen carefully but we listen to
55:35
different things
55:36
to listen to try to hear sounds
55:39
carefully
55:40
listen okay another one
55:43
to stay until something happens
55:47
so you're staying in one place and
55:50
you're what until something happens
55:52
you're staying until
55:54
something happens what are you doing you
55:57
are waiting so if you before you
56:01
cross the street wait don't just cross
56:04
the street
56:05
stop wait look both sides
56:08
then cross the street when it's safe but
56:11
you should wait
56:12
before crossing the street to stay stay
56:16
here don't move wait
56:19
until something happens it's safe okay
56:23
then we can cross but you should wait
56:25
first
56:26
to stay until something happens
56:29
wait this object here
56:32
it's a strange object i've never seen
56:34
that before
56:35
right what is that things that help you
56:38
see
56:39
things that help you see what is oh wait
56:41
a minute i've got them on my head
56:43
right what are these things okay what do
56:46
you call them
56:47
they're glasses glasses note that we use
56:51
plural we say it's like plural it's
56:54
one thing yes it's one thing but we use
56:57
it as plural
56:58
because there are two lenses we say
57:02
glasses
57:03
glasses okay so these are glasses
57:07
okay the next word now this is something
57:10
to do
57:11
with the one of the senses we talked
57:13
about when you use your tongue
57:15
right when you taste something the taste
57:19
of candy or in this case ice cream
57:22
ice cream candy cake
57:26
things that have sugar what
57:29
does it taste like it tastes
57:32
sweet mmm that's good sugar
57:35
things that have sugar in them taste
57:37
sweet
57:39
it's very good right like ice cream
57:41
candy
57:42
we really like those things right don't
57:44
eat too much
57:45
i know it's sweet it tastes good but
57:48
don't eat too much
57:49
because it's bad for your teeth anyway
57:51
these things taste
57:52
sweet what is the opposite of sweet
57:55
pandero
57:57
well that would be oh look at this poor
57:58
boy right
58:00
what is he doing he's eating a lemon the
58:02
taste of
58:03
lemons did you ever take a lemon and
58:06
lick it
58:07
right what it what do we say it is very
58:10
not sweet
58:11
pandiro it's sour
58:14
sour right sour is the taste
58:18
of lemons it's the opposite of sweet
58:21
okay okay now here we have another word
58:25
this has to do
58:26
with this object here it's
58:29
something that grows on a bird's
58:32
wing it grows on a bird's wing so a bird
58:35
can fly
58:36
right but the bird has to have many of
58:38
these things
58:39
on its wing also all over its body not
58:42
just its wing
58:43
it looks like this it's very soft if you
58:46
take a
58:47
if you take this and you brush it
58:49
against your cheek right you can use
58:51
your cheek
58:52
to feel or to touch something ah it's
58:55
very soft
58:56
what is it it of course is a feather
59:00
feather be careful with the f
59:04
feather and th the
59:07
the feather so we say feather
59:11
it's a feather it grows on a bird's wing
59:14
and it's very soft if we touch it very
59:17
nice
59:19
now we have this here now this is an
59:21
interesting picture this boy is between
59:23
his
59:24
father and his mother right and his
59:26
mother and his father are holding his
59:28
hand
59:29
how does this boy feel he's out of
59:32
harm's way harm is like danger right
59:36
joshua right harm is something that can
59:40
hurt you
59:41
so be careful you want to stay away
59:44
from harm you want to stay away from
59:46
danger
59:47
if you are out of the way of danger
59:50
or you're away from harm what are you
59:53
then
59:54
you are safe i'm safe right
59:57
nothing is going to harm him he's happy
60:00
he's
60:01
safe between his parents so he is
60:04
safe okay before we talked about
60:07
feather right we said a feather is very
60:09
soft
60:10
well here we have an object here and the
60:14
word that we have to define it is stone
60:17
so basically we're looking for another
60:20
word
60:20
that means the same as stone
60:24
stone is very hard right what is another
60:27
word
60:27
that we can use to talk about this of
60:30
course it's very simple
60:31
it's rock rock r
60:35
er er rock okay so it's a rock
60:40
a rock is very hard don't throw rocks
60:44
because if the rock hits you oh it hurts
60:46
your head because it's very hard
60:48
and it's heavy right so be careful with
60:51
rocks
60:52
do not throw rocks okay uh
60:56
at other people right you can throw
60:58
rocks in the water
60:59
okay but don't throw rocks at other
61:01
people that's very dangerous
61:03
okay rocks are hard okay
61:07
our next word is this right here what is
61:10
that right we have two of them
61:12
right i have two of them behind my
61:14
glasses
61:15
right you see things with this
61:20
with this we're only talking about one
61:21
now you see
61:23
things with this what is it it is
61:26
an i and of course we have two so we
61:29
have
61:30
eyes everybody has two
61:33
eyes but if you want to talk about one
61:36
you just say ah i
61:38
can see with one eye right or cover
61:41
one eye so i is singular
61:45
eyes plural we all have
61:48
two eyes everybody has two eyes
61:51
and what do we use our eyes for we see
61:54
things that's one of our five senses we
61:57
talked about before
61:59
another one of the five senses we talked
62:02
about before
62:03
is to hear and do you remember what i
62:06
said we use to here with of course we
62:10
have two
62:10
but we're talking about just one here
62:13
what is this do you remember
62:14
it's called an ear ear
62:18
so we have one ear two ears
62:22
again we just say two ears one
62:26
ear two ears
62:29
two ears okay so of course you're
62:32
listening to me right now you're
62:34
hearing me with your ears and you're
62:36
watching me
62:38
with your eyes okay so those are two of
62:40
the senses
62:41
we talked about okay oh look at poor
62:44
doggy
62:46
he's he looks so so sad right so
62:49
so pitiful right he's covered
62:52
with water if he's covered with water
62:55
or you go outside in the rain it rains a
62:58
lot
62:59
you don't have an umbrella all the water
63:02
falls on you
63:03
you're covered with water like the poor
63:05
doggy here
63:06
what do you say the doggy is
63:09
wet the dog is wet and we can feel
63:13
right if we're wet with our skin that's
63:15
one of our senses
63:16
we can with our touch with our skin we
63:19
can feel oh we're very wet
63:21
let's dry off right so we're wet
63:24
this is wet covered with water
63:28
okay don't do this this is not good for
63:31
her
63:32
ears right what's going on she's making
63:35
a big
63:35
noise to make a big noise what do we
63:39
call that
63:40
we say it's loud it's very loud making
63:43
a big noise if something makes a big
63:47
noise
63:47
we say it's loud right this woman
63:51
is very loud and this poor woman
63:54
is going to hurt her ear right so be
63:57
careful don't do this
63:58
it's just a picture but it's showing
64:01
loud
64:01
something is very loud makes a big noise
64:05
okay okay here we have to have
64:09
a particular flavor so this woman she
64:12
looks like
64:13
a cook right she is a cook
64:16
and she is making looks like soup and
64:19
she wants to
64:20
find the flavor she wants to know
64:24
what is the flavor of the soup
64:27
so what is what is she doing she is
64:30
tasting
64:31
this is one of these senses we talked
64:33
about before to taste
64:35
she's using her tongue all right she's
64:38
using her tongue
64:39
to taste the soup because it's your
64:41
tongue not your mouth
64:43
but your tongue that we use to taste
64:47
food what does it taste like
64:50
what does it taste like that is
64:54
to have a particular flavor it tastes
64:56
now we can taste
64:58
something but an object can also
65:01
have a taste right the strawberries
65:05
taste sweet and that has a particular
65:08
flavor
65:09
lemons taste sour
65:12
so we can use taste in two ways we
65:16
people can taste something but objects
65:19
can have a taste what do they taste
65:23
like what do they taste like okay
65:27
then we have to look at something to
65:29
look at something wow he's using these
65:31
are by the way these are
65:34
q binocular that's a big word
65:38
binoculars or binoculars binoculars are
65:42
really big they're like glasses right
65:44
but they're really strong they let you
65:46
see things
65:47
wow it comes really close whoa right you
65:50
look at some whoa it's really close and
65:52
it's a lot bigger
65:53
so you can really see things that are
65:55
far away with binoculars
65:57
what is he doing he's looking at
65:59
something another word
66:01
another word for look is see
66:05
i can see that's one of our five senses
66:09
now down here we have the verb the verb
66:13
changes in form whether we use it
66:15
present tense
66:17
past tense or present participle pp
66:20
right so what are the different forms we
66:23
have
66:23
see saw scene
66:26
see saw seen i see
66:30
you i saw him this morning
66:33
i have seen that movie
66:37
see saw seen okay okay so that's c
66:41
to look at something a very young
66:44
child zero to one year old oh very
66:47
cute right he's sleeping right very cute
66:50
what do we
66:51
call this person we call this person a
66:54
baby baby right zero
66:58
to one year old zero is interesting
67:01
in american age when a baby is born
67:05
the first day we say they're like zero
67:08
years old they're just one day old two
67:11
days
67:12
old okay then we go to months the baby
67:14
is three months old
67:16
six months old up to a year but before
67:20
they're there have been in the world for
67:22
one year
67:23
we say that they are a baby and by the
67:26
way baby
67:27
how do we say many babies we say
67:30
babies i e s so the y
67:34
changes to i e and then we put the s
67:38
babies babies so one baby
67:41
many babies right okay so that's the
67:44
first stage
67:45
in a person's life the first step the
67:48
first
67:49
step or the first stage
67:53
in a person's life and we're talking
67:55
about steps or stages
67:57
in people's lives the first step is
68:00
baby what's the next one the next step
68:04
is a child who is learning
68:08
to walk a child who is learning to walk
68:12
from one to three years old they are
68:15
learning
68:16
to walk they can't walk very well yet
68:18
they're kind of going like this right
68:20
they're learning to walk they're they're
68:22
like this and when they do this
68:24
we say they're kind of luck toddling
68:27
right they are a
68:28
toddler toddler is kind of the idea of
68:31
you know a baby
68:32
wobbling right like this they're very
68:34
careful
68:35
they don't walk very well they're not
68:37
like a mad robot right maybe i'm not
68:39
doing that right but you know
68:41
they're toddling right they're a toddler
68:44
a person who toddles a person who
68:47
doesn't walk
68:48
very well yet they're still learning
68:51
they're learning
68:52
to walk one to three years old they we
68:54
call those people a toddler
68:56
because they're learning how to walk
68:58
they haven't been able to walk
69:00
well on their own yet before they walk
69:03
what do people do
69:04
before they walk like babies
69:08
they will crawl crawl is like this
69:11
on all arms and legs that's crawling
69:15
after crawling people will walk but when
69:18
they're learning to walk they are a
69:20
toddler okay a boy
69:24
or girl between 3 and 12 years old what
69:27
do we call that person we use that word
69:30
actually on the previous slide when we
69:32
talked about a toddler
69:33
of course we talk about that person that
69:35
person is a
69:37
child a child between 3
69:40
and 12 years old maybe some of you
69:43
are three between between three
69:46
and 12 years old i don't think any of
69:47
you are three years old
69:49
you don't understand me but maybe if
69:52
some of you are maybe 10 or 11
69:54
or even 12 years old then you can be
69:57
called a
69:58
child by the way in english what is the
70:01
plural
70:02
of children if you have one child but
70:05
many
70:05
do we say childs no don't say childs
70:09
say children children
70:12
many children at your school there are
70:15
many
70:16
children in your class there are many
70:19
children okay so one child many
70:22
children now after a person
70:25
after 12 years old right they become 13
70:29
14 15 they become one of
70:32
these people or in this stage a boy or
70:35
girl between
70:35
13 and 19 years old
70:40
13 and 19
70:44
years old so what do we call them of
70:46
course i'm saying it
70:47
teen because 13 14
70:52
15 16
70:55
17 18
70:59
and 19. all of these words end in
71:02
teen right so we say that these people
71:06
are called teens now you might also call
71:08
them
71:09
teen agers teen
71:12
agers teenagers that's another word for
71:16
teens okay teenager or teenagers
71:21
teen is the same word okay now
71:24
after the teenage years right this is
71:27
quite a lot after
71:28
this a long time after okay
71:31
a man or woman over 20 because after 19
71:35
then they are 20 19 then 20
71:38
20 years old that person is now what
71:41
what do we call those people we call
71:43
those people
71:44
an adult adult adults are no longer
71:48
children
71:48
they are no longer teens they are adults
71:51
they are
71:52
independent they are responsible for
71:54
themselves they can make
71:56
their own decisions they don't depend
71:59
on their parents anymore they are
72:02
independent they are
72:03
adults a man or woman over 20 years old
72:06
now these are older adults right these
72:09
are getting a little bit older
72:11
than adults and of course you do have
72:12
different stages in adults you have
72:14
young adult middle aged adult
72:18
or senior citizen let me write those
72:20
down for you
72:21
very quickly just a little extra young
72:24
adult
72:24
you can say young adult usually somebody
72:28
who is in their 20s young adult
72:31
then after somebody gets to be about 40
72:33
years old
72:34
then you could say middle aged middle
72:39
middle aged okay
72:43
let me see if middle d d that's d d
72:46
m i d d l e h that's an
72:49
a a g e d middle aged
72:52
and after middle age maybe around 60
72:54
after 60 years old
72:56
we can say senior
72:59
senior sit zen
73:03
okay but all of these people all of them
73:07
are adults okay so you also have
73:10
different stages in the adult stage
73:12
okay let's move on to get bigger and
73:16
taller so we've just talked about baby
73:18
toddler
73:19
child teen and adult this process
73:23
this change what do we say what's going
73:26
on here to get bigger what's the verb we
73:29
use
73:30
we use of course the verb grow to grow
73:34
somebody who gets bigger right they get
73:36
bigger and they get taller
73:38
as they go along it's very interesting
73:40
the baby is so small
73:42
when you see babies oh wow they're so
73:43
small their fingers and their toes are
73:45
so small
73:46
but they get much bigger right they grow
73:48
into a full adult
73:50
so they grow bigger and they grow taller
73:52
they grow
73:54
what are the different forms of the verb
73:56
grow of course we have
73:57
grow grew grown
74:01
right grow grew grown it's an irregular
74:05
verb
74:05
you have to remember the different forms
74:08
for the different verb
74:09
tenses grow grew grown
74:13
okay next we have this is another verb
74:17
to rest with your eyes closed
74:21
at night this is what you should do
74:24
don't play computer games right
74:26
get in your bed and do this what is this
74:30
right what are you doing you need this
74:32
especially when you're growing when
74:33
you're young
74:34
you need a lot of this what is this
74:36
person doing this person is sleeping
74:39
so she is sleeping get sleep
74:42
go to bed get some sleep or go
74:45
to sleep right sleep at night what are
74:48
the different
74:49
verb forms of to sleep
74:53
we have sleep slept slept
74:56
so this is the same for past tense and
74:59
present uh
75:00
present participle sleep slept slept
75:03
sleep slep slept
75:04
okay that's another irregular verb sleep
75:07
slept slept to rest with your eyes
75:10
closed
75:10
usually we do it at night but sometimes
75:13
we do it during the day
75:14
for a short time if you sleep during the
75:17
day for a short time
75:19
that is take a
75:23
nap take a nap that's a short
75:27
sleep during the day take a nap maybe
75:30
you're tired
75:31
take a nap for 30 minutes or an hour but
75:34
at night
75:34
you sleep at least eight hours usually
75:38
people sleep for eight hours
75:39
some people less some people more right
75:42
but don't play video games all night
75:44
it's important to get some sleep okay
75:47
now to begin life we're talking about a
75:50
baby
75:51
of course the baby there's a point when
75:53
the baby comes into the world
75:56
that is the time that the baby we say is
75:59
beginning life of course
76:00
babies begin life in their mother's
76:03
wombs in their mother's bodies
76:05
but the moment the baby comes out into
76:07
the world we have a special verb for
76:09
that
76:10
what do we say we say to be born
76:13
to be born to begin life
76:17
when were you born
76:21
when were you born okay that's the very
76:23
common question
76:24
when were
76:28
you born you could say well
76:32
i was born in 1980 something
76:37
or i was born in 1980 some of you might
76:40
have been born
76:41
in 2000 something right maybe 2000 or
76:45
2001.
76:46
when were you born what year were you
76:49
born
76:49
okay what year did you come into the
76:51
world born
76:53
okay now this is a verb that
76:57
we talked about before actually to go by
76:59
moving
77:00
your feet right toddlers are learning
77:03
how to do this
77:05
toddlers you remember i talked about
77:06
this toddlers are learning how to do
77:08
this
77:09
what is it it is of course to walk
77:12
to walk right to move by moving your
77:15
feet
77:16
now of course walk you could also say
77:19
run but run is to move fast or to go
77:23
fast
77:24
by moving your feet to just go normally
77:26
normally people walk
77:27
they don't run so to go by moving your
77:30
feet you
77:31
walk okay if you go fast that's run
77:34
okay to say things
77:37
so you're with your friends right and
77:40
you say
77:40
things to your friends they say some
77:43
things to you
77:44
in return so what are they doing of
77:46
course we say
77:47
they are talking to talk talk talked
77:50
talked okay talk to talk with people
77:53
of course talk is a regular verb so we
77:55
don't have to worry about the different
77:56
forms right
77:57
talk talk talk okay so these people are
78:01
talking to say
78:02
things to each other let's talk okay
78:05
or they are talking to each other okay
78:08
what's our next word
78:10
our next word is another verb to right
78:13
to make to make pictures with
78:16
a pen or pencil you probably
78:19
do this a lot even at school you do this
78:22
what are you doing you're making
78:23
pictures
78:24
right maybe a house people or
78:27
landscape with trees maybe fish or
78:30
animals
78:31
but you what are you doing you're making
78:33
pictures you are
78:34
drawing to draw
78:37
to draw means to make pictures with a
78:40
pen or
78:41
pencil now draw is not a regular verb
78:44
it's an irregular verb so what are the
78:46
different
78:47
verb forms what are the different forms
78:49
of this verb
78:50
we have draw drew drawn
78:54
draw drew drawn
78:58
so this verb draw drew drawn okay so to
79:01
draw is to make pictures
79:03
with a pen or a pencil also you could
79:07
yeah with those pens or pencils that's
79:09
drawing
79:10
if you use a paint brush then you're not
79:12
drawing you're painting
79:13
okay so that's different okay paintbrush
79:16
that's painting
79:17
but pencil or pen then you're drawing
79:20
okay that's an interesting point okay
79:24
very nice to look at oh look at this kia
79:27
jio right kipchi
79:28
a little cat is very what we say very
79:32
cute a cat is cute of course but not
79:34
just a cat
79:35
there are many things that are cute like
79:37
for example we're talking about babies
79:39
babies are very cute right when they're
79:41
not crying and they're like
79:43
that's not cute but usually babies right
79:46
and they make the little faces
79:48
that's very cute right so we say very
79:50
cute
79:51
very nice to look at it's very nice to
79:53
look at something
79:54
that is cute it's also very interesting
79:57
right cha misoyo
79:58
right but it's also very cute
80:03
right oh kia wild right that's very cute
80:06
okay the first word has to do with this
80:09
picture here
80:10
what do we call this here
80:14
this is trees cut up
80:17
cut up for making something
80:21
we make a lot of things from trees
80:24
we've talked about this in previous
80:26
lessons probably you've
80:27
we've studied together on a previous
80:29
lesson we can see that trees are used
80:31
for what
80:32
trees are used to make wood we use
80:36
wood to make other things like houses
80:39
furniture desk chair toys
80:43
you can have toys made out of wood
80:47
these things are wooden right a
80:50
wooden chair a wooden desk
80:53
a wooden toy things made
80:56
out of wood wood
81:00
okay what's our next word the next word
81:02
has to do with this here
81:04
of course it's been cut this is a tree
81:06
that has been cut
81:07
but what is the main stem of a tree
81:12
if you remember or if you studied about
81:14
plants you know there are many different
81:16
parts of a plant right there are the
81:19
roots
81:20
there's the stem there's the branches
81:23
the leaves right the flower in some
81:26
plants
81:27
but on a tree right the stem we have a
81:30
special word for it
81:31
because a small plant we don't say this
81:34
word but for a big tree
81:35
it's strong it's thick and we use it to
81:38
make
81:39
wood what is this part of the tree
81:42
we call it the trunk trunk
81:45
tr tr
81:49
trunk trunk we call it the trunk
81:52
of a tree we don't really say the stem
81:55
of a tree that sounds a little strange
81:58
in instead we say the trunk of a tree
82:02
but if it's a small plant yes you can
82:04
say the stem
82:05
but a big plant like a tree that's weird
82:08
we would say the trunk of a tree not
82:11
really the stem of a tree that sounds a
82:13
little bit strange
82:14
so it's better to say the trunk of a
82:16
tree and it's the trunk
82:18
where we get our wood from most of our
82:21
wood
82:22
you can get some wood from the branches
82:24
yes but mostly
82:26
it's the trunk where we get our wood
82:29
okay if you look at the trunk of a tree
82:33
that's been cut right this way not this
82:36
way
82:36
but this way you can see these things
82:38
here what are these there's
82:40
round circles these are a
82:43
circle or many circles inside a tree
82:46
trunk
82:47
so we want to know about one we're
82:49
talking about singular not
82:50
plural one of these is called a
82:53
ring a ring a ring basically
82:56
is a circular shape right many married
83:00
people
83:00
have a ring on their finger right it's
83:03
just
83:04
it's a round shape like a circle right
83:07
and we call these
83:08
rings right rings many we say
83:11
rings so r sound er
83:14
ring an ng
83:21
so we say ring a circle inside a tree
83:24
trunk
83:25
wow you can see many rings inside the
83:28
tree
83:30
now we have another word that we can use
83:32
look at this tree this
83:34
is a very very big tree
83:37
it's big we use a special word to say
83:40
something that's very big
83:42
this tree trunk of course this tree
83:44
trunk is big but look at this tree
83:46
wow it goes from here all the way over
83:49
to there
83:49
that's really big and this is a person
83:51
here right so that's your scale
83:54
right it's very very big these trees
83:57
probably are growing in northern
84:00
california or
84:02
oregon washington the trees are really
84:05
big
84:05
in those states in america what do we
84:08
say they're really big
84:10
one word we can say they're huge
84:13
they're huge they're really really big
84:16
if you go to northern california oregon
84:20
or washington state you can see these
84:22
trees
84:23
in the forest you are you go wow they're
84:26
huge
84:27
they're so amazing we say huge huge is a
84:30
good word to use
84:32
it means very very big
84:35
okay now we have another word here
84:38
that's interesting
84:39
because we want to say that this person
84:42
is
84:42
in the middle point of something
84:46
they are right in the middle of
84:48
something
84:49
you have an area or maybe a room but
84:52
you're right
84:52
at the middle point of that room
84:55
or that area where are you you are in
84:58
the center
85:00
we say in oops in
85:04
the center in the center
85:07
in the center of the room in the center
85:11
of the field right in the center of the
85:15
paper
85:16
something that is in the very middle of
85:18
something the exact
85:19
middle of something they are in the
85:21
center of it
85:22
in the center so here we have
85:26
a lot of fruit a lot of fruit right
85:29
more than enough there's there's enough
85:32
food to make us full but there's more
85:34
than enough we can't eat all of this
85:36
food we can't eat it
85:38
so we have plenty we have plenty
85:42
of food we have plenty of fruit
85:45
we have plenty of wood we have plenty of
85:48
air right so we have more than enough we
85:51
have
85:52
plenty we have plenty of food please
85:54
come over
85:55
share our lunch i have plenty of food
85:59
i can share my lunch with you i have
86:02
plenty
86:04
okay another word we have to watch
86:07
something if you're watching something
86:10
what are you doing you're looking at it
86:13
so this woman is
86:14
looking at her shoe right she's trying
86:16
to get her shoe
86:17
maybe she can't but she's looking at it
86:19
right she's trying to grab it
86:20
her shoe is under her bed but we look at
86:23
things
86:24
look at and watch are very similar you
86:27
watch a television show you look at
86:30
your television you watch a television
86:33
show
86:34
you watch your dog you look at your dog
86:37
right
86:37
so when you watch something you but by
86:40
the way when you watch something you
86:41
watch it for a long time
86:43
when you look at something it can mean
86:45
you look at it for a long time
86:47
it can also mean you look at it to
86:49
examine it what what's going on what is
86:51
it okay
86:52
so look at and watch are very similar
86:55
you look at something
86:56
you watch it c is very quick do you see
86:59
it
87:00
yeah i see it it's over there go get out
87:02
but i see it right that's very quick
87:04
but you look at it
87:07
oh okay i'm watching it okay so you look
87:10
at or watch something
87:13
and then you see it very quick well i
87:14
see it it's right there okay
87:16
okay so those are the differences
87:17
between look at watch and see
87:20
okay to make a tree fall down to make a
87:24
tree fall down
87:25
this was a huge tree it fell down and
87:28
then they cut it
87:29
into pieces they're gonna make wood out
87:31
of it right what do we say
87:32
we cut down i just said it they cut the
87:35
tree down they cut it down
87:37
and they cut it into different pieces
87:39
but when you cut down a tree
87:41
that means it falls down by the way in
87:44
america
87:44
when the workers go in the forest and
87:47
they cut down a tree
87:48
they yell something what do they yell
87:50
they yell timber
87:52
right timber timber
87:56
timber it means the tree is falling down
88:00
but timber also is another word for
88:04
wood it's interesting right so it's like
88:06
the workers are
88:07
going out they cut down the tree wood
88:09
but they don't say wood they say
88:10
timber and that means watch out joshua
88:13
male get out of the way
88:15
right so that's very interesting if
88:16
you're in the forest in america
88:18
and you hear somebody say timber look
88:21
around right
88:22
there might be a tree falling down
88:24
hopefully not
88:25
but probably not but anyway that's what
88:27
they say when you cut down a tree
88:30
that's what happens you make a tree fall
88:33
down you make it
88:34
fall down okay something round
88:38
we talked about that our ring is round
88:41
but a ring makes a shape what is the
88:44
shape called
88:45
it's a circle this is a
88:48
circle we can also say it's a ring like
88:50
the ring on my finger
88:52
or the ring in a tree it's a circle it
88:55
makes a circle
88:56
it's round so something that is round
89:00
it makes
89:03
a circle makes a circle that's the
89:06
shape the circle is the shape it is
89:09
round you could also say
89:10
it has a round shape also a ring
89:14
a ring is a round shape it is a circle a
89:18
ring
89:18
makes a circle okay
89:22
not inside these people are not inside
89:25
their house
89:26
they are what the opposite of inside is
89:30
outside that's very easy right
89:33
in in out opposite
89:36
inside means inside a building in a
89:39
building
89:40
in a building
89:43
someplace where you have a roof a
89:46
ceiling
89:47
and walls around you you are inside
89:50
in a building but if you are out
89:54
of a building there's no ceiling
89:59
above you is sky around you just
90:02
air right then you are outside so
90:06
inside in a building outside out of a
90:09
building
90:09
okay so inside outside
90:13
next to add up to find the total
90:17
so this girl is using a very old device
90:21
to do what she's doing what what is she
90:23
doing she is
90:24
counting to count one
90:28
two three four that's one way to count
90:33
another way is to add up to find the
90:35
total let's say you have many pieces of
90:37
candy
90:38
you want to know how many pieces of
90:40
candy do you have
90:41
you go one two
90:44
three four da 15
90:49
20 50. i have 50 pieces of candy right
90:53
so you're counting the pieces of candy
90:56
don't eat 50 pieces of candy you will
90:58
get a stomach ache right just eat one or
91:00
two pieces of candy
91:02
but to add up the to find the total
91:04
you're counting something
91:06
one two three four and so on
91:09
to count okay the next word is kind of a
91:12
funny picture right
91:13
these guys are buddies but you can see
91:15
there's a big difference
91:17
between these two gentlemen here right
91:20
this guy's
91:21
huge this guy is not huge
91:24
he's not thick by the way thick thick
91:27
also means
91:28
you're gonna like this right he's not
91:30
fat it doesn't necessarily mean fat
91:32
it just means that he's got a wide
91:36
body right he's got a wide body he's
91:38
thick
91:39
he's not thick when a person isn't thick
91:42
we say that they are
91:44
thin thin so thick
91:47
and thin are opposites pandero right
91:50
pandiro
91:51
this man is thick this man is
91:54
thin but we don't really say people are
91:57
thick
91:58
we kind of say he's big right he's a big
92:01
guy
92:02
he's a thin guy you can't say thin thin
92:05
is used for people it's also used for
92:08
trees
92:09
right or other things right a book a
92:12
book can be thick
92:13
or a book can be thin a thick book
92:17
a thin book a big person a thin person
92:20
okay we don't really say he's a thick
92:22
person we say he's a big person we have
92:25
here
92:26
a picture a place with trees and animals
92:29
a place with trees
92:31
and animals i was just talking about
92:34
this place
92:35
do you remember what the name of this
92:37
place is
92:38
starts with an f of course it is a
92:42
forest when you say forest remember with
92:44
the f
92:46
your teeth are on your bottom lip
92:50
forest so this is a forest a place with
92:53
trees
92:54
and animals what's next next we have
92:58
a safe place to be remember this cute
93:01
guy right here
93:02
right he's looking out from his home
93:04
well he
93:05
of course lives in the forest or she
93:07
we're not sure but they live in the
93:09
forest this type of animal
93:10
and many types of animals will make
93:13
what inside a tree right they will
93:16
make a shelter shelter
93:20
and shelter is the same word or it's the
93:22
same meaning
93:23
really for many animals it's their home
93:26
isn't it
93:27
right so this animal will find
93:30
shelter in a tree they'll make it their
93:33
home
93:34
so shelter is like a home for many types
93:37
of animals
93:38
in the forest okay what else
93:42
we have what's this boy doing right he's
93:45
holding on to a tree and he's going up
93:48
into the tree here it says to go
93:50
up like a monkey right so if you think
93:53
about monkeys we saw the picture before
93:55
of the monkey
93:56
what do monkeys do really well right
93:59
they can go up in the tree
94:01
very quickly what is the verb that we
94:04
use to describe
94:05
this action what is this boy doing he
94:08
is climbing of course climb
94:12
is just the root form climb to
94:15
climb he is climbing
94:19
the tree whoops he is climbing
94:23
the tree the boy is climbing the tree
94:26
can you climb a tree but be careful
94:29
right make sure your mother or your
94:32
father
94:33
is watching you when you climb the tree
94:35
it can be dangerous so be careful
94:38
but he is climbing the tree okay
94:42
the next we saw this picture before
94:44
right here is a bird
94:45
now a home built by a bird
94:49
before we talked about shelter right and
94:52
we saw the
94:53
the squirrel the the cute animal looking
94:55
out from the shelter
94:57
this is a type of shelter but it's a
95:00
special word
95:02
for birds only birds make
95:05
this right what do we use for this a
95:07
word we call it
95:09
a nest a nest so we set talk about a
95:13
nest
95:13
you should think ah it's a bird right a
95:16
bird
95:17
makes a nest and a nest is the home
95:21
for the bird it's their shelter it's
95:24
also their home
95:25
for birds we say it is a nest
95:29
okay interesting okay now we have
95:32
another type of home right we've talked
95:34
about
95:34
shelter we've talked about nest now this
95:37
is another type of home and this is a
95:39
interesting looking animal here right
95:41
kind of looks like a dog
95:43
but it's not really a dog it's a
95:45
different type of animal
95:46
and this animal will live in a home in
95:49
the ground
95:50
so many animals will dig in the ground
95:53
and they will make their shelter or
95:55
their home there's a special word for
95:58
this what is it
95:59
we say it's a cave okay
96:02
now sometimes animals will will make a
96:05
small cave
96:06
or maybe there's a big cave that they
96:08
don't make
96:09
but they will live in there what lives
96:11
in caves
96:12
well wild dogs perhaps hyenas
96:16
a hyena is a type of dog a hyena
96:19
is a type of wild dog in africa this
96:23
looks like a hyena but also big animals
96:26
like bears right be careful if you're in
96:29
the woods
96:29
and you see a bear bears are very big
96:32
animals
96:32
and they also live in caves okay so
96:36
cave is another type of shelter okay
96:39
these are all shelters a nest is a
96:41
shelter and a cave is a shelter
96:44
okay another word that we have here
96:47
is the plant part so it's a part
96:51
of a plant the part of a plant
96:55
that holds the seeds so the seeds of
96:58
course
96:59
are what the plant makes and the seeds
97:02
will go into the ground
97:03
and make a new plant right seeds are how
97:06
plants
97:07
make more plants what do we call the
97:10
part of the plant that holds the seeds
97:12
we for many plants it's called the fruit
97:15
right so bananas are a type
97:18
of fruit apples are a type of fruit
97:22
watermelon right that's a type of fruit
97:26
and if you look at each of these fruits
97:28
they all
97:29
have seeds in them and if you take those
97:32
seeds and you put them in the ground
97:34
a new plant will grow okay so we call
97:38
that fruit
97:39
okay not all plants but many plants
97:42
have fruits and that's how they
97:44
distribute their seeds
97:47
okay insect we have an insect here
97:50
and of course another word for insect is
97:53
bug you may know this word from the
97:56
movies right
97:57
so there's in english of course there's
97:59
a lot of uh
98:00
words that have two words that mean the
98:04
same thing right
98:05
insect insect is more formal it's a
98:08
little bit more of a difficult word
98:10
isn't it it's much easier to say bug
98:15
bug right and that's what insects are
98:17
insects
98:18
are bugs and this is an example of
98:22
a bug right so you can say bug or you
98:25
can say
98:26
insect same thing
98:30
is this we talked about this before do
98:32
you remember what i said at the
98:33
beginning
98:34
of this lecture this is an animal with
98:37
long arms right he has long arms right
98:40
and a long tail so a long tail
98:45
not just long arms but also a long
98:49
tail and what type of animal is this do
98:51
you remember what i said at the
98:53
beginning
98:54
of this lecture we said monkey
98:57
so say it with me monkey monkey
99:01
okay so this isn't a monkey and we
99:04
learned about uh the monkey we also when
99:07
we looked at the picture with climb
99:09
the boy is going up the tree like a
99:12
monkey
99:12
monkeys are very good at climbing aren't
99:15
they so
99:16
you find monkeys in forests but not
99:19
cold forests not up in korea well maybe
99:22
up in korea
99:23
and in japan you find monkeys but also
99:25
more commonly
99:27
in the south where the trees where the
99:29
forests are
99:30
warmer there's many monkeys that live in
99:32
the forests
99:33
in the warmer forests uh
99:36
near in the south okay
99:40
again the next one a place where people
99:42
live we talked about this already
99:45
in terms of animals right we've talked
99:46
about shelter we've talked about
99:48
nests for birds we talked about caves
99:51
for wild dogs or bears but people
99:55
where do people live of course we live
99:58
in a house right
99:59
people build a house right you could
100:02
also say
100:03
home but home and house is where
100:06
somebody lives house though is house
100:09
means the building
100:11
home is like a place that you're
100:13
emotionally connected to
100:15
this is my home this is where i live
100:18
people can live in an apartment they can
100:21
live in a tent
100:22
they can live in a cave those are all
100:24
homes right
100:25
but a house is something that's built
100:28
like this right it has doors it might
100:30
have a chimney it has walls
100:32
that were built by people so we've seen
100:35
a lot of different types of shelters
100:37
because this is
100:38
also a shelter so we've seen uh nest
100:41
cave house these are all shelters
100:45
okay next we have something
100:48
used to travel on water
100:52
can you walk on water no you'll sink
100:55
right
100:56
be careful right you jump in the water
100:58
you will sink
100:59
but if you want to travel over water on
101:02
top of the water so you don't
101:04
sink what do you travel in what is this
101:06
this of course is called
101:08
a boat a boat and some boats are very
101:10
small
101:11
like this some boats are very big
101:13
they're like hotels
101:15
and they go across the water okay so
101:18
something used to travel on water
101:19
is a boat
101:23
okay this young girl is doing something
101:26
very good right she's helping her mom
101:28
out she is getting rid of
101:33
some dirty uh stuff on the ground
101:36
so if you say something is not dirty if
101:39
it's
101:40
not dirty the opposite of dirty what do
101:43
we say
101:43
it is clean so clean can be an
101:48
adjective right we can use it as an
101:50
adjective
101:51
it is clean
101:56
we can use it as an adjective the floor
101:59
is clean we can also use it as
102:02
a verb please
102:07
clean the floor
102:11
so we can use it in two ways okay
102:16
as an adjective it is clean the floor is
102:18
clean or if mom
102:19
sees some dirt on the floor she will say
102:22
to her daughter
102:24
please clean the floor and that's a verb
102:27
please clean up your room right please
102:30
clean up your desk for example okay
102:34
so we can use it as an adjective or as a
102:37
verb
102:38
very commonly okay the next one
102:41
an animal with feathers and wings
102:44
we already talked about this type of
102:46
animal right this type of animal
102:48
what type of shelter does it make in the
102:51
trees
102:52
it makes a nest what is it of course
102:55
we know it's a bird and there are many
102:58
different kinds of birds right
103:00
many different shapes different sizes
103:03
different colors but we all if they have
103:06
feathers and wings we say it is
103:10
a bird okay so we see a bird here
103:13
a warm and rainy season
103:16
so it's a warm season a lot of rain
103:19
comes down
103:20
and as we can see there's lots of
103:22
insects come out
103:24
flowers bloom what season is it
103:27
we say it is spring spring
103:31
okay so in spring life comes out
103:35
it and it also rains a lot okay next one
103:39
is a hot season kids go swimming they
103:42
enjoy swimming it's very hot
103:44
so you can wear a bathing suit no
103:47
problem
103:47
we talked about that what season is it
103:50
it is
103:51
summer summer is a
103:54
hot season okay next one
103:58
we talked about this a dry and cool
104:01
season it's dry
104:02
doesn't rain a lot leaves fall
104:06
from the trees it's cool so you have to
104:08
wear more clothes
104:10
this of course is fall you can also say
104:14
autumn but a simpler word is fall
104:17
it's easier to say fall in
104:20
the fall okay next one we talked about
104:24
this one
104:25
a cold season there are snow
104:29
flakes falling down we can make snowmen
104:32
so there's a lot of snow
104:33
it's a cold season what season is it
104:37
of course it's winter winter
104:41
it is cold in winter
104:44
let's learn some more words about
104:46
seasons let's take a look at this this
104:49
is an
104:49
interesting picture here when we talk
104:52
about the seasons
104:53
remember i said there are four seasons
104:56
and this picture shows all four
104:59
seasons usually we
105:03
start with spring spring
105:07
summer fall winter
105:10
and then it starts again it's like a
105:12
circle right
105:14
we start with spring because that's when
105:16
life comes back out
105:17
in the winter everything seems dead but
105:20
in the spring it comes back out
105:22
and the time of the year with special
105:24
weather there are four of them
105:25
and i use that word already of course
105:28
we're talking about
105:29
season there are four seasons spring
105:32
summer fall and winter they are all
105:35
called seasons and there are four of
105:38
them
105:39
okay let's take a look at this word
105:42
here we have a lot lots of vegetables
105:44
here clean
105:46
and new is our definition what word are
105:48
we looking for
105:49
of course we're looking for fresh
105:52
because
105:53
especially when you think about food
105:56
you want your food to be fresh
106:00
so tomatoes are bright red they're
106:04
round and they're strong right if
106:07
they're not fresh they're
106:08
old and they don't taste so good right
106:11
but you want fresh food right so clean
106:15
it's clean and it's new not old
106:18
it is fresh
106:22
let's take a look at another word look
106:24
at this here are two birds right here
106:26
is a small bird and here is a
106:29
what not small of course we're looking
106:31
for big here's a big
106:33
bird right big bird okay so sometimes
106:37
you can see very big birds
106:38
sometimes they're small birds but of
106:40
course there are many things that are
106:42
big
106:42
many things that are small something
106:45
that is not small
106:46
the opposite pandero is big
106:50
not small pandito small big okay
106:54
very warm if something is very warm
106:57
remember
106:58
when i talked about summer i said it is
107:00
what
107:01
it is hot it is hot
107:05
in summer so very warm warm
107:08
is kind of a little warm but
107:11
hot is very warm right so you go from
107:15
cold let's do a little chart here cold
107:19
is really right freezing lots of snow
107:22
but next is cool
107:26
right cool is not as strong as cold
107:29
it's a little warmer and then after cool
107:33
we come to warm okay
107:36
so warm not cool anymore and then after
107:39
warm a little stronger is
107:42
hot so we can have a little chart here
107:45
cold
107:46
cool warm hot and of course they go in
107:50
degrees
107:51
okay so hot is very warm
107:55
now we have to move through the air like
107:58
a bird
107:59
can you move through the air like a bird
108:02
i'm sorry you can't
108:03
unless your big brother or sister throws
108:06
you
108:06
right then you do what you
108:10
fly but your big brother or sister
108:12
shouldn't throw you
108:13
unless you're going to land in a
108:15
swimming pool okay
108:17
flying can be dangerous because landing
108:20
well flying isn't dangerous
108:22
landing is dangerous right okay so to
108:25
move through the air like a bird
108:27
means to fly and that's very interesting
108:30
okay
108:31
so fly but fly is
108:34
a special verb in english it changes
108:38
form depending on how you use it
108:40
especially in the past tense
108:42
what are the three changes we say fly
108:46
flew flown so remember
108:49
fly flew flown fly flew
108:53
flown those are the three different verb
108:55
tenses
108:56
for the verb fly okay
109:00
now we have a word here for water to
109:03
fall
109:04
from clouds so when sometimes
109:08
right you go outside and you feel wet
109:11
what's going on
109:12
there's water falling from the sky from
109:15
the clouds in the sky
109:17
it falls down what do we say it's doing
109:20
we say
109:20
it is raining now rain can be
109:24
a noun right it
109:27
is rain so we say it
109:31
is rain we can say
109:35
there is a lot of rain or there's just
109:38
a little rain that's a noun we can also
109:42
use it as a verb it
109:46
is whoa it is raining
109:51
it is raining today or it will
109:55
rain tomorrow it rained
109:59
yesterday so noun or verb
110:02
with rain it is rain a lot of rain a
110:05
little rain
110:06
noun verb it is raining it will
110:10
rain it rained this morning
110:13
okay moving on being alive
110:17
a short time okay so we have
110:21
actually it's kind of like a contrast
110:22
here here we have an old man
110:25
right he's been alive for a long time
110:29
then we have a boy here right and the
110:32
word we want is the word to put
110:34
next to the boy because the boy has been
110:36
alive
110:37
only a short time so what do we say
110:40
about the boy
110:41
if the old man is old we say the boy is
110:44
young right so that would be the
110:46
opposite
110:47
of old young and old opposites
110:51
okay to get ready
110:56
looks like this woman she wants to make
110:58
a meal right she has a lot of food
111:00
she's going to get ready what is she
111:02
going to do she's going to prepare
111:06
prepare a meal probably your mother
111:09
or maybe your father prepares a meal
111:12
every day sometimes prepares three meals
111:16
a day
111:17
but at least it's prepared once a day
111:19
that's dinner right
111:20
dinner is prepared every day to get
111:23
ready
111:24
but prepare isn't just food you
111:27
prepare to prepare is like jun bi hada
111:30
right june bihar i think so
111:32
when you get ready for school you
111:35
prepare
111:36
you put your books in your bag you put
111:39
on
111:39
your school clothes you're preparing to
111:42
go to school
111:44
so when we get ready for something we
111:47
are preparing
111:48
we prepare for something we prepare for
111:52
dinner
111:52
or you can prepare something you prepare
111:55
dinner
111:56
you prepare your bag you prepare your
111:59
notes
112:00
okay what do we see here this is an
112:02
interesting picture
112:03
isn't it we have little pieces of wood
112:06
standing up
112:07
right and we have somebody's going to
112:09
push it right
112:10
and that's going to hit that and they're
112:12
all going to fall over
112:14
so we're going to make something happen
112:16
to make something happen
112:18
we're going to cause one to hit the
112:20
other and the other and the other and i
112:22
just use the word there
112:23
right to cause cause
112:26
so if you cause something that means
112:30
you made it happen if you cause all of
112:33
these to fall down
112:34
right you made it happen to cause
112:38
something to happen the wit
112:41
the tornado caused the car
112:45
to fly away okay so something
112:48
makes another thing happen to cause
112:52
okay next word this is a type of weather
112:56
right
112:57
this this little girl right she's in her
112:59
coat she's in her
113:00
knit hat and look it's
113:04
very strong the wind weather with
113:07
fast moving air the air is moving
113:10
past her very quickly in this case
113:13
what is the weather we say the weather
113:16
is
113:16
windy windy it's very windy so the wind
113:21
is strong it's windy
113:24
okay the next one
113:27
strong dangerous weather strong
113:30
dangerous weather of course we talked
113:32
about tornado
113:33
but we're looking for not just tornado
113:35
but any type of weather
113:38
any type of weather that is
113:41
dangerous or strong we could say storm
113:45
it is a storm so a tornado is a
113:49
type of storm but there are other types
113:52
of weather
113:53
for example it rains a lot
113:56
and there's lightning and thunder that's
113:59
a storm
114:00
if it snows a lot too much snow
114:04
your parents can't drive their car
114:07
nobody can
114:08
move everybody stays inside that's a
114:11
storm a snow storm so
114:14
some storms are very big and cause a lot
114:16
of water
114:18
rain or snow to fall down
114:21
very quickly and we call those storms
114:24
okay i taught you this word before do
114:27
you remember seeing this picture before
114:29
right this is dangerous bright light
114:32
from storms okay dangerous bright light
114:36
from storms we say it's light ning
114:39
just two sounds light ning lightning
114:42
it's lightning and of course with
114:44
lightning i also said something else
114:46
with lightning you also hear thunder
114:50
right so thunder and then after
114:54
oh actually before thunder you see the
114:56
lightning you see the flash
114:58
and then a little bit later you hear the
115:00
thunder
115:01
so thunder and lightning very common
115:05
uh thing in a storm to experience
115:09
okay so lightning the next word oh my
115:13
gosh
115:14
look what happened it's terrible right
115:16
there was a
115:17
strong wind maybe a very big storm
115:21
very strong winds and it pushed this
115:24
tree
115:25
over onto this house that's terrible
115:28
these poor people who live there right
115:30
to make
115:31
into nothing what did this tree do
115:34
it made the house into nothing well
115:37
maybe they can save it but you could say
115:40
destroy
115:41
the tree destroyed the house
115:45
sometimes in a flood there's a lot of
115:47
water the water will come
115:49
and it might bury your car under the
115:52
water
115:53
and you can't use your car anymore your
115:55
car is destroyed
115:57
okay so storms are very dangerous they
116:01
cause a lot of damage storms destroy
116:05
homes cars many
116:08
things that are destroyed in a storm
116:12
okay the next word we saw this picture
116:14
before right the people with no face
116:17
okay let's take a look of course but
116:19
we're looking at the water again
116:21
a lot of water that goes onto land
116:24
so usually the water is in the river
116:28
or it's in a lake but if it there's a
116:30
lot of water comes from the sky
116:32
in rain or as snow then maybe that water
116:36
will come onto the land
116:37
and cover everywhere and of course we
116:40
say that is a
116:41
flood now by the way flood
116:45
can be used as a noun
116:49
for example there
116:52
is a flood
116:55
there is a flood that's a noun
116:58
there is a flood but flood can also be
117:01
used
117:02
as a verb the
117:06
river flooded
117:11
over okay or you could also say
117:15
the town flooded that means the town was
117:18
covered in water
117:18
so we can use flood as a noun there is a
117:21
flood
117:22
or a verb the river flooded over the
117:24
river got too big
117:25
and it flooded the surrounding area so
117:28
we can use flood as a noun or as a verb
117:31
okay next one to begin these
117:35
uh boys are running in a race right
117:38
at the start of the race right at the
117:41
start of the race
117:42
they begin to begin means to start
117:45
okay to start okay
117:49
here we have another word this is a an
117:51
interesting picture all these pieces of
117:53
wood seem to have fallen down maybe they
117:56
they they made something like a tower
117:59
before
118:00
but they fell down so to make something
118:02
fall
118:03
down this is a kind of a special word
118:05
it's a little bit of
118:06
a difficult word it is to
118:10
topple to topple pronunciation
118:14
topple topple to topple
118:17
if something falls over especially
118:20
something that's very
118:22
large very big and tall it will fall
118:26
over
118:26
it will topple so imagine if you cut
118:29
down a tree
118:30
the tree falls over we say the tree
118:33
topples over
118:34
buildings might topple over okay
118:37
so to topple means something very tall
118:40
falls over whoa
118:43
he looks kind of interesting does he
118:45
look like me
118:46
maybe okay he's a weatherman right
118:50
now news that tells us the weather
118:53
news that tells us the weather you want
118:57
to know
118:58
about tomorrow will it be
119:01
sunny will it be windy is there a storm
119:05
coming
119:05
so you want news that tells us the
119:08
weather
119:09
what do you want to look at you want to
119:12
look at
119:12
the weather report this is the
119:16
news that tells you about
119:19
the weather okay
119:22
here we have an object here it's a very
119:25
colorful object
119:26
they're not all like this maybe i'm sure
119:28
you have
119:29
one of these at home it's a tool
119:33
a tool is something we use right
119:36
a tool we hold we hold in our hand
119:39
to keep the rain off it's raining
119:42
outside
119:43
you don't want to get wet so you use one
119:47
of these
119:48
to keep the rain off you want to stay
119:53
dry right you don't want to get wet
119:56
you want to stay dry you want to keep
119:58
the rain
119:59
off what is it usan
120:02
in korean umbrella in english
120:06
okay so i'm sure you have a uson jipe
120:10
i'm not sure if my korean's that good
120:12
but do you have an umbrella at home
120:14
i'm sure you do okay so umbrella
120:19
okay now in the summertime oh
120:22
it's really hot isn't it if you're in
120:25
the park
120:26
and you're out in the sun the sun is
120:28
hitting you oh it's so hot
120:30
and you sweat dumb money hail right oh
120:32
no
120:36
right i'm very hot so it's too hot in
120:39
the sun
120:40
you want to but you don't want to go
120:41
inside a building you want to enjoy the
120:44
park
120:44
so maybe you go under a tree or maybe
120:47
there's an umbrella
120:48
a big umbrella so you want to go to an
120:51
outside place
120:52
with no sun like these
120:55
ducks are smart right they're not
120:58
in the sunlight they went in the dark
121:01
area under the tree a place with no sun
121:05
what is this dark area it's a little
121:08
cooler there right we say it's the shade
121:11
shade so if you're outside you're in a
121:15
park
121:15
or you're playing soccer and the sun is
121:18
too strong
121:19
maybe you want to go in the shade
121:22
go in the
121:25
shade in the shade
121:28
because the shade is cooler
121:32
than in the sun you don't have the sun
121:36
hitting you directly so it's a little
121:39
cooler
121:40
in the shade it's a little cooler
121:43
in the shade okay
121:46
num the next word to move air
121:50
now we talked about windy right this
121:52
picture looks like it's windy
121:54
but windy is an adjective it is
121:57
windy right it is windy outside
122:01
that's imaginative but we're looking for
122:03
a verb here to move
122:05
air why is it windy what is the
122:08
action what's happening well we're
122:10
looking for the verb
122:12
blow when when the wind
122:15
blows right then the air
122:18
moves we can blow
122:22
right you can put your hand in front of
122:24
your mouth
122:26
you can feel the air moving i am blowing
122:30
right blow blue
122:33
blown this is an irregular verb so it
122:37
changes
122:38
according to how we use it when we use
122:41
it
122:41
in now to blow that means right now
122:44
blue past tense blown past participle
122:48
have blown
122:49
right blow blue blown
122:52
blow blue blown so
122:55
in english i'm sorry some words you have
122:58
to some verbs you have to know the
123:00
different
123:00
forms when you use them in different
123:04
time periods okay so blow
123:07
first word that we're going to go over
123:10
here is
123:10
to become something else this is a nice
123:13
picture right
123:15
it's the picture of the same thing it's
123:18
changing it's changing from this little
123:21
uh
123:22
piece here you can see the butterfly is
123:25
coming out
123:26
so the caterpillar used to be here
123:29
but the caterpillar changes
123:32
becomes something else what does it do
123:35
it
123:35
turns into it turns into
123:39
a butterfly to turn into means
123:42
to change from one thing to another
123:46
the caterpillar caterpillar
123:53
you know the caterpillar the the little
123:55
green insect that crawls around looks
123:58
like a worm
123:59
the caterpillar turns into
124:03
a butterfly a beautiful butterfly
124:07
and that's what turned into means to
124:10
change okay next word
124:13
number two these are very pretty rocks
124:16
aren't they
124:17
very nice looking rocks what are they
124:19
they are a special type of rocks an
124:21
important part of rocks
124:23
they are minerals now these are large
124:27
you know they're kind of big right but
124:30
when plants grow in dirt
124:32
right the plants take the minerals up
124:35
from the dirt
124:36
and the minerals are in the plants when
124:38
we eat the plants
124:40
we eat some minerals very small very
124:43
small pieces
124:45
of minerals but they're good for our
124:46
bodies we need those
124:48
things we need minerals and we need
124:51
vitamins
124:52
so minerals are an important part of
124:55
rocks
124:56
they're also good for us but don't eat
124:58
these you'll break your teeth
125:00
right just eat the plants you can't see
125:02
the minerals
125:03
in the plants but they're good for you
125:06
okay
125:07
next word oh it's too bad it's sad
125:10
here's a fish the fish is out of water
125:14
the fish cannot live out of water so
125:17
it's not alive
125:18
what's another word that means not
125:21
alive the word of course is dead
125:25
dead the fish is dead so something that
125:28
is not alive
125:29
is dead okay the next word number four
125:33
here we have a picture of a lot of dirt
125:35
but there's also some plants here
125:38
right and we have this uh definition
125:41
to break down to break
125:44
down if you imagine that this is a lot
125:48
of plants or maybe we could put some old
125:50
fruit like some old apples or some old
125:53
oranges
125:54
on top of there and after a while it
125:57
begins to smell
125:58
right because what is it doing it is
126:02
rotting too rot this is a verb
126:05
to rot means to break down
126:08
and usually things get oh they get
126:10
smelly right
126:11
and they break down over time and they
126:14
go back
126:14
into the dirt they go back into the soil
126:18
to rot to break down
126:21
okay the next word look at these guys
126:24
they're having fun
126:25
right they were hiking all day now they
126:28
are at the
126:29
highest position in the mountains where
126:33
are they
126:33
they are on the top on the top
126:37
on the top
126:40
right they are on the top of the
126:43
mountain so
126:44
top is the highest in position it's the
126:47
top
126:47
thing the thing that is on top right
126:51
to be on the top top okay
126:55
number six the gas that we breathe
127:01
right if you breathe
127:05
you can feel the wind right the wind is
127:08
gas
127:09
what is that gas that's all around us we
127:12
breathe it
127:12
we need it so that we don't die so
127:16
that we stay alive what is it it's
127:18
called
127:19
air air air is all around us
127:22
right it's the gas that we breathe
127:25
remember we can't really see the gas
127:27
the gas is very light we can move around
127:29
in it
127:30
right but we breathe it that's the gas
127:33
that we're breathing
127:34
that's called air okay next word
127:37
number seven to keep in place
127:40
okay this is an interesting picture
127:42
somebody has
127:43
a strong grip on their money
127:46
right ton okay because it's very
127:49
important
127:49
but what are they doing if you have like
127:52
baguan or obeguan in your hand
127:54
you don't want to lose it you put in
127:56
your hand you close your fingers around
127:58
it
127:58
what are you doing what is that verb
128:01
hold you are holding your money
128:05
also when you go on the street and
128:08
you're walking on a busy street
128:09
hold your mother's hand hold your
128:13
father's hand
128:14
because you don't want to get in the
128:15
street it could be dangerous hold your
128:18
brother's hand or your sister's hand to
128:20
take care of them okay
128:22
so you hold now this is an irregular
128:26
verb
128:27
it changes so we say hold
128:30
held held right hold it's a present
128:34
tense held past tense and held
128:36
pp right hold held held
128:40
okay good next word i kind of talked
128:43
about this before
128:44
a little bit when i talked about air i
128:47
said
128:47
air is all around us in all places
128:52
another word we could use everywhere
128:55
it's a big word right everywhere that's
128:57
a really big word
128:59
if you look at the sand right there is
129:01
sand
129:03
sand is a type of dirt by the way but
129:06
sand is not
129:07
good dirt things don't grow well in sand
129:10
but
129:10
in the desert sand is everywhere
129:14
right right now air is everywhere
129:18
right okay so everywhere in all places
129:22
everywhere around us okay next word
129:26
number nine at a lower place
129:29
so here we see a man he's sitting by a
129:32
tree the tree is very tall
129:34
right the branches and the leaves are on
129:37
top
129:38
there they're on top where is he he is
129:41
below he's below the branches
129:44
and the leaves he is below so what could
129:48
say
129:48
here is a pen right here's my hand the
129:51
pen
129:52
is below my hand okay so below
129:56
at a lower place
129:59
number 10 kind of
130:02
slimy right i said slimy slimy is
130:05
uh you know it's a little wet
130:09
and it's a little soft right that's
130:12
slimy
130:12
do you want to pick up that worm i'm
130:14
sure the girls in the audience they
130:16
don't want to pick up that worm
130:18
the boys are like yeah let's pick up the
130:19
worm right okay but it's a little
130:21
slimy right and we can see this worm
130:24
in the dirt which is very wet it's
130:28
also slimy but when we see a mix
130:31
of rotting stuff and soil
130:34
so imagine that there's like old uh
130:37
fruit
130:38
on the top right it's just kind of
130:39
rotting and and breaking down
130:42
uh and it's a mix of that stuff and soil
130:45
there's a special word we use for it
130:47
it's a little hard to pronounce but look
130:50
at this word
130:50
it's humous
130:55
hue mus two sounds two sounds
130:59
hue mus humus so we say
131:03
humus that is the mix of rotting stuff
131:07
and soil good for growing plants
131:10
okay now here we have an interesting
131:13
picture we have many green apples
131:15
they're a little sour
131:17
right green apples are a little sour and
131:19
then we have one
131:20
red apple it's a little more sweet right
131:24
when we say not the same there's many
131:26
words that mean not the same we're going
131:28
to look at one word here is
131:30
other right these are the all the green
131:33
apples
131:34
i the other apple is red
131:37
i have many green apples but the other
131:40
apple
131:41
is red so something that is not the same
131:44
as
131:45
other as as the what you have that is
131:48
the other right when you're saying
131:49
something is different not the same
131:52
the other okay
131:55
having a special use something that has
131:58
a special use
131:59
what do we call that we can say it's
132:02
important
132:03
right here we have a picture of a little
132:06
girl
132:06
and she's getting ready for bed maybe
132:09
she's praying
132:10
and she has a little teddy bear with her
132:13
right
132:13
the teddy bear is very important
132:16
to the girl what is important
132:20
in your life do you have a toy that is
132:22
your favorite toy
132:24
it's very important to you maybe you
132:26
have a book
132:27
that you like to read that book is
132:30
important
132:30
but also think about your family your
132:33
family members are
132:34
very important your mom is important
132:37
your dad is important
132:39
your brothers and sisters i know
132:41
sometimes we fight
132:42
but they're important to you too these
132:45
are things that have
132:47
not just a special use but a special
132:49
value
132:50
to you they are important okay
132:54
this is a home right a place where
132:56
something
132:57
lives is of course a home many homes
133:01
are made from bricks and bricks are made
133:05
from soil or dirt we live in dirt
133:08
homes is it dirty no
133:11
it's clean because of the way we make
133:14
bricks
133:15
that's what we're talking about how
133:17
different homes are made
133:18
from bricks and of course we're going to
133:21
look at not just this word
133:23
but many other words for this lesson
133:26
let's go for number two
133:28
the second word to cook in an
133:31
oven this of course in the background
133:33
that's an
133:34
oven right you put food usually
133:37
you put food in an oven lots of heat
133:41
and you get a nice loaf
133:44
of bread or cake that comes out and of
133:47
course this means to
133:49
bake when you put food in the oven
133:52
lots of heat goes on it and you bake it
133:55
so you bake a cake bake a loaf
133:59
of bread something like that so to bake
134:03
here of course is what we were talking
134:05
about before right we just used this
134:07
word
134:08
it's actually they say a space for
134:10
cooking at a high heat
134:12
a space is on the inside of course this
134:15
is a device
134:17
or appliance that you find in your
134:20
kitchen
134:22
appliance
134:24
there are many appliances in your
134:27
kitchen
134:28
one appliance of course is this thing
134:31
which we just
134:32
talked about that's an oven an
134:35
oven by the way just for your
134:39
information this part
134:42
is the oven this part
134:46
don't say oven this part is
134:50
stove the top is the stove
134:54
the middle part is the oven
134:57
okay next one wow big house right
135:01
looks like a castle right very
135:04
strong and lasting lasting means
135:08
it will be there for a long time
135:12
right lasting for
135:15
a long
135:18
time like this house this
135:21
castle house just one house very rich
135:24
person
135:25
or big building this has been there for
135:28
a long
135:29
long time right so what do we say it's
135:32
sturdy it's a sturdy
135:36
building it's a sturdy building
135:39
it's very strong and it will last for a
135:42
long time
135:44
it will be there for a long time it's
135:46
already been here for hundreds of years
135:48
that's a long time this
135:50
building is very sturdy okay next word
135:55
this of course here is what do we call
135:57
this couple of birds are sitting on it i
136:00
hope they're not angry they don't look
136:01
angry
136:02
they're just birds right okay so a
136:04
couple birds on top of this one
136:06
what holds a roof up of course this is a
136:10
wall
136:11
these birds are sitting on a wall
136:14
a wall holds a roof up right if you
136:18
have a a roof over your head what holds
136:21
it up
136:22
the walls the walls have to be sturdy
136:25
if the walls are not sturdy the roof
136:28
falls on top of you
136:29
right so walls walls should be sturdy
136:35
what's this here this looks interesting
136:37
it's a box that's not a box
136:39
it's a block a block used to build
136:42
things and we
136:43
we put these things on top of each other
136:45
we call this of course
136:46
is a brick we said it before when i
136:50
talked about a brick
136:52
wall right bricks there are the little
136:55
blocks
136:56
that you use to build a brick wall
136:58
remember the wall we just saw
137:00
the birds were sitting on it it was red
137:02
there are many bricks
137:04
in that wall now
137:08
when you take bricks and you put them on
137:10
top of one another or you take
137:12
books and you put on top of
137:16
each other right you take
137:20
one one book and you put it on top of
137:23
that book and on top of each other you
137:26
keep putting more and more and more
137:28
and more books what are you doing this
137:30
is a special
137:31
verb it's to stack it means
137:35
to keep putting on top of each other
137:37
right you have one book
137:38
put another book another book another
137:40
book another book
137:41
or one brick another brick another brick
137:45
you're stacking the bricks or books
137:48
on top of each other or whatever it is
137:51
can you stack
137:52
apples if you're really good you can
137:54
stack
137:55
apples but not too high they'll fall
137:57
over
137:58
books are easier to stack bricks are
138:01
easier
138:02
to stack ok
138:05
a straight line so here we see that we
138:08
have many straight lines right going
138:10
this way
138:11
this is a straight line a straight line
138:13
a straight line
138:14
you could also go like this a straight
138:16
line a straight line
138:18
what do we call these we call these rows
138:23
so if you go to a movie theater right
138:25
younghua
138:26
right you can see many uh
138:30
seats and your ticket has the number
138:33
and the row on your ticket so you know
138:36
where to go it says
138:38
row h so you go a b c
138:41
d e f g h
138:44
h that's my row then you go over to the
138:47
number
138:48
so look to find out what row you are
138:51
in and then you can find your seat so a
138:54
row especially when we talk about
138:56
seats we talk about rows in a big
139:00
theater or stadium for example
139:03
okay let's move on to number nine whoa
139:05
what's that
139:06
that's a really weird soup right tsubaki
139:10
what the heck okay that's just a funny
139:12
picture
139:13
it doesn't really look like that right
139:16
having
139:16
four straight sides
139:20
four straight sides of course it would
139:22
be square
139:23
is a subac square tsubak watermelon
139:29
watermelon
139:31
is a watermelon square
139:35
that's crazy right watermelons don't
139:37
look like that
139:38
that's just a funny picture watermelons
139:41
are round right they're round
139:45
or not exactly round like a like a ball
139:48
you could also say oval oval
139:52
is like a watermelon some watermelons
139:54
are exactly
139:55
round like a ball that's true they are
139:58
round perfectly round
140:00
but usually watermelons are longer on
140:02
the ends
140:03
right and not so long on the top and
140:05
bottom so we say they're
140:06
oval so many different shapes square
140:10
would be like a box
140:11
right if you have a box that is
140:14
a square box am i a good artist
140:19
yeah kind of i guess okay that would be
140:21
a box it's a square
140:23
box okay that would be square okay
140:26
number ten
140:28
uh-oh what's wrong with this guy
140:32
someone who builds but he's not building
140:34
very well
140:35
look he's making what what's going on
140:37
there you need another brick over here
140:40
pablo okay and look he didn't fill up
140:43
that that
140:44
position there he needs more experience
140:48
don't hire him okay but anyway oh
140:50
someone who builds this is
140:52
interesting this is easy right someone
140:55
who
140:55
builds this is your verb to
140:58
build but we want to say a
141:02
person who does this so it's very easy
141:04
just take the verb
141:06
b u i l d
141:09
and add e r e
141:13
r ah there we go that's our word builder
141:16
and you can do this with many verbs in
141:20
english
141:20
yay right someone who
141:24
drives to drive if you go to
141:27
school right sometimes you ride in a
141:31
school bus
141:32
or you just take the city bus the person
141:35
who drives the bus is a
141:40
driver driver
141:42
okay so many verbs in english
141:46
you just add er not all of them
141:49
but many of them it's a common way to
141:52
use the verb to talk about a
141:55
person who does that thing
141:58
okay so uh a builder but we have to be
142:02
careful with this guy he's not a
142:03
good builder right he's making some
142:06
strange uh
142:08
problems here okay anyway let's move on
142:11
number 11.
142:12
now here we have a by the way this is an
142:16
exception right what is he doing he's
142:18
cooking
142:19
to cook to cook but don't say
142:23
cooker don't do that that's an exception
142:26
we say he's a
142:31
cook don't say cook er
142:34
right that's that's an exception i'm
142:37
sorry
142:38
english has many exceptions but don't
142:40
say cooker
142:41
he's a cook what is he doing he's
142:44
mixing together with a big iron piece
142:48
or sometimes your mom if she's making
142:51
soup
142:51
she'll take a wooden spoon and she'll
142:55
mix together what is she doing she is
142:58
stirring to stir the pot
143:02
right to stir things is to mix it
143:05
together
143:06
okay let's take a look number 12
143:10
glue this is not really glue but it's
143:13
like glue it's similar to glue glue
143:16
made from sand and water sand and water
143:20
makes
143:20
glue well it can if you get the right
143:25
mix maybe you've seen this before when
143:28
you see
143:29
construction workers they are working
143:32
they're called
143:33
workers right when you see construction
143:36
workers
143:36
making a new sidewalk they have this
143:40
material it's just sand and water and it
143:43
it's not glue
143:44
but it acts like glue it behaves
143:48
like glue it sticks things together
143:51
what do we call it we call it cement
143:55
cement cement is a common
143:59
building material most buildings
144:02
are made from cement probably
144:06
if you are in an apartment building
144:09
right now your apartment building
144:12
was made from cement sand and water
144:15
dirt that's what we're talking about
144:18
right
144:19
many homes were made from dirt are made
144:22
of dirt okay first word
144:25
is a hole in a building
144:29
that we look through a hole
144:32
now usually it's not a hole that
144:35
somebody made because they were angry
144:37
no it's a hole that people make that the
144:39
builder of the building makes
144:41
we call it a window right it's not just
144:43
a hole
144:44
and sometimes we cover that window with
144:47
glass
144:47
right so air can't come in and out but
144:50
we can look out
144:51
right a hole in the building that we can
144:53
look through
144:54
because if there are no windows oh no mo
144:57
shimsham hail right
144:58
it's very boring we feel we don't feel
145:01
good
145:01
so we want windows we can look through
145:03
and light
145:05
natural light from outside can come in
145:08
that's good
145:08
chung moon right in karim you say
145:10
changmun that would be
145:12
window a window
145:15
number two on a bright
145:18
sunny day you see this a lot don't you
145:21
this is a place where light doesn't go
145:25
right light goes here and here and here
145:28
and here and here and here right but
145:31
light
145:31
does not go here or here so a place
145:34
where light
145:35
doesn't go is a shadow
145:40
and on a sunny day your shadow
145:43
is always with you right you can always
145:46
see your shadow and you can see
145:48
other people's shadow too you can see
145:51
the shadow
145:52
of buildings you can see the shadow
145:55
of cars sometimes you see the shadow of
145:58
an
145:58
airplane whoa right and that's very
146:01
interesting
146:02
an airplane up in the sky can make a
146:05
shadow on the ground okay so that's
146:08
shadow
146:09
number three to trap and hold
146:12
wow he's a he looks like a good yagu
146:14
player right he's a good baseball player
146:16
and he's going to see the ball right
146:18
here he's getting ready it's going to go
146:20
in his glove
146:21
what is he going to do he's going to
146:23
catch
146:25
catch the ball to trap something
146:28
because something's moving you stop it
146:30
that means to trap it
146:31
and then you hold it right that means to
146:34
catch
146:34
something okay so he's going to catch
146:37
now let's take a look
146:38
catch caught caught because catch
146:42
is an irregular verb it's not a regular
146:45
verb so
146:46
catch caught caught okay that is the
146:49
verb to use
146:50
to trap and hold something okay the next
146:54
word
146:54
number four to keep from going
146:58
stop right if you see the policeman
147:02
if you're going to walk across the
147:03
street be careful the policemen might
147:05
say stop
147:06
it's a red light don't go stop
147:10
wait okay that means to keep from going
147:14
stop stop opposite of go of course
147:17
okay so be careful when you're on the
147:19
street pay attention you need to know
147:21
when
147:21
you should stop and when you should go
147:25
number five energy that warms
147:29
things these two girls are sitting in
147:32
front of a fire
147:33
we talked about three types of energy
147:36
before right
147:37
remember one type of energy that warms
147:40
things that makes you
147:41
warm in front of a fire or a fireplace
147:45
you feel heat you
147:48
feel heat ah it keeps you warm
147:51
maybe outside it's cold it's winter
147:54
you want to stay inside next to a fire
147:56
to feel heat
147:58
ah choil number six
148:02
to use heat we use heat not just to warm
148:05
our bodies
148:06
but we also use heat with food we
148:09
change food right if you have
148:13
um for example a steak right
148:16
the steak is not brown when you mother
148:19
buys it
148:19
at the store it's pink it's red
148:23
do you want to eat it well that's raw
148:25
meat
148:26
you don't want to eat that you want to
148:28
change it you want to change it so it's
148:30
brown warm and it's juicy
148:33
right that's what you do
148:36
with heat then is you cook you cook
148:40
the food that's changing the food use
148:43
heat to change the food
148:45
that is to cook are you a cook
148:48
or do you let your mom cook all the time
148:51
probably let your mom
148:52
but help her out see if you can help her
148:55
to cook
148:56
okay number seven this man
149:00
seems like he's trying to hear something
149:03
something we
149:03
hear right it's another type of energy
149:06
we talked about
149:08
in the beginning we talked about three
149:10
kinds of energy
149:12
right this is one type this of course is
149:15
sound sound is something we
149:19
hear there are many different kinds of
149:22
sounds right there's loud sounds there's
149:25
soft sounds right there's long
149:29
sounds and short sounds there's all
149:32
different kinds of sounds
149:34
good sounds and bad sounds right but
149:36
they are all sounds
149:40
here we have to pass a thing to someone
149:43
else
149:43
this woman here is giving the little
149:46
girl a basket and i just use the word
149:48
right
149:49
she's giving to give
149:52
give and give is an irregular verb so we
149:55
say
149:55
give gave given one more time
149:59
give gave given okay good so that's
150:04
very easy verb you give something you do
150:06
this all the time don't you
150:08
you give something to somebody else very
150:11
common thing to do
150:14
number nine what makes things happen
150:18
what makes things happen that's a good
150:20
question
150:21
work makes things happen i'm sorry
150:24
but around the house you need to work if
150:28
you want your clothes to be clean
150:31
well your mom has to work she washes
150:33
your clothes but you have to pick up the
150:35
clothes
150:36
off your floor put your clothes away
150:39
if you want things to happen in your
150:41
room you have to work
150:43
right and that's good it's good to work
150:46
because it helps you
150:48
get things done it makes things
150:51
happen okay then we have number 10
150:54
to be straight on your feet not like
150:57
this
150:58
right that's lean right if i do that
151:02
that's called to lean right i'm like
151:04
this right
151:05
some people like to lean against the
151:07
wall don't lean against the wall
151:09
especially not an elevator wall right
151:11
you should stand
151:13
up right stand stand stand
151:16
straight on your feet sometimes if
151:18
you're like this your teacher
151:19
or your mom might say stand up right
151:22
don't
151:23
don't lean okay stand
151:26
stand stood stood okay it's a regular
151:29
verb
151:30
one more time stand stood
151:33
stood okay good
151:36
number eleven whoa that's what is that
151:39
that looks like ice cream
151:40
no it's not ice cream okay kind of looks
151:43
like
151:43
ice cream a very bright ice cream maybe
151:46
orange flavor
151:47
but that's not ice cream that is a huge
151:49
ball of light and heat
151:51
it doesn't normally look like this in
151:53
fact don't look at it
151:54
because it's not good for your eyes but
151:57
if you had a special camera
151:59
maybe a telescope scientists can take
152:02
pictures of it
152:03
and it looks like this it's huge this is
152:06
so big we can't imagine how big this
152:09
thing is
152:10
what is it of course i'm talking about
152:13
the sun
152:15
the sun is a big ball of light and heat
152:19
huge ball of light and heat in the sky
152:22
and it's far away really far away so it
152:25
looks small to us
152:27
but it's really really big but even
152:29
though it's so
152:30
far away it's so big we can still feel
152:33
the light
152:34
and we can feel the heat from the sun
152:38
without the sun we couldn't live
152:41
okay so it's a very important thing to
152:43
us it's the sun
152:45
okay the next word uh wow
152:48
right this guy's really driving how is
152:51
he driving he's moving quickly
152:53
his wheels aren't even on the ground
152:55
that's how
152:56
fast he's going he's going so
152:59
fast his wheels are off the ground right
153:03
he just jumped
153:04
but you have to be moving fast to do
153:06
that don't drive fast it's dangerous
153:09
you don't drive anyway but don't drive
153:11
fast it's a little dangerous
153:13
okay but if you walk fast walk quickly
153:16
you can walk you can run
153:18
but be careful when you do so let's
153:20
begin with our first word
153:22
electricity is a type of energy isn't it
153:26
electricity is a type of energy but what
153:29
is the word
153:30
from the unit from our lesson that is
153:33
the same as
153:34
energy what is that word we can see that
153:37
that word is
153:39
power power now be careful when
153:42
pronouncing
153:44
p when you pronounce
153:48
p your lips are together
153:51
and you have power sound behind it
153:57
power okay so it's a powerful word isn't
154:00
it
154:01
power so power is the same as
154:05
energy power and energy are the same
154:08
thing okay so that's our first word
154:11
let's move on to the second word
154:12
okay let's look at our second word our
154:15
second
154:16
word is about this device here
154:19
we can see it's a device that turns
154:23
sunlight into electricity
154:27
so let's look at this here a device a
154:30
device
154:31
is a machine or a tool
154:34
that you use to do something in this
154:37
case
154:37
it's a device a machine that turns
154:40
turns turns changes
154:44
okay so when you say it turns a into
154:47
b it changes a into b
154:52
in this case it's turning sunlight
154:55
into electricity so this device
155:00
turns sunlight into electricity isn't
155:03
that great
155:04
imagine we have sunlight coming down
155:07
right
155:07
and it's being turned into electricity
155:11
so what are these things what are they
155:14
well if we look at our word list we can
155:16
see that they're
155:17
solar panel solar panels
155:21
many but one is solar panel
155:24
this is a little difficult of a word
155:26
right think about it this way
155:29
solar means from the sun
155:32
solar is associated with the sun solar
155:36
panel a panel is a flat
155:40
uh device here like this this is one
155:43
panel there are many
155:45
panels so solar panel
155:48
and remember the p pronunciation panel
155:52
panel lips together so we have solar
155:55
panel
155:55
you guys practice solar panel
155:59
okay good solar panel okay let's move on
156:02
this is one device of course to make
156:04
electricity
156:05
let's move on to our third word
156:09
our third word our clue is a building
156:12
well this is a strange looking building
156:15
right but it's a building
156:17
where electricity is made
156:20
a building where electricity is made
156:24
what kind of building can that be
156:27
remember
156:28
our word that we learned in the first
156:29
time it was power right
156:32
so we put these two words together power
156:35
and we have plant
156:37
plant now you may know plant
156:40
are we talking about a bush or a flower
156:42
no
156:43
another meaning of plant is like a
156:46
factory
156:47
where something is made especially
156:50
energy
156:51
energy plant or power plant
156:54
so here this building which looks very
156:56
strange
156:58
it's a very interesting looking building
157:00
is a
157:01
power plant we make electricity
157:05
at this building okay so this is a
157:07
building where
157:08
electricity is made this is a little
157:11
difficult of a word
157:12
let's practice power plant
157:15
remember we have two p's here power
157:20
plant power plant you guys try it
157:23
power plant okay good
157:26
let's move on then to our fourth word
157:30
here our clue is a giant fan
157:34
a giant fan these are huge aren't they
157:36
they're really
157:37
really big fans uh not in your house
157:41
right you don't have these in your house
157:43
to make you cool
157:45
these are outside it's interesting let's
157:47
look at this be careful
157:49
this is giant fan
157:52
we have the f sound be careful
157:55
between f and
157:59
oops f versus p
158:02
before we learn p p p
158:06
is the sound for that but be careful
158:08
with f
158:09
with f we put our teeth on our bottom
158:12
lip
158:13
like this
158:17
so we have fan
158:20
fan let the air flow through your teeth
158:24
fan okay so p there's no air going
158:28
through your lips are closed tight
158:30
and then you release it powerfully okay
158:34
so a giant fan what is a giant fan
158:38
this is also where we use uh we can get
158:42
electricity where does it come from we
158:44
can make electricity
158:46
with a turbine a turbine these are
158:50
turbines
158:51
also be careful here if we just said if
158:54
there's no e e
158:57
then it's turbine right but e ismian
159:00
turbine it makes the i
159:04
a longer sound turbine
159:07
let's practice turbine turbine
159:11
okay so these are turbines they
159:14
generate they make electricity they turn
159:18
wind energy into electricity
159:22
okay let's move on now
159:26
we've talked about where electricity
159:28
comes from how can we
159:30
get electricity that we've we found out
159:33
how we can make
159:34
electricity but how can we use
159:37
electricity
159:38
where can we get the electricity from
159:41
we can get electricity from this you can
159:44
see this
159:45
in your house right how many do you have
159:47
in your house
159:48
wait you can count them later let's
159:50
study okay
159:51
you can count how many you have in your
159:53
house later but
159:54
what is this what is this we can
159:56
describe it as
159:57
a spot a spot a place right
160:01
a spot where you can get
160:04
electricity so you want electricity
160:08
for your computer for your smartphone
160:11
where can you get it if your battery is
160:14
dead
160:15
you can get it from here this is an
160:18
outlet look this is like
160:22
two words out out going out
160:26
and let out let think of it this way
160:29
it lets the electricity out
160:33
of this place so you can get it and you
160:36
can use it
160:37
it's an outlet so this is where you can
160:40
get
160:41
your electricity okay so that's very
160:44
useful
160:45
let's move on now behind the
160:48
outlet right we have these things
160:51
okay we're talking about the metal part
160:53
here right this is a long
160:56
thin piece of metal
160:59
metal that's this part here
161:02
not this part this part is plastic but
161:05
inside the plastic
161:06
is metal what is this called
161:09
this is called a wire
161:13
wire again remember e opsamian
161:16
we're okay but e is a
161:20
wire stretch the i sound makes it long
161:23
wire so practice wire
161:26
okay wire why are we concerned about
161:30
wire electricity moves
161:33
through the wire goes to your outlet and
161:36
that's important
161:37
so there are wires inside your house
161:40
okay okay
161:44
some the wires are inside your house but
161:46
we also have
161:47
wires on the outside of your computer
161:50
this is a special word
161:51
for these kinds of wires this is a
161:55
short wire for moving electricity
161:58
electricity travels through a wire but
162:01
on your computer or on your battery pack
162:04
for your cell phone
162:06
you have small wires we have a special
162:09
word
162:09
for that what is that word that word is
162:13
chord chord a chord is a small wire
162:17
with two uh ends you put one end in the
162:20
outlet
162:21
the other end goes into your device into
162:24
your computer
162:26
or smartphone that short wire we call
162:29
a chord a chord okay let's move on
162:34
on number eight at the end of the chord
162:36
this is the chord here
162:38
this is the cord part here what is this
162:42
part
162:43
what is that this is the part
162:46
of a cord that goes into an outlet
162:50
right you have to connect your cord
162:53
to your outlet to get the electricity
162:56
out what do we call this part we call
163:00
this part
163:02
a plug plug let's practice that
163:06
we have a blend p and l pu
163:10
plug plug you guys
163:14
plug very good okay
163:17
plug so we use this plug we put it
163:21
into the outlet and then we can get our
163:24
electricity
163:25
okay great let's move on here what's
163:28
this boy doing
163:30
right he's very happy he is using
163:33
a device we use for many things
163:37
maybe right now you're watching me
163:41
on this device what is this device
163:44
of course you know this this is very
163:46
easy right
163:48
it is a computer computer
163:53
computer right computer of course you
163:55
know that
163:56
that's an easy one so this boy is using
163:58
a computer
163:59
we don't see the chord but of course
164:01
there's probably a chord
164:03
that the electricity is coming into and
164:06
these are
164:06
this is one example of many devices
164:10
we use with electricity we need
164:13
electricity
164:14
to use these devices so this is a
164:17
computer now let's take a look at
164:21
uh word number 10 okay sometimes we want
164:25
to
164:26
make electricity go from one place to
164:29
another
164:30
so what verb can we use to describe that
164:33
motion going from one place to another
164:36
to move something to move something
164:39
to somewhere else i'm in korea
164:43
i want to send a present to my friend in
164:46
america
164:48
i will do what with that present i will
164:50
go to the post office
164:52
and i will send the present to my friend
164:56
when we talk about electricity we need
164:58
to send electricity
165:00
from the power plant to the outlet
165:04
in your house okay so this is a verb
165:07
be careful some verbs in english are
165:11
uh not regular they change form
165:14
when you use them in different
165:16
situations for example
165:18
send that's now chigum i i
165:22
i am sending i will send also future
165:25
scent is passed quago right sent
165:29
and sent so i sent my present
165:32
i sent a present to my friend in america
165:36
that's quago okay past tense okay send
165:40
sent sent practice that you guys
165:43
send sent sent
165:46
okay very good okay let's move on then
165:50
wow look at these birds where are they
165:51
going right um
165:53
they are going of course it must be uh
165:56
getting cold and they're going south
165:58
right well what are they doing
166:00
they are moving from one place to
166:03
another
166:04
so if you move from one place to another
166:07
what are you doing it's a verb
166:10
travel travel so i want to go
166:14
to america i will travel to
166:17
america travel to
166:20
somewhere move from one place to
166:24
another place i will travel to
166:28
america i will travel to another country
166:32
so these birds are traveling south
166:35
okay let's take a look at the next one
166:37
our last word here
166:39
is kind of a a scary word right
166:43
that's be careful of this right be
166:46
careful of this sign
166:47
if you see that sign on a bottle stay
166:49
away from that bottle right this
166:52
what what can we say this about this
166:54
it's causing death
166:56
death somebody dies right it's very
166:59
dangerous
167:00
what word are we looking at here we are
167:02
looking at
167:03
deadly deadly is a description word
167:07
right adjective it describes something
167:11
we can look at this and say oh be
167:12
careful it's
167:14
deadly it can cause death why are we
167:17
looking at this word deadly
167:19
in our topic about electricity because
167:22
you have to be careful
167:24
electricity can be deadly it can be very
167:28
dangerous
167:29
so although electricity is very useful
167:32
we use it for many things you also have
167:35
to be
167:35
careful electricity can also be
167:38
dangerous
167:39
it can be deadly
