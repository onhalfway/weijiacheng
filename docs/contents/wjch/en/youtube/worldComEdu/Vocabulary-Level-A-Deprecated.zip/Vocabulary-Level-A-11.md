# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
the first word that we're going to go
over here is to become something else
this is a nice picture right
it's the picture of the same thing it's
changing its changing from this little
piece here you can see the butterfly is
coming out so the caterpillar used to be
here but the caterpillar changes becomes
something else what does it do it turns
into it turns into a butterfly to turn
into means to change from one thing to
another
the caterpillar caterpillar you know the
caterpillar the little green insect that
crawls around looks like a worm
the caterpillar turns into a butterfly a
beautiful butterfly and that's what
turned into means to change okay next
word number two these are very pretty
rocks aren't they very nice-looking
rocks what are they they are a special
type of rocks an important part of rocks
they are minerals now these are large
you know they're kind of big right
but when plants grow in dirt right the
plants take the minerals up from the
dirt and the minerals are in the plants
when we eat the plants we eat some
minerals very small very small pieces of
minerals but they're good for our bodies
we need those things we need minerals
and we need vitamins so minerals are an
important part of rocks they're also
good for us but don't eat these you'll
break your teeth right just eat the
plants you can't see the minerals in the
plants but they're good for you
okay next word oh it's too bad it's sad
here's a fish the fish is out of water
the fish can
live out of water so it's not alive
what's another word that means not alive
the word of course is dead dead the fish
is dead so something that is not alive
is dead okay the next word number four
here we have a picture of a lot of dirt
but there's also some plants here right
and we have this definition to break
down to break down if you imagine that
this is a lot of plants or maybe we
could put some old fruit like some old
apples or some old oranges on top of
there and after a while it begins to
smell right because what is it doing it
is rotting to rot this is a verb to rot
means to break down and usually things
get no they get smelly right and they
break down over time and they go back
into the dirt they go back into the soil
to rot to break down okay the next word
look at these guys they're having fun
right they were hiking all day now they
are at the highest position in the
mountains where are they they are on the
top on the top on the top right they are
on the top of the mountain so top is the
highest in position it's the top thing
the thing that is on top right to be on
the top top okay number six the gas that
we breathe right if you breathe you can
feel the wind right the wind is gasps
what is that gasps that's all around us
we breathe it we need it so that we
don't die so that so that we stay alive
what is it it's called air air air is
all around us right it's the gas that we
breathe remember we can't really see the
gas the gas is very light
can move around in it right but we
breathe it that's the gas that we're
breathing
that's called air okay next word number
seven to keep in place okay this is an
interesting picture somebody has a
strong grip on their money right Tony
okay
because it's very important but what are
they doing if you have like beg one or
Oh big one in your hand you don't want
to lose it you put in your hand you
close your fingers around it what are
you doing
what is that verb hold you are holding
your money also when you go on the
street and you're walking on a busy
street hold your mother's hand hold your
father's hand because you don't want to
get on the street it could be dangerous
hold your brother's hand or your sisters
hand to take care of them okay so you
hold now this is an irregular verb it
changes so we say hold held held right
hold it's a present tense held past
tense and held PP right hold held held
okay good
next word I kind of talked about this
before a little bit when I talked about
air
I said air is all around us in all
places another word we could use
everywhere it's a big word right
everywhere that's a really big word if
you look at the sand right there is sand
sand is a type of dirt by the way but
sand is not good dirt things don't grow
well in sand but in the desert sand is
everywhere right right now air is
everywhere right okay so everywhere in
all places everywhere around us okay
next word number nine at a lower place
so here we see a man he's sitting by a
tree the tree is very tall right the
branches and the leaves are on top there
they're on top where is he he is
though he's below the branches and the
leaves he is below
so what could say here is a pen right
here is my hand the pen is below my hand
okay so below at a lower place number 10
yeah kind of slimy right
I said slimy slimy is uh you know it's a
little wet and it's a little soft right
that's slimy do you want to pick up that
worm I'm sure the girls in the audience
they don't want to pick up that worm the
boys are like yeah let's pick up the
worm right okay but it's a little slimy
right and we can see this worm in the
dirt which is very wet it's also slimy
but when we see a mix of rotting stuff
and soil so imagine that there's like
old fruit on the top right it's just
kind of rotting and and breaking down
and it's a mix of that stuff and soil
there's a special word we use for it
it's a little hard to pronounce but look
at this word it's houmous hue hue muss -
sounds - sounds hue muss houmous so we
say houmous that is the mix of rotting
stuff and soil good for growing plants
okay now here we have an interesting
picture we have many green apples
they're a little sour right green apples
are a little sour and then we have one
red apple it's a little more sweet right
when we say not the same there's many
words that mean not the same we're gonna
look at one word here is other right
these are the all the green apples I the
other Apple is red
I have many green apples but the other
Apple is red so something that is not
the same as other as as the what you
have that is the other right when you're
saying something is different not the
same the other okay
having a special use something that has
a special use what do we call that we
can say it's important right here we
have a picture of a little girl and
she's getting ready for bed maybe she's
praying and she has a little teddy bear
with her right the teddy bear is very
important to the girl what is important
in your life do you have a toy that is
your favorite toy it's very important to
you maybe you have a book that you like
to read that book is important but also
think about your family your family
members are very important your mom is
important
your dad is important your brothers and
sisters I know sometimes we fight but
they're important to you too these are
things that have not just a special use
but a special value to you
they are importance okay

## toggle timestamps Transcript

[Music]
the first word that we're going to go
over here is to become something else
this is a nice picture right
it's the picture of the same thing it's
changing its changing from this little
piece here you can see the butterfly is
coming out so the caterpillar used to be
here but the caterpillar changes becomes
something else what does it do it turns
into it turns into a butterfly to turn
into means to change from one thing to
another
the caterpillar caterpillar you know the
caterpillar the little green insect that
crawls around looks like a worm
the caterpillar turns into a butterfly a
beautiful butterfly and that's what
turned into means to change okay next
word number two these are very pretty
rocks aren't they very nice-looking
rocks what are they they are a special
type of rocks an important part of rocks
they are minerals now these are large
you know they're kind of big right
but when plants grow in dirt right the
plants take the minerals up from the
dirt and the minerals are in the plants
when we eat the plants we eat some
minerals very small very small pieces of
minerals but they're good for our bodies
we need those things we need minerals
and we need vitamins so minerals are an
important part of rocks they're also
good for us but don't eat these you'll
break your teeth right just eat the
plants you can't see the minerals in the
plants but they're good for you
okay next word oh it's too bad it's sad
here's a fish the fish is out of water
the fish can
live out of water so it's not alive
what's another word that means not alive
the word of course is dead dead the fish
is dead so something that is not alive
is dead okay the next word number four
here we have a picture of a lot of dirt
but there's also some plants here right
and we have this definition to break
down to break down if you imagine that
this is a lot of plants or maybe we
could put some old fruit like some old
apples or some old oranges on top of
there and after a while it begins to
smell right because what is it doing it
is rotting to rot this is a verb to rot
means to break down and usually things
get no they get smelly right and they
break down over time and they go back
into the dirt they go back into the soil
to rot to break down okay the next word
look at these guys they're having fun
right they were hiking all day now they
are at the highest position in the
mountains where are they they are on the
top on the top on the top right they are
on the top of the mountain so top is the
highest in position it's the top thing
the thing that is on top right to be on
the top top okay number six the gas that
we breathe right if you breathe you can
feel the wind right the wind is gasps
what is that gasps that's all around us
we breathe it we need it so that we
don't die so that so that we stay alive
what is it it's called air air air is
all around us right it's the gas that we
breathe remember we can't really see the
gas the gas is very light
can move around in it right but we
breathe it that's the gas that we're
breathing
that's called air okay next word number
seven to keep in place okay this is an
interesting picture somebody has a
strong grip on their money right Tony
okay
because it's very important but what are
they doing if you have like beg one or
Oh big one in your hand you don't want
to lose it you put in your hand you
close your fingers around it what are
you doing
what is that verb hold you are holding
your money also when you go on the
street and you're walking on a busy
street hold your mother's hand hold your
father's hand because you don't want to
get on the street it could be dangerous
hold your brother's hand or your sisters
hand to take care of them okay so you
hold now this is an irregular verb it
changes so we say hold held held right
hold it's a present tense held past
tense and held PP right hold held held
okay good
next word I kind of talked about this
before a little bit when I talked about
air
I said air is all around us in all
places another word we could use
everywhere it's a big word right
everywhere that's a really big word if
you look at the sand right there is sand
sand is a type of dirt by the way but
sand is not good dirt things don't grow
well in sand but in the desert sand is
everywhere right right now air is
everywhere right okay so everywhere in
all places everywhere around us okay
next word number nine at a lower place
so here we see a man he's sitting by a
tree the tree is very tall right the
branches and the leaves are on top there
they're on top where is he he is
though he's below the branches and the
leaves he is below
so what could say here is a pen right
here is my hand the pen is below my hand
okay so below at a lower place number 10
yeah kind of slimy right
I said slimy slimy is uh you know it's a
little wet and it's a little soft right
that's slimy do you want to pick up that
worm I'm sure the girls in the audience
they don't want to pick up that worm the
boys are like yeah let's pick up the
worm right okay but it's a little slimy
right and we can see this worm in the
dirt which is very wet it's also slimy
but when we see a mix of rotting stuff
and soil so imagine that there's like
old fruit on the top right it's just
kind of rotting and and breaking down
and it's a mix of that stuff and soil
there's a special word we use for it
it's a little hard to pronounce but look
at this word it's houmous hue hue muss -
sounds - sounds hue muss houmous so we
say houmous that is the mix of rotting
stuff and soil good for growing plants
okay now here we have an interesting
picture we have many green apples
they're a little sour right green apples
are a little sour and then we have one
red apple it's a little more sweet right
when we say not the same there's many
words that mean not the same we're gonna
look at one word here is other right
these are the all the green apples I the
other Apple is red
I have many green apples but the other
Apple is red so something that is not
the same as other as as the what you
have that is the other right when you're
saying something is different not the
same the other okay
having a special use something that has
a special use what do we call that we
can say it's important right here we
have a picture of a little girl and
she's getting ready for bed maybe she's
praying and she has a little teddy bear
with her right the teddy bear is very
important to the girl what is important
in your life do you have a toy that is
your favorite toy it's very important to
you maybe you have a book that you like
to read that book is important but also
think about your family your family
members are very important your mom is
important
your dad is important your brothers and
sisters I know sometimes we fight but
they're important to you too these are
things that have not just a special use
but a special value to you
they are importance okay