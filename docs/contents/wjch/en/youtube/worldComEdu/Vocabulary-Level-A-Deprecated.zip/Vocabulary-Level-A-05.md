# Transcript

- [Transcript](#transcript)
  - [un-toggle timestamps Transcript](#un-toggle-timestamps-transcript)
  - [toggle timestamps Transcript](#toggle-timestamps-transcript)

## un-toggle timestamps Transcript

[Music]
our first word is this object here
it's a strange object I've never seen
that before right
what is that things that help you see
things that help you see what is oh wait
a minute I've got them on my head right
what are these things okay what do you
call them they're glasses glasses note
that we use plural did we say it's like
plural it's one thing yes it's one thing
but we use it as plural because there
are two lenses we say glasses glasses
okay so these are glasses okay
their next word now this is something to
do with the one of the senses we talked
about when you use your tongue right
when you taste something the taste of
candy or in this case ice cream ice
cream candy cake things that have sugar
what does it taste like it tastes sweet
mmm that's good
sugar things that have sugar in them
taste sweet
mmm that's very good right like ice
cream candy we really like those things
right don't eat too much
I know it's sweet it tastes good but
don't eat too much cuz it's bad for your
teeth anyway these things taste sweet
what is the opposite of sweet Panda no
well that would be all look at this poor
boy you lose right what is he doing he's
eating a lemon the taste of lemons did
you ever take a lemon and lick it
oh right what it what do we say it is
very not sweet pandered oh it's sour
Oh sour right sour is the taste of
lemons it's the opposite of sweet okay
okay now here we have another word this
has to do with this object here it's
something that grows on a bird's wing it
grows on a bird's wing so bird can
I write but the bird has to have many of
these things on its wing also all over
its body not just its wing it looks like
this it's very soft if you take a if you
take this and you brush it against your
cheek right you can use your cheek to
feel or to touch something oh it's very
soft what is it it of course is a
feather feather be careful with the F
thumb feather and th the the feather so
we say feather it's a feather it grows
on a bird's wing and it's very soft if
we touch it very nice now we have this
here now this is an interesting picture
this boy is between his father and his
mother right and his mother and his
father are holding his hand how does
this boy feel he's out of harm's way
harm is like danger right
Jochem hey oh right harm is something
that can hurt you so be careful you want
to stay away from harm you want to stay
away from danger if you are out of the
way of danger or you're away from harm
what are you then you are safe I'm safe
right nothing is going to harm him he's
happy he is safe between his parents so
he is safe okay before we talked about
feather right we said a feather is very
soft well here we have an object here
and the word that we have to define it
is stone so basically we're looking for
another word that means the same as
stone stone is very hard right what is
another word that we can use to talk
about this of course it's very simple
it's rock rock R or a rock okay so it's
a rock a rock is very hard don't throw
rocks cuz if the rock hit you oh it
hurts your head because it's very hard
and it's
the right so be careful with rocks do
not throw rocks okay at other people
right you can throw rocks in the water
okay but don't throw rocks at other
people that's very dangerous
okay rocks are hard okay our next word
is this right here what is that right we
have two of them right I have two of
them behind in my glasses all right you
see things with this with this we're
only talking about one now you see
things with this what is it
it is an eye and of course we have two
so we have eyes everybody has two eyes
but if you want to talk about one you
just say I can see with one eye right or
cover one eye so I is singular eyes
plural we all have two eyes everybody
has two eyes and what do we use our eyes
for we see things that's one of our five
senses we talked about before another
one of the five senses we talked about
before is to hear and do you remember
what I said we use to hear with of
course we have two but we're talking
about just one here what is this do you
remember it's called an ear ear so we
have one ear two ears again we just say
two ears one year two years two ears
okay so of course you're listening to me
right now you're hearing me with your
ears and you're watching me with your
eyes okay so those are two of the senses
we talked about okay oh look at poor
doggy yes look so so sad right so so
pitiful right he's covered with water if
he is covered with water or you go
outside in the rain it rains a lot you
don't have an umbrella all the water
falls on you
you're covered with water like the poor
doggy here what do you say the doggy is
wet the dog is wet and we can feel right
if we're wet with our skin that's one of
our senses we can with our touch with
our skin we can feel oh we're very wet
let's dry off right so we're wet this is
wet covered with water okay don't do
this this is not good for her ears right
what's going on she's making a big noise
to make a big noise what do we call that
we say it's loud it's very loud making a
big noise if something makes a big noise
we say it's loud right this woman is
very loud and this poor woman is going
to hurt her
ear right so be careful don't do this
it's just a picture but it's showing
loud something is very loud makes a big
noise okay okay here we have to have a
particular flavour so this woman she
looks like a cook right she is a cook
and she is making looks like soup and
she wants to find the flavor she wants
to know what is the flavor of the soup
so what is what is she doing she is
tasting this is one of these senses we
talked about before to taste she's using
her tongue alright she's using her
tongue to taste the soup because it's
your tongue not your mouth but your
tongue that we use to taste food what
does it taste like what does it taste
like that is to have a particular flavor
it tastes now we can taste something but
an object can also have a taste right
the strawberries taste sweet and that
has a particular flavor lemons taste
sour so we can use taste in two ways we
people can taste something but objects
can have a taste what do they taste like
what do they taste like
okay then we have to look at something
to look at something Wow he's using
these are by the way these are by na q
lers that's a big word binocular some
binoculars binoculars are really big
they're like glasses right but they're
really strong they let you see things
wow it comes really close whoa
right you look at some ho it's really
close and it was a lot bigger so you can
really see things that are far away with
binoculars what is he doing he's looking
at something another word another word
for look is see I can see that's one of
our five senses now down here we have
the verb the verb changes in form
whether we use it present tense past
tense or present participle P P right so
what are the different forms we have C
saw seen C saw seen I see you I saw him
this morning I have seen that movie C
saw seen okay okay so that's C to look
at something

## toggle timestamps Transcript

00:00
[Music]
00:05
our first word is this object here
00:09
it's a strange object I've never seen
00:12
that before right
00:13
what is that things that help you see
00:16
things that help you see what is oh wait
00:19
a minute I've got them on my head right
00:21
what are these things okay what do you
00:24
call them they're glasses glasses note
00:28
that we use plural did we say it's like
00:31
plural it's one thing yes it's one thing
00:34
but we use it as plural because there
00:37
are two lenses we say glasses glasses
00:41
okay so these are glasses okay
00:45
their next word now this is something to
00:48
do with the one of the senses we talked
00:51
about when you use your tongue right
00:53
when you taste something the taste of
00:57
candy or in this case ice cream ice
01:00
cream candy cake things that have sugar
01:05
what does it taste like it tastes sweet
01:10
mmm that's good
01:12
sugar things that have sugar in them
01:14
taste sweet
01:16
mmm that's very good right like ice
01:18
cream candy we really like those things
01:21
right don't eat too much
01:23
I know it's sweet it tastes good but
01:25
don't eat too much cuz it's bad for your
01:28
teeth anyway these things taste sweet
01:30
what is the opposite of sweet Panda no
01:34
well that would be all look at this poor
01:36
boy you lose right what is he doing he's
01:39
eating a lemon the taste of lemons did
01:42
you ever take a lemon and lick it
01:44
oh right what it what do we say it is
01:47
very not sweet pandered oh it's sour
01:51
Oh sour right sour is the taste of
01:55
lemons it's the opposite of sweet okay
02:00
okay now here we have another word this
02:03
has to do with this object here it's
02:06
something that grows on a bird's wing it
02:11
grows on a bird's wing so bird can
02:13
I write but the bird has to have many of
02:16
these things on its wing also all over
02:19
its body not just its wing it looks like
02:22
this it's very soft if you take a if you
02:25
take this and you brush it against your
02:27
cheek right you can use your cheek to
02:30
feel or to touch something oh it's very
02:33
soft what is it it of course is a
02:36
feather feather be careful with the F
02:40
thumb feather and th the the feather so
02:47
we say feather it's a feather it grows
02:50
on a bird's wing and it's very soft if
02:54
we touch it very nice now we have this
02:58
here now this is an interesting picture
03:00
this boy is between his father and his
03:03
mother right and his mother and his
03:05
father are holding his hand how does
03:07
this boy feel he's out of harm's way
03:11
harm is like danger right
03:14
Jochem hey oh right harm is something
03:17
that can hurt you so be careful you want
03:20
to stay away from harm you want to stay
03:23
away from danger if you are out of the
03:27
way of danger or you're away from harm
03:30
what are you then you are safe I'm safe
03:34
right nothing is going to harm him he's
03:37
happy he is safe between his parents so
03:41
he is safe okay before we talked about
03:45
feather right we said a feather is very
03:47
soft well here we have an object here
03:50
and the word that we have to define it
03:54
is stone so basically we're looking for
03:56
another word that means the same as
04:00
stone stone is very hard right what is
04:04
another word that we can use to talk
04:07
about this of course it's very simple
04:09
it's rock rock R or a rock okay so it's
04:16
a rock a rock is very hard don't throw
04:20
rocks cuz if the rock hit you oh it
04:24
hurts your head because it's very hard
04:26
and it's
04:27
the right so be careful with rocks do
04:30
not throw rocks okay at other people
04:34
right you can throw rocks in the water
04:36
okay but don't throw rocks at other
04:39
people that's very dangerous
04:41
okay rocks are hard okay our next word
04:46
is this right here what is that right we
04:49
have two of them right I have two of
04:51
them behind in my glasses all right you
04:54
see things with this with this we're
04:58
only talking about one now you see
05:00
things with this what is it
05:02
it is an eye and of course we have two
05:06
so we have eyes everybody has two eyes
05:11
but if you want to talk about one you
05:14
just say I can see with one eye right or
05:18
cover one eye so I is singular eyes
05:23
plural we all have two eyes everybody
05:27
has two eyes and what do we use our eyes
05:30
for we see things that's one of our five
05:33
senses we talked about before another
05:37
one of the five senses we talked about
05:40
before is to hear and do you remember
05:43
what I said we use to hear with of
05:46
course we have two but we're talking
05:49
about just one here what is this do you
05:52
remember it's called an ear ear so we
05:56
have one ear two ears again we just say
06:01
two ears one year two years two ears
06:07
okay so of course you're listening to me
06:10
right now you're hearing me with your
06:13
ears and you're watching me with your
06:16
eyes okay so those are two of the senses
06:18
we talked about okay oh look at poor
06:22
doggy yes look so so sad right so so
06:27
pitiful right he's covered with water if
06:31
he is covered with water or you go
06:34
outside in the rain it rains a lot you
06:37
don't have an umbrella all the water
06:39
falls on you
06:40
you're covered with water like the poor
06:43
doggy here what do you say the doggy is
06:46
wet the dog is wet and we can feel right
06:51
if we're wet with our skin that's one of
06:53
our senses we can with our touch with
06:56
our skin we can feel oh we're very wet
06:59
let's dry off right so we're wet this is
07:02
wet covered with water okay don't do
07:07
this this is not good for her ears right
07:10
what's going on she's making a big noise
07:13
to make a big noise what do we call that
07:17
we say it's loud it's very loud making a
07:21
big noise if something makes a big noise
07:24
we say it's loud right this woman is
07:28
very loud and this poor woman is going
07:32
to hurt her
07:33
ear right so be careful don't do this
07:36
it's just a picture but it's showing
07:38
loud something is very loud makes a big
07:41
noise okay okay here we have to have a
07:47
particular flavour so this woman she
07:50
looks like a cook right she is a cook
07:53
and she is making looks like soup and
07:56
she wants to find the flavor she wants
08:00
to know what is the flavor of the soup
08:04
so what is what is she doing she is
08:07
tasting this is one of these senses we
08:10
talked about before to taste she's using
08:13
her tongue alright she's using her
08:16
tongue to taste the soup because it's
08:19
your tongue not your mouth but your
08:21
tongue that we use to taste food what
08:25
does it taste like what does it taste
08:29
like that is to have a particular flavor
08:33
it tastes now we can taste something but
08:37
an object can also have a taste right
08:40
the strawberries taste sweet and that
08:44
has a particular flavor lemons taste
08:48
sour so we can use taste in two ways we
08:53
people can taste something but objects
08:56
can have a taste what do they taste like
09:00
what do they taste like
09:03
okay then we have to look at something
09:07
to look at something Wow he's using
09:09
these are by the way these are by na q
09:13
lers that's a big word binocular some
09:17
binoculars binoculars are really big
09:20
they're like glasses right but they're
09:22
really strong they let you see things
09:24
wow it comes really close whoa
09:27
right you look at some ho it's really
09:29
close and it was a lot bigger so you can
09:31
really see things that are far away with
09:34
binoculars what is he doing he's looking
09:37
at something another word another word
09:39
for look is see I can see that's one of
09:45
our five senses now down here we have
09:48
the verb the verb changes in form
09:52
whether we use it present tense past
09:54
tense or present participle P P right so
09:58
what are the different forms we have C
10:01
saw seen C saw seen I see you I saw him
10:10
this morning I have seen that movie C
10:15
saw seen okay okay so that's C to look
10:19
at something