# Transcript

- [Transcript](#transcript)
  - [un-toggle timestaps](#un-toggle-timestaps)
  - [toggle timestamps](#toggle-timestamps)

💓 Lesson 1 We Eat Flowers!
Do you like to eat plants?
The plant parts we eat are vegetables .
Plants have many different parts.
We use all these parts for food.

Do you like to eat carrots?
Carrots are vegetables.
They come from carrot plants.
The part we eat is the root .
Roots grow down in the dirt.

Many people like to eat potatoes.
They are a very tasty vegetable.
Potatoes are stems that we eat.
Stems help hold a plant up.

We eat the of some plants.
Leaves are flat and green.
Do you like to eat lettuce?
Lettuce is the leaf of a lettuce plant.
Peas are vegetables, too.
They are the of the pea plant.
We do not eat all of the pea plant.
We eat the seeds.

Seeds grow into plants.
Do you like to look at flowers?
All flowers make seeds.
Flowers are pretty and smell nice.
Some flowers taste good too!
The top parts of broccoli are flowers.
That means we eat flowers!

## un-toggle timestaps

[Music]
okay let's start with our first word the
first word we don't see it but we have
the definition here and we have a
picture over here let's see the
definition let's take a look at the
definition the definition is the part
the part there are many parts of a plant
but we're looking at maybe one part or a
few different parts right I am a person
I have many parts right just like a
plant has many parts so we're looking at
the part of a plant that we eat we eat
the part of the plant so sometimes we
have this part of the plant over here we
eat that sometimes it's this part of the
plant or sometimes this part of a plant
there are different parts of a plant we
eat them what do we call that we call
those vegetable vegetable if you look at
the word it looks like vegetable but no
we say vegetable everybody vegetable so
it sounds like you don't say II
vegetable vegetable don't say vegetable
money Oh vegetable is very common
vegetable but there's an interesting
point when I see vegetable
I think fruit so there's a question what
is the difference between vegetable and
fruits ego hago ego hago autocut orany
right how are they different it's very
simple
think about this fruit has seeds if
there are seeds in it it's a fruit
vegetable no seeds
a vegetable does not have seeds no seeds
so a fruit is a part of the plant yes
but it's only one part of the plant it's
the part that has seeds if it has seeds
it's a fruit so an apple cut open an
apple there are seeds an apple is a
fruit watermelon must die
right you cut the watermelon watermelon
soo bahk right watermelon you cut the
watermelon wha
many many many seeds watermelon is a
fruit vegetable a carrot dong-gun tongan
right you cut the carrot where's the
seeds there's no seeds carrot is a
vegetable okay so that's how you know
the difference between vegetable and
fruit but mostly in this lesson we will
talk about vegetables okay the parts of
the plant that we eat many parts don't
have seeds so mostly we will talk about
vegetables okay okay let's go to the
next word the next word is the part
remember there's many parts of a plant
we're looking at one part the part of a
plant that makes seeds it's the part of
the plant that makes the seeds before
the fruit right it's the part of the
plant that makes the seeds before it
becomes a fruit what part is it look at
the picture there are many pretty-pretty
what we have yellow we have purple what
are they of course we say they are
flowers flower be careful this is a
little hinder Oh a little difficult to
pronounce F and L right F and L very
difficult combination F and L
love love put them together
flower flower that's not so hard
our flower it's the part of the plant
that makes seeds the flowers make seeds
okay let's move on to our next word the
next word we can see Wow looks really
bright here right very green this is the
flat green part of a plant and there are
many right a plant has many of these
what do we call this one one of them
what do we call it we call it a leaf
leaf here we have L and F at the end
right now they're apart but L remember L
la la la la la put your tongue behind
your teeth on the top la leaf and then
for F leaf leaf that's only one one leaf
but a plant has many so how do we make
it plural we say many leaves many leaves
leaves leaves okay so if it's one just
one we say it's a leaf but of course a
plant has many you look at a plant you
see many leaves on a plant the flat
green part of a plant usually green
sometimes they're yellow sometimes
they're orange right depends but usually
they're green the green parts of a plant
okay now we're on the next part of the
plant and this part we can't see it
right we can't see that part of the
plant because it's underground
underground let me write that for you
under ground right this is the ground
this is the ground it's under under the
ground
under ground it's Underground the part
of a plant that grows it grows down in
the dirt it's in the dirt
in the dirt it's underground so what
part of this plant is it what do we say
what's the word there we say that part
of the plant is called the root root
right strong word of course the roots
are strong because they have to be
strong because they hold the plant in
the ground right these roots we can't
see them unless we pull the plant out
right we pull the plant out of the
ground
then we can see the roots we can see the
roots right but one root many roots okay
so root root right strong word root okay
what's our next word okay our next word
we're talking about a different part of
the plant this is this part right here
actually it's this whole piece right
here right that whole thing we're
talking about that part of the plant now
now it's the part of a plant that holds
the plant up it holds the plant up right
it supports the rest of the plant it's
kind of like my body right my trunk of
my body holds my body up right but this
part we don't usually say trunk for a
small plant we can say what stem stem
yes we can say trunk for a tree but this
is a small plant we say stem stem many
plants all plants have a stem the stem
is like the body of a plant right it's
like the body of a plant it's their body
right some bodies are thin some bodies
are thick right so these are the stems
of the plant right some of them are are
thick and big some of them are very thin
and not so strong but they are called
stems stem the stem of a plant the part
that holds the plant up okay
the next one is the part of a plant that
grows into a new plant we talked about
this part before we've mentioned it
several times already we're looking at
this very small piece of the plant that
piece that part will fly away on the
wind it'll fall in the ground and a new
plant will grow okay
so that's just one type of plant of
course there are many types of these
sometimes people eat them right and they
throw them away in different places and
a new plant will grow what are we
talking about we're talking about the
seed the seed the seed of a plant
remember when we talked about fruits and
vegetables where is the seed the seed is
in the fruit but not all plants have
fruit some plants there's no fruit like
this plant here there's no fruit because
the seeds break off and fly away on the
wind but many plants grow fruit the
seeds are in them because animals eat
the fruit and they eat the seeds too and
they walk away and they go they go they
go to the bathroom somewhere else but
the seeds are in that and the seeds will
grow in a different location and those
are seeds okay so plants have many ways
to spread their seeds okay now we've
come here to this type of plant we're
talking about a type of plant a long
orange vegetable so it's a vegetable you
can see it right here you know what that
is right we can only see part of it but
we know what the rest of it is the rest
of it is underground right what if we
call that this of course is called the
carrot right before I said tongan right
tongan one of the first words I learned
in Korean because carrots are very
common they're good for you carrots are
very good for your eyes
you eat many carrots you have good
eyesight I don't know what happened with
me I think I read too much but if you
eat many carrots you have good eyesight
ok but carrots are long orange vegetable
they're very good for you ok
now here we have an action it's not a
noun we're looking for a verb an action
to put food into your mouth and chew and
swallow
swallow it so you chew it and you
swallow it actually you do three things
right first you put it in your mouth
that's first second you chew it and
third you swallow it
right make sure you chew before you
swallow don't just put and go chew don't
be so fast take your time chew your food
well but there's three actions right to
put food in your mouth chew it and then
swallow it what are we talking about of
course we're talking about to eat eat
okay so when we eat that's what we're
doing we're actually doing three things
put food in your mouth chew it and then
swallow of course we can also talk about
the different times right present tense
past tense right and past participle
okay so when we talk about present tense
eat eat that's what we're doing now what
will we do now let's eat let's go eat
okay and that's also a little bit of
future right let's eat I want to eat now
you're talking about the present time or
just a little bit in the future
what about ate eat ate I ate breakfast
did you eat breakfast yes I ate
breakfast I hope you ate breakfast right
but you're talking about eatin a long
time ago right
I have eaten or I've done something
before right I have eaten breakfast I
have eaten
have you ever eaten eggs for breakfast
right so if you're talking about if you
ever did something in your life you have
done it you have eaten eggs okay
so eat ate eaten one more time eat ate
eaten those are the different verb forms
of this verb to eat by the way you
should eat breakfast every day right
always eat breakfast I ate breakfast
today I hope you ate breakfast today
okay our next word is another type of
vegetable another type of vegetable we
saw carrot before that's one type of
vegetable but now we have another type
of vegetable and this is the picture you
know this one right this is very common
round white there white maybe a little
yellow but usually white vegetables that
grow in the dirt they grow underground
just like the carrot right what do we
call these vegetables we call them
potato potato
right you know of course come John right
come John potato is very very common and
of course we know potatoes as potato
chips right potato chips are very common
- made from potatoes and I just gave you
of course when you talk about plural say
potatoes potatoes with the e we add es
at the end it is potatoes potatoes so
potatoes of course are very common you
probably eat them maybe every day if not
every day then probably many times a
week right I'm sure you eat potatoes
very often ok ok let's move on now this
is also very common especially with
Korean dishes right I really like
bulgogi right and I like when I eat
bulgogi I use this to put the bulgogi in
what do we call that
a plant with large green leaves it has
many large green leaves okay what do we
call it in English we say it's lettuce
lettuce now lettuce is very similar to
another vegetable we call cabbage the
cabbage is very similar but lettuce is
not so heavy lettuce is lighter it's
thinner and it tastes a little bit
better lettuce is a different kind but
cabbage and they're very close they're
like brothers right they're like sisters
they're very close well lettuce or
cabbage lettuce of course is very common
we use it in salads of course in many
Korean dishes you can use it to eat with
meat I like to put the meat the rice the
garlic the onion and the dwenjang I hate
mana hot oil machi soil right but we use
the lettuce in many different ways okay
we say lettuce lettuce it almost sounds
like let us go but it doesn't mean that
right it's lettuce lettuce and that is a
plant with large green leaves okay here
we have another type of plant that we
eat right we eat these things right here
these actually are seeds right but
there's in this case they're soft and
they're good for you the seed of a pea
plant that we eat the seed of a pea
plant that we eat remember pea plants
right that's very easy because we say P
right it's a pea peas eat your peas peas
are very good for you now usually we
don't eat the seeds of a plant like
apple seeds come yeah they're very hard
right look they don't taste good but we
can eat peas the seeds of a pea plant we
eat those very often so sometimes we can
eat seeds but sometimes we don't eat the
seeds right but in the case of peas we
eat the seeds okay it's part of the
plant that we eat
okay our next word is a verb to have an
odor that's a verb right a verb when we
see to do something we're talking about
a verb to have an odor an odor that
means I can sense it with my nose right
there are good odors mmm that's nice and
there are bad odors whoa mmm saying that
pile right bad odors so to have an odor
what is the word what is going on here
we say that this is smell smell to have
an odor is to smell there's two ways you
can use this verb one way is this the
flower smells so in this case the flower
smells that's a good odor but sometimes
there's a bad odor for example my whoops
where my socks smell whoops
smell my sock what is a sock you say
young MA
right so sock is like this well it
smells right don't smell that snow whoo
it smells my socks smell that's one way
another way you can use this is I smell
I smell I smell what my sock No yuck
that's horrible right I smell a flower
that's much better
I smell a flower ah much better
right don't smell your socks whoo right
that's that's terrible
right so my socks smell it has an odor
it gives an odor some good odors and
some bad odors right my socks smell or I
smell a flower so there's two ways you
can use this verb some things smell or
people
animals smell something so there's two
ways the flower smells the boy smells
the flower two ways right
okay so smell very interesting verb

## toggle timestamps

00:00
[Music]
00:06
okay let's start with our first word the
00:10
first word we don't see it but we have
00:13
the definition here and we have a
00:16
picture over here let's see the
00:19
definition let's take a look at the
00:21
definition the definition is the part
00:25
the part there are many parts of a plant
00:30
but we're looking at maybe one part or a
00:33
few different parts right I am a person
00:37
I have many parts right just like a
00:40
plant has many parts so we're looking at
00:43
the part of a plant that we eat we eat
00:49
the part of the plant so sometimes we
00:52
have this part of the plant over here we
00:55
eat that sometimes it's this part of the
00:58
plant or sometimes this part of a plant
01:01
there are different parts of a plant we
01:04
eat them what do we call that we call
01:07
those vegetable vegetable if you look at
01:13
the word it looks like vegetable but no
01:16
we say vegetable everybody vegetable so
01:20
it sounds like you don't say II
01:23
vegetable vegetable don't say vegetable
01:28
money Oh vegetable is very common
01:31
vegetable but there's an interesting
01:33
point when I see vegetable
01:36
I think fruit so there's a question what
01:43
is the difference between vegetable and
01:47
fruits ego hago ego hago autocut orany
01:51
right how are they different it's very
01:55
simple
01:56
think about this fruit has seeds if
02:03
there are seeds in it it's a fruit
02:08
vegetable no seeds
02:12
a vegetable does not have seeds no seeds
02:18
so a fruit is a part of the plant yes
02:21
but it's only one part of the plant it's
02:24
the part that has seeds if it has seeds
02:28
it's a fruit so an apple cut open an
02:32
apple there are seeds an apple is a
02:36
fruit watermelon must die
02:39
right you cut the watermelon watermelon
02:42
soo bahk right watermelon you cut the
02:44
watermelon wha
02:45
many many many seeds watermelon is a
02:49
fruit vegetable a carrot dong-gun tongan
02:55
right you cut the carrot where's the
02:57
seeds there's no seeds carrot is a
03:00
vegetable okay so that's how you know
03:03
the difference between vegetable and
03:05
fruit but mostly in this lesson we will
03:09
talk about vegetables okay the parts of
03:13
the plant that we eat many parts don't
03:16
have seeds so mostly we will talk about
03:20
vegetables okay okay let's go to the
03:23
next word the next word is the part
03:27
remember there's many parts of a plant
03:29
we're looking at one part the part of a
03:32
plant that makes seeds it's the part of
03:36
the plant that makes the seeds before
03:40
the fruit right it's the part of the
03:42
plant that makes the seeds before it
03:45
becomes a fruit what part is it look at
03:49
the picture there are many pretty-pretty
03:52
what we have yellow we have purple what
03:55
are they of course we say they are
03:58
flowers flower be careful this is a
04:02
little hinder Oh a little difficult to
04:05
pronounce F and L right F and L very
04:11
difficult combination F and L
04:16
love love put them together
04:20
flower flower that's not so hard
04:25
our flower it's the part of the plant
04:28
that makes seeds the flowers make seeds
04:33
okay let's move on to our next word the
04:37
next word we can see Wow looks really
04:39
bright here right very green this is the
04:44
flat green part of a plant and there are
04:49
many right a plant has many of these
04:53
what do we call this one one of them
04:56
what do we call it we call it a leaf
05:00
leaf here we have L and F at the end
05:04
right now they're apart but L remember L
05:07
la la la la la put your tongue behind
05:11
your teeth on the top la leaf and then
05:16
for F leaf leaf that's only one one leaf
05:22
but a plant has many so how do we make
05:26
it plural we say many leaves many leaves
05:34
leaves leaves okay so if it's one just
05:41
one we say it's a leaf but of course a
05:43
plant has many you look at a plant you
05:46
see many leaves on a plant the flat
05:49
green part of a plant usually green
05:53
sometimes they're yellow sometimes
05:55
they're orange right depends but usually
05:58
they're green the green parts of a plant
06:01
okay now we're on the next part of the
06:03
plant and this part we can't see it
06:06
right we can't see that part of the
06:09
plant because it's underground
06:11
underground let me write that for you
06:15
under ground right this is the ground
06:22
this is the ground it's under under the
06:26
ground
06:26
under ground it's Underground the part
06:30
of a plant that grows it grows down in
06:35
the dirt it's in the dirt
06:38
in the dirt it's underground so what
06:42
part of this plant is it what do we say
06:45
what's the word there we say that part
06:48
of the plant is called the root root
06:53
right strong word of course the roots
06:56
are strong because they have to be
06:58
strong because they hold the plant in
07:01
the ground right these roots we can't
07:04
see them unless we pull the plant out
07:07
right we pull the plant out of the
07:09
ground
07:09
then we can see the roots we can see the
07:13
roots right but one root many roots okay
07:17
so root root right strong word root okay
07:23
what's our next word okay our next word
07:25
we're talking about a different part of
07:28
the plant this is this part right here
07:31
actually it's this whole piece right
07:34
here right that whole thing we're
07:37
talking about that part of the plant now
07:39
now it's the part of a plant that holds
07:44
the plant up it holds the plant up right
07:48
it supports the rest of the plant it's
07:51
kind of like my body right my trunk of
07:54
my body holds my body up right but this
07:58
part we don't usually say trunk for a
08:00
small plant we can say what stem stem
08:05
yes we can say trunk for a tree but this
08:09
is a small plant we say stem stem many
08:15
plants all plants have a stem the stem
08:18
is like the body of a plant right it's
08:22
like the body of a plant it's their body
08:25
right some bodies are thin some bodies
08:28
are thick right so these are the stems
08:32
of the plant right some of them are are
08:35
thick and big some of them are very thin
08:38
and not so strong but they are called
08:41
stems stem the stem of a plant the part
08:46
that holds the plant up okay
08:50
the next one is the part of a plant that
08:54
grows into a new plant we talked about
08:59
this part before we've mentioned it
09:03
several times already we're looking at
09:06
this very small piece of the plant that
09:10
piece that part will fly away on the
09:13
wind it'll fall in the ground and a new
09:16
plant will grow okay
09:18
so that's just one type of plant of
09:20
course there are many types of these
09:23
sometimes people eat them right and they
09:26
throw them away in different places and
09:29
a new plant will grow what are we
09:31
talking about we're talking about the
09:34
seed the seed the seed of a plant
09:38
remember when we talked about fruits and
09:42
vegetables where is the seed the seed is
09:46
in the fruit but not all plants have
09:49
fruit some plants there's no fruit like
09:53
this plant here there's no fruit because
09:56
the seeds break off and fly away on the
10:00
wind but many plants grow fruit the
10:03
seeds are in them because animals eat
10:05
the fruit and they eat the seeds too and
10:08
they walk away and they go they go they
10:10
go to the bathroom somewhere else but
10:13
the seeds are in that and the seeds will
10:15
grow in a different location and those
10:18
are seeds okay so plants have many ways
10:21
to spread their seeds okay now we've
10:27
come here to this type of plant we're
10:30
talking about a type of plant a long
10:34
orange vegetable so it's a vegetable you
10:38
can see it right here you know what that
10:40
is right we can only see part of it but
10:42
we know what the rest of it is the rest
10:44
of it is underground right what if we
10:48
call that this of course is called the
10:50
carrot right before I said tongan right
10:52
tongan one of the first words I learned
10:56
in Korean because carrots are very
10:59
common they're good for you carrots are
11:02
very good for your eyes
11:04
you eat many carrots you have good
11:06
eyesight I don't know what happened with
11:08
me I think I read too much but if you
11:11
eat many carrots you have good eyesight
11:13
ok but carrots are long orange vegetable
11:18
they're very good for you ok
11:20
now here we have an action it's not a
11:25
noun we're looking for a verb an action
11:28
to put food into your mouth and chew and
11:34
swallow
11:36
swallow it so you chew it and you
11:39
swallow it actually you do three things
11:41
right first you put it in your mouth
11:45
that's first second you chew it and
11:48
third you swallow it
11:51
right make sure you chew before you
11:54
swallow don't just put and go chew don't
11:58
be so fast take your time chew your food
12:02
well but there's three actions right to
12:05
put food in your mouth chew it and then
12:08
swallow it what are we talking about of
12:11
course we're talking about to eat eat
12:13
okay so when we eat that's what we're
12:17
doing we're actually doing three things
12:18
put food in your mouth chew it and then
12:22
swallow of course we can also talk about
12:24
the different times right present tense
12:29
past tense right and past participle
12:32
okay so when we talk about present tense
12:35
eat eat that's what we're doing now what
12:39
will we do now let's eat let's go eat
12:43
okay and that's also a little bit of
12:45
future right let's eat I want to eat now
12:48
you're talking about the present time or
12:50
just a little bit in the future
12:53
what about ate eat ate I ate breakfast
12:58
did you eat breakfast yes I ate
13:01
breakfast I hope you ate breakfast right
13:05
but you're talking about eatin a long
13:07
time ago right
13:08
I have eaten or I've done something
13:11
before right I have eaten breakfast I
13:15
have eaten
13:16
have you ever eaten eggs for breakfast
13:20
right so if you're talking about if you
13:22
ever did something in your life you have
13:25
done it you have eaten eggs okay
13:28
so eat ate eaten one more time eat ate
13:33
eaten those are the different verb forms
13:37
of this verb to eat by the way you
13:42
should eat breakfast every day right
13:45
always eat breakfast I ate breakfast
13:47
today I hope you ate breakfast today
13:50
okay our next word is another type of
13:54
vegetable another type of vegetable we
13:57
saw carrot before that's one type of
14:00
vegetable but now we have another type
14:03
of vegetable and this is the picture you
14:07
know this one right this is very common
14:09
round white there white maybe a little
14:14
yellow but usually white vegetables that
14:17
grow in the dirt they grow underground
14:21
just like the carrot right what do we
14:24
call these vegetables we call them
14:27
potato potato
14:30
right you know of course come John right
14:32
come John potato is very very common and
14:36
of course we know potatoes as potato
14:39
chips right potato chips are very common
14:42
- made from potatoes and I just gave you
14:46
of course when you talk about plural say
14:49
potatoes potatoes with the e we add es
14:53
at the end it is potatoes potatoes so
14:59
potatoes of course are very common you
15:02
probably eat them maybe every day if not
15:06
every day then probably many times a
15:09
week right I'm sure you eat potatoes
15:11
very often ok ok let's move on now this
15:16
is also very common especially with
15:20
Korean dishes right I really like
15:23
bulgogi right and I like when I eat
15:25
bulgogi I use this to put the bulgogi in
15:29
what do we call that
15:30
a plant with large green leaves it has
15:35
many large green leaves okay what do we
15:38
call it in English we say it's lettuce
15:42
lettuce now lettuce is very similar to
15:46
another vegetable we call cabbage the
15:51
cabbage is very similar but lettuce is
15:55
not so heavy lettuce is lighter it's
15:58
thinner and it tastes a little bit
16:00
better lettuce is a different kind but
16:03
cabbage and they're very close they're
16:05
like brothers right they're like sisters
16:07
they're very close well lettuce or
16:09
cabbage lettuce of course is very common
16:12
we use it in salads of course in many
16:15
Korean dishes you can use it to eat with
16:17
meat I like to put the meat the rice the
16:20
garlic the onion and the dwenjang I hate
16:24
mana hot oil machi soil right but we use
16:27
the lettuce in many different ways okay
16:30
we say lettuce lettuce it almost sounds
16:34
like let us go but it doesn't mean that
16:37
right it's lettuce lettuce and that is a
16:41
plant with large green leaves okay here
16:45
we have another type of plant that we
16:48
eat right we eat these things right here
16:52
these actually are seeds right but
16:54
there's in this case they're soft and
16:56
they're good for you the seed of a pea
16:59
plant that we eat the seed of a pea
17:03
plant that we eat remember pea plants
17:06
right that's very easy because we say P
17:08
right it's a pea peas eat your peas peas
17:13
are very good for you now usually we
17:17
don't eat the seeds of a plant like
17:19
apple seeds come yeah they're very hard
17:22
right look they don't taste good but we
17:25
can eat peas the seeds of a pea plant we
17:29
eat those very often so sometimes we can
17:33
eat seeds but sometimes we don't eat the
17:36
seeds right but in the case of peas we
17:39
eat the seeds okay it's part of the
17:42
plant that we eat
17:44
okay our next word is a verb to have an
17:49
odor that's a verb right a verb when we
17:54
see to do something we're talking about
17:57
a verb to have an odor an odor that
18:02
means I can sense it with my nose right
18:08
there are good odors mmm that's nice and
18:12
there are bad odors whoa mmm saying that
18:15
pile right bad odors so to have an odor
18:18
what is the word what is going on here
18:22
we say that this is smell smell to have
18:26
an odor is to smell there's two ways you
18:30
can use this verb one way is this the
18:35
flower smells so in this case the flower
18:38
smells that's a good odor but sometimes
18:41
there's a bad odor for example my whoops
18:45
where my socks smell whoops
18:53
smell my sock what is a sock you say
18:57
young MA
18:57
right so sock is like this well it
19:01
smells right don't smell that snow whoo
19:04
it smells my socks smell that's one way
19:09
another way you can use this is I smell
19:14
I smell I smell what my sock No yuck
19:19
that's horrible right I smell a flower
19:23
that's much better
19:25
I smell a flower ah much better
19:29
right don't smell your socks whoo right
19:32
that's that's terrible
19:33
right so my socks smell it has an odor
19:37
it gives an odor some good odors and
19:41
some bad odors right my socks smell or I
19:46
smell a flower so there's two ways you
19:50
can use this verb some things smell or
19:55
people
19:57
animals smell something so there's two
20:00
ways the flower smells the boy smells
20:05
the flower two ways right
20:08
okay so smell very interesting verb